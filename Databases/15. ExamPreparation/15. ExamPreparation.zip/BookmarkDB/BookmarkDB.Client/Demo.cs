﻿using System;
using System.Collections.Generic;
using System.Linq;
using BookmarkDB.Model;
using System.Text;
using System.Xml.Linq;
using System.Text.RegularExpressions;


namespace BookmarkDB.Client
{
    public class Demo
    {
        public static void CreateBookmark(string username,
            string title, string url, string[] tags, string notes)
        {
            BookmarksDBEntities dbContext = new BookmarksDBEntities();
            Bookmark newBookmark = new Bookmark();
            newBookmark.User = CreateOrLoadUser(dbContext, username);
            newBookmark.Title = title;
            newBookmark.URL = url;
            newBookmark.Notes = notes;

            if (tags != null)
            {
                foreach (var tagName in tags)
                {
                    Tag tag = CreateOrLoadTag(dbContext, tagName);
                    newBookmark.Tags.Add(tag);
                }
            }
           
            string[] titleTags = Regex.Split(title, @"[,'!\. ;?-]+");
            foreach (var titleTagName in titleTags)
            {
                Tag titleTag = CreateOrLoadTag(dbContext, titleTagName);
                newBookmark.Tags.Add(titleTag);
            }

            dbContext.Bookmarks.Add(newBookmark);
            dbContext.SaveChanges();
        }

        private static User CreateOrLoadUser(
            BookmarksDBEntities dbContext, string username)
        {
            User existingUser =
                (from u in dbContext.Users
                 where u.Username.ToLower() == username.ToLower()
                 select u).FirstOrDefault();
            if (existingUser != null)
            {
                return existingUser;
            }

            User newUser = new User();
            newUser.Username = username;
            dbContext.Users.Add(newUser);
            dbContext.SaveChanges();

            return newUser;
        }

        private static Tag CreateOrLoadTag(BookmarksDBEntities dbContext, string tagName)
        {
            Tag existingTag =
                (from t in dbContext.Tags
                 where t.Name.ToLower() == tagName.ToLower()
                 select t).FirstOrDefault();
            if (existingTag != null)
            {
                return existingTag;
            }

            Tag newTag = new Tag();
            newTag.Name = tagName.ToLower();
            dbContext.Tags.Add(newTag);
            dbContext.SaveChanges();

            return newTag;
        }

        private static void LoadXML()
        {
            BookmarksDBEntities dbContext = new BookmarksDBEntities();
            XDocument xmlDoc = XDocument.Load(@"..\..\bookmarks.xml");
            var bookmarks = xmlDoc.Descendants("bookmark");

            foreach (var bookmark in bookmarks)
            {
                string username = bookmark.Element("username").Value;
                string title = bookmark.Element("title").Value;
                string url = bookmark.Element("url").Value;

                string[] tags = null;
                if ((string)bookmark.Element("tags") != null)
                {
                    tags = bookmark.Element("tags").Value.Split(new string[] { " ", ", ", "," },
                    StringSplitOptions.RemoveEmptyEntries);
                }

                string notes = string.Empty;
                if ((string)bookmark.Element("notes") != null)
                {
                    notes = bookmark.Element("notes").Value;
                }

                CreateBookmark(username, title, url, tags, notes);
            }
        }

        private static void FindBookmarksByUsernameAndTag(
            string username, string tag)
        {
            BookmarksDBEntities context = new BookmarksDBEntities();
            List<Bookmark> bookMarks = new List<Bookmark>();
            if (username != null)
            {
                bookMarks = context.Bookmarks.Where(b => b.User.Username == username).ToList();
            }

            var urls = bookMarks.Where(b => b.Tags.Any(t => t.Name == tag));

            foreach (var url in urls)
            {
                Console.WriteLine(url.URL);
            }
        }

        private static void LoadQueries()
        {
            XDocument doc = XDocument.Load(@"..\..\simple-query.xml");
            var queries = doc.Descendants("query");
            foreach (var query in queries)
	        {
                FindBookmarksByUsernameAndTag(query.Element("username").Value, query.Element("tag").Value);
	        }
        }

        public static void Main()
        {
            //LoadXML();
            LoadQueries();
        }
    }
}

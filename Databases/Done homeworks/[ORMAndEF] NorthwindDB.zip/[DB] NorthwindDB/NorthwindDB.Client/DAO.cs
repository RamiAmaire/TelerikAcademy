﻿using System;
using System.Collections.Generic;
using System.Linq;
using NorthwindDB.Data;
using System.Data.Entity.Validation;
using System.Transactions;

public class DAO
{
    public static void DeleteCustomer(string contactName, string companyName)
    {
        using (NorthwindEntities db = new NorthwindEntities())
        {
            var customers = db.Customers.
                Where(x => x.ContactName == contactName && x.CompanyName == companyName);
            foreach (var customer in customers)
            {
                db.Customers.Remove(customer);
            }

            Console.WriteLine(db.SaveChanges());
        }
    }

    public static void InsertCustomer(string customerId, string companyName, string contactName,
        string contactTitle, string address, string city, string region, string postalCode,
        string country, string phone, string fax)
    {
        using (NorthwindEntities db = new NorthwindEntities())
        {
            Customer customer = new Customer()
            {
                CustomerID = customerId,
                CompanyName = companyName,
                ContactName = contactName,
                ContactTitle = contactTitle,
                Address = address,
                City = city,
                Region = region,
                PostalCode = postalCode,
                Country = country,
                Phone = phone,
                Fax = fax
            };

            db.Customers.Add(customer);
            try
            {
                Console.WriteLine(db.SaveChanges());
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }

                throw;
            }
        }
    }

    public static void UpdateCustomer(Customer customer, string newCompanyName, NorthwindEntities db)
    {
        customer.CompanyName = newCompanyName;
        Console.WriteLine(db.SaveChanges());
    }

    public static void InsertShipper(string companyName, string phone)
    {
        using (NorthwindEntities db = new NorthwindEntities())
        {
            Shipper shipper = new Shipper()
            {
                CompanyName = companyName,
                Phone = phone
            };

            db.Shippers.Add(shipper);
            Console.WriteLine(db.SaveChanges());    
        }
    }

    public static void FindAllCustomersWhoHaveMadeOrdersSince1997()
    {
        using (NorthwindEntities db = new NorthwindEntities())
        {
            var orders = db.Orders.Where(x => x.ShippedDate.Value.Year == 1997 && x.ShipCountry == "Canada");
            foreach (var order in orders)
            {
                Console.WriteLine(order.Customer.ContactName + " " + order.Customer.CompanyName);
            }
        }
    }

    public static void FindAllCustomersWhoHaveMadeOrdersSince1997Native()
    {
        using (NorthwindEntities dbContext = new NorthwindEntities())
        {
            string sqlCmd = @"select * 
                            from Orders o join Customers c
                            on o.CustomerID = c.CustomerID
                            where YEAR(o.OrderDate) = 1997 and o.ShipCountry = 'Canada'";
            var customers = dbContext.Database.SqlQuery<Customer>(sqlCmd);

            foreach (var customer in customers)
            {
                Console.WriteLine(customer.ContactName + " " + customer.CompanyName);
            }
        }
    }

    public static void FindAllSalesByRegionAndPeriod(string region, int startYear, int endYear)
    {
        using (NorthwindEntities dbContext = new NorthwindEntities())
        {
            var sales = dbContext.Orders.Where
                (o => o.ShipRegion == region && o.OrderDate.Value.Year > startYear && o.OrderDate.Value.Year < endYear).Select(
                o => new { ShipName = o.ShipName, ShippedDate = o.ShippedDate });

            foreach (var sale in sales)
            {
                Console.WriteLine(sale.ShipName + " " + sale.ShippedDate);
            }
        }
    }

    public static void CreateOrderWithTransaction(int OrderID, string CustomerID, int EmployeeID,
        DateTime OrderDate, DateTime RequiredDate, DateTime ShippedDate, int ShipVia, decimal Freight,
         string ShipName, string ShipAddress, string ShipCity, string ShipRegion, string ShipPostalCode, string ShipCountry)
    {
        using (NorthwindEntities dbContext = new NorthwindEntities())
        {
            using (TransactionScope  scope = new TransactionScope())
            {
                Order order = new Order() 
                {
                    OrderID = OrderID,
                    CustomerID = CustomerID,
                    EmployeeID = EmployeeID,
                    OrderDate = OrderDate,
                    RequiredDate = RequiredDate,
                    ShippedDate = ShippedDate,
                    ShipVia = ShipVia,
                    Freight = Freight,
                    ShipName = ShipName,
                    ShipAddress = ShipAddress,
                    ShipCity = ShipCity,
                    ShipRegion = ShipRegion,
                    ShipPostalCode = ShipPostalCode, 
                    ShipCountry = ShipCountry
                };

                scope.Complete();
            }
        }
    }
}


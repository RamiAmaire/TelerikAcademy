﻿using System;
using System.Linq;
using NorthwindDB.Data;
using System.Text;
using System.Data.Entity.Infrastructure;

public class Demo
{
    public static void Main()
    {
        //DAO.InsertShipper("Telerik", "822 333 333");
        //DAO.InsertCustomer("93", "TelerikAD", "Pencho", "Developer",
        //    "Obere Str. 57", "Berlin", "BC", "05021", "Germany", "030-0074341", "030-0076575");
        //using(NorthwindEntities db = new NorthwindEntities())
        //{
        //    var customer = db.Customers.Find("93");
        //    DAO.UpdateCustomer(customer, "KaspichanAD", db);
        //}
        //DAO.FindAllCustomersWhoHaveMadeOrdersSince1997();
        //DAO.FindAllCustomersWhoHaveMadeOrdersSince1997Native();
        //DAO.FindAllSalesByRegionAndPeriod(null, 1996, 1997);
        //DAO.CreateOrderWithTransaction(
    }
}

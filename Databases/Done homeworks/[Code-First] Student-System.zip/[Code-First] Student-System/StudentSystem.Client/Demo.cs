﻿using System;
using System.Collections.Generic;
using StudentSystem.Data;
using Student_System.Models;
using StudentSystem.Data.Migrations;
using System.Data.Entity;
using System.Linq;

namespace StudentSystem.Client
{
    public class Demo
    {
        public static void Main()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion
            <StudentSystemContext, Configuration>());
            using (StudentSystemContext context = new StudentSystemContext())
            {
                foreach (var stud in context.Students)
                {
                    Console.Write(stud.Number + ". " + stud.Name + " ");
                    foreach (var course in stud.Courses)
                    {
                        Console.Write(course.Name + " " + course.Description);
                    }

                    Console.WriteLine();
                }
            }
        }
    }
}

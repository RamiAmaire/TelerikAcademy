﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Student_System.Models
{
    public class Student
    {
        private ICollection<Course> courses;
        private ICollection<Homework> homeworks;

        public Student()
        {
            this.courses = new HashSet<Course>();
            this.homeworks = new HashSet<Homework>();
        }

        public Student(string name, string number, StudenType type, ICollection<Course> courses)
            :base()
        {
            this.Name = name;
            this.Number = number;
            this.Type = type;
            this.Courses = courses;
            this.Homeworks = homeworks;
        }

        [Key]
        public int StudentId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Number { get; set; }
        [Required]
        public StudenType Type { get; set; }

        public virtual ICollection<Course> Courses
        {
            get
            {
                return this.courses;
            }
            set
            {
                this.courses = value;
            }
        }
        public virtual ICollection<Homework> Homeworks
        {
            get
            {
                return this.homeworks;
            }
            set
            {
                this.homeworks = value;
            }
        }
    }
}

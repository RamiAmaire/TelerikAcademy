﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Student_System.Models
{
    public class Homework
    {
        public Homework(string content, DateTime timeSent, Student student, Course course)
        {
            this.Content = content;
            this.TimeSent = timeSent;
            this.Student = student;
            this.Course = course;
        }

        public int HomeworkId { get; set; }
        [Required]
        public string Content { get; set; }
        [Required]
        public DateTime TimeSent { get; set; }

        [ForeignKey("Student")]
        public int StudentId { get; set; }
        public virtual Student Student { get; set; }

        [ForeignKey("Course")]
        public int CourseId { get; set; }
        public virtual Course Course { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_System.Models
{
    public enum StudenType
    {
        Autumn = 0,
        Spring = 1
    }
}

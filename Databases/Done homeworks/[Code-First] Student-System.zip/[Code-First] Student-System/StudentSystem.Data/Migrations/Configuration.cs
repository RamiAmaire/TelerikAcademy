namespace StudentSystem.Data.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using StudentSystem.Data;
    using Student_System.Models;
    using System.Collections.Generic;

    public sealed class Configuration : DbMigrationsConfiguration<StudentSystemContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(StudentSystemContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

            Course dataBase = new Course("Data base", "Relational", null, null);
            Course supportBasics = new Course("Support basics", "Boring", null, null);
            context.Courses.AddOrUpdate(dataBase);
            context.Courses.AddOrUpdate(supportBasics);

            foreach (var stud in context.Students)
            {
                foreach (var course in context.Courses)
                {
                    stud.Courses.Add(course);
                }
            }
            
            context.SaveChanges();
        }
    }
}

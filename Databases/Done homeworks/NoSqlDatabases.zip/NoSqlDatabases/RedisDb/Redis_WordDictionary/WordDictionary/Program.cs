﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordDictionary
{
    using ServiceStack.Redis;

    class Program
    {
        static void Main()
        {
            var client = new RedisClient("127.0.0.1:6379");

            using (client)
            {
                while (true)
                {
                    PrintMenu();
                    var command = Console.ReadLine();
                    
                    if (command != null && command == "exit") break;


                    try
                    {
                       int parsedCommand = int.Parse(command);
                       PorcessCommand(parsedCommand);
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("must be digit");
                    }

                }
            }
        }
        private static void PorcessCommand(int command)
        {
            switch (command)
            {
                case 1:
                    ;break;
                case 2:
                    ;
                    break;
                case 3:
                    ;
                    break;
                case 4:
                    ;
                    break;
                case 5:
                    ;
                    break;
                default: break;
            }
        }
        private static void EditWord(RedisClient words)
        {
            Console.WriteLine("enter word to edit..");
            string wordToEdit = Console.ReadLine().Trim().ToLower();

            Console.WriteLine("translation is: ");
            string translation = Console.ReadLine().Trim().ToLower();

            var wordsCount = words.HExists("word",wordToEdit.ToAsciiCharArray());

            if (wordsCount > 0)
            {
                words.HSet("words", wordToEdit.ToAsciiCharArray(), translation.ToAsciiCharArray());
            }
            else
            {
                Console.WriteLine("no such word");
            }
        }

        private static void RemoveWords(RedisClient words)
        {
            Console.WriteLine("enter word to remove");

            var wordToRemove = Console.ReadLine().ToLower().Trim();

            var wordsCount = words.HExists("words", wordToRemove.ToAsciiCharArray());

            if (wordsCount > 0)
            {
                words.HDel("words", wordToRemove.ToAsciiCharArray());
            }
            else
            {
                Console.WriteLine("no such word");
            }
        }

        private static void SearchWord(RedisClient words)
        {
            Console.WriteLine("enter word");
            var word = Console.ReadLine().ToLower().Trim();

            var wordsCount = words.HExists("word", word.ToAsciiCharArray());
            if (wordsCount > 0)
            {
                var translation = words.HGet("word", word.ToAsciiCharArray());
                Console.WriteLine("word: {0}  translation: {1}",word,Extensions.StringFromByteArray(translation));
            }
            else
            {
                Console.WriteLine("no such word");
            }
        }

        private static void AddWord(RedisClient words)
        {
            Console.WriteLine("enter word");
            string wordToAdd = Console.ReadLine().Trim().ToLower();
            Console.WriteLine("translation");
            string wordTranslation = Console.ReadLine().Trim().ToLower();
            var wordsCount = words.HExists("words", wordToAdd.ToAsciiCharArray());

            if (wordsCount > 0)
            {
                Console.WriteLine("already exists");
            }
            else
            {
                words.HSet("words", wordToAdd.ToAsciiCharArray(),wordTranslation.ToAsciiCharArray());
            }

        }

        //private static void EditWord()
        //{

        //}

        private static void PrintMenu()
        {
            Console.WriteLine("----------------------------");
            Console.WriteLine("1 => Search for translation"); 
            Console.WriteLine("2 => List all words"); 
            Console.WriteLine("3 => Edit a listed word"); 
            Console.WriteLine("4 => Remove a listed word"); 
            Console.WriteLine("5 => Add word");
            Console.WriteLine("type exit to quit");
        }
    }
}

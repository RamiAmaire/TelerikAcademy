﻿namespace MongoDb_WordDictionary
{
    using System;
    using System.Linq;
    using MongoDB.Driver;
    using MongoDB.Driver.Linq;

    class Program
    {
        private static MongoCollection<Word> words;

        private static IQueryable<Word> wordQuery;
 
        static void Main()
        {
            var mongoClient = new MongoClient("mongodb://localhost/");
            var mongoServer = mongoClient.GetServer();
            var dictionaryDb = mongoServer.GetDatabase("Dictionary");
            words = dictionaryDb.GetCollection<Word>("Words");

            wordQuery = words.AsQueryable();

            while (true)
            {
                PrintMenu();

                string command = Console.ReadLine().Trim();

                if (command == "exit")
                {
                    break;
                }

                ParseCommand(command);

            }


        }   

        private static void ParseCommand(string command)
        {
            int parsedCommand = 0;

            try
            {
                parsedCommand = int.Parse(command);
            }
            catch (Exception)
            {
                Console.WriteLine("must be digit");
            }

            switch (parsedCommand)
            {

                case 1:
                    AddWordAndTranslation(words);break;
                case 2:
                    ListWords(wordQuery);break;
                case 3:
                    WordTranslation(wordQuery);break;
                default:
                    break;
            }
        }
        private static void WordTranslation(IQueryable<Word> words)
        {
            Console.Write("input the searched word: ");
            var _word = Console.ReadLine().Trim();

            var searchedWord = words.Where(x => x.Name == _word);

            foreach (var word in searchedWord.ToList())
            {
                Console.WriteLine("Seatched Word: {1} - Translation: {0}", word.Translation,word.Name);
            }
            Console.WriteLine();
        }

        private static void ListWords(IQueryable<Word> words)
        {
            var _words = words.ToList();

            foreach (var word in _words)
            {
                Console.WriteLine("word: {0}  translation: {1}", word.Name, word.Translation);
            }
            Console.WriteLine();
        }
        private static void AddWordAndTranslation(MongoCollection<Word> words)
        {
            Console.WriteLine("Enter word and translation");
            Console.Write("word: ");
            string word = Console.ReadLine();
            Console.Write("translation: ");
            string tanslation = Console.ReadLine();

            Word newWord = new Word() { Name = word, Translation = tanslation };

            words.Insert(newWord);
            Console.WriteLine();
        }     
        private static void PrintMenu()
        {
            Console.WriteLine("1 => add new word & translation");
            Console.WriteLine("2 => list words + their translations");
            Console.WriteLine("3 => translation of given word");
            Console.WriteLine("exit => type exit");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MongoDb.Data
{
    using MongoDB.Driver;

    public static class MongoDbProvider
    {
        public static MongoDatabase db
        {
            get
            {
                  var client = new MongoClient("mongodb://localhost");

                  MongoServer server = client.GetServer();

                return server;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using TelerikAcademy.Data;
using System.Linq;

namespace TelerikAcademy.Client
{
    public class Demo
    {
        public static void Main()
        {
            // First Task
            //using (TelerikAcademyEntities dbContext = new TelerikAcademyEntities())
            //{
            //    // Without include
            //    //foreach (var employee in dbContext.Employees)
            //    //{
            //    //    Console.WriteLine("Employee : {0}, {1}, {2}",
            //    //    employee.FirstName + " " + employee.LastName, employee.Department.Name, employee.Address.Town.Name);
            //    //}

            //    // With include
            //    var employees = dbContext.Employees.
            //        Include("Town").
            //        Include("Address").
            //        Include("Department").
            //        Select(e => new {e.LastName, e.Department.Name, e.Address.Town});
            //    foreach (var employee in employees)
            //    {
            //        Console.WriteLine(employee.LastName + " " + employee.Name + " " + employee.Town.Name);
            //    }
            //}

            // Second Task
            // Slow
            //using (TelerikAcademyEntities dbContext = new TelerikAcademyEntities())
            //{
            //    var employeeTownSofia = dbContext.Employees.ToList().
            //        Select(e => e.Address).ToList().
            //        Select(e => e.Town).ToList().FindAll(t => t.Name == "Sofia");

            //    foreach (var employee in employeeTownSofia)
            //    {
            //        Console.WriteLine(employee.TownID + ". " + employee.Name);
            //    }
            //}

            // Fast
            using (TelerikAcademyEntities dbContext = new TelerikAcademyEntities())
            {
                var employeesFromSofia = from e in dbContext.Employees
                                         join a in dbContext.Addresses
                                         on e.AddressID equals a.AddressID
                                         join t in dbContext.Towns
                                         on a.TownID equals t.TownID
                                         where t.Name == "Sofia"
                                         orderby e.LastName
                                         select new { EmployeeName = e.LastName, Town = t.Name };


                foreach (var em in employeesFromSofia)
                {
                    Console.WriteLine(em.EmployeeName + ";" + em.Town);
                }
            }
        }
    }
}

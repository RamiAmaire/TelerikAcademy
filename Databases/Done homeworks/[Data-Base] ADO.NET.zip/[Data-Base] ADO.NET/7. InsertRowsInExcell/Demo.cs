﻿using System;
using System.Data.OleDb;

public class Demo
{
    public static void Main()
    {
        string connectionString = string.Format(
            "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0 Xml;HDR=No;IMEX=1\";", @"C:\Users\ramia_000\Desktop\TATrainees.xlsx;Extended Properties=""Excel 12.0 XML;HDR=Yes""");
        OleDbConnection dbCon = new OleDbConnection(connectionString);
        dbCon.Open();

        using (dbCon)
        {
            for (int i = 0; i < 5; i++)
            {
                OleDbCommand cmd = new OleDbCommand(
                    "INSERT INTO [Sheet1$] (Name,Score) VALUES (@Name,@Score)", dbCon);
                cmd.Parameters.AddWithValue("@Name", "Pencho " + i);
                cmd.Parameters.AddWithValue("@Score", i + 25);
                cmd.ExecuteNonQuery();
            }
        }
    }
}


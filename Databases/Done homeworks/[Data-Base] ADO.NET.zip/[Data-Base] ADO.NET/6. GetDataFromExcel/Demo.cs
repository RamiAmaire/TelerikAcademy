﻿using System;
using System.Data;
using System.Data.OleDb;

public class Demo
{
    public static void Main()
    {
        string connectionString = string.Format(
            "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=\"Excel 12.0 Xml;HDR=No;IMEX=1\";", @"C:\Users\ramia_000\Desktop\TATrainees.xlsx");
        OleDbConnection dbCon = new OleDbConnection(connectionString);
        OleDbCommand myCommand = new OleDbCommand("select * from [Sheet1$]", dbCon);
        dbCon.Open();

        OleDbDataReader reader = myCommand.ExecuteReader();
        while (reader.Read())
        {
            Console.Write(reader[0] + "       " + reader[1]);
            Console.WriteLine();
        }
    }
}


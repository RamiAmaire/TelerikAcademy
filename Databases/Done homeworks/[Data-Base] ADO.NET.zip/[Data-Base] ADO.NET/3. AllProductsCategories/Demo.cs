﻿using System;
using System.Data.SqlClient;

public class Demo
{
    public static void Main()
    {
        SqlConnection dbCon = new SqlConnection("Server=RAMIPC; " +
            "Database=northwind; Integrated Security=true");
        dbCon.Open();

        using (dbCon)
        {
            SqlCommand cmdAllEmployees = new SqlCommand(
              @"select c.CategoryName, p.ProductName
                from Products P JOIN Categories c
                on p.CategoryID = c.CategoryID
                group by c.CategoryName, p.ProductName", dbCon);
            SqlDataReader reader = cmdAllEmployees.ExecuteReader();
            using (reader)
            {
                int counter = 1;
                while (reader.Read())
                {
                    string categoryName = (string)reader["CategoryName"];
                    string productName = (string)reader["ProductName"];
                    Console.WriteLine("{0}. {1} - {2}", counter, categoryName, productName);
                    counter++;
                }
            }
        }
    }
}

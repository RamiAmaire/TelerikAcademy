﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

public class Demo
{
    public static void Main()
    {
        SqlConnection dbCon = new SqlConnection("Server=RAMIPC; " +
            "Database=northwind; Integrated Security=true");
        dbCon.Open();

        using (dbCon)
        {
            SqlCommand cmdCount = new SqlCommand(
                "SELECT COUNT(*) FROM Categories", dbCon);
            int categoriesCount = (int)cmdCount.ExecuteScalar();
            Console.WriteLine(categoriesCount);
        }
    }
}


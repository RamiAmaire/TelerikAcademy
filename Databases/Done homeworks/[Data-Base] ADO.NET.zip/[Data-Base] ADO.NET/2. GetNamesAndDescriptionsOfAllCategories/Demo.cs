﻿using System;
using System.Data.SqlClient;

public class Demo
{
    public static void Main()
    {
        SqlConnection dbCon = new SqlConnection("Server=RAMIPC; " +
            "Database=northwind; Integrated Security=true");
        dbCon.Open();

        using (dbCon)
        {
            SqlCommand cmdAllEmployees = new SqlCommand(
              "SELECT CategoryName, Description FROM Categories", dbCon);
            SqlDataReader reader = cmdAllEmployees.ExecuteReader();
            using (reader)
            {
                int counter = 1;
                while (reader.Read())
                {
                    string name = (string)reader["CategoryName"];
                    string description = (string)reader["Description"];
                    Console.WriteLine("{0}. {1} {2}", counter, name, description);
                    counter++;
                }
            }
        }
    }
}


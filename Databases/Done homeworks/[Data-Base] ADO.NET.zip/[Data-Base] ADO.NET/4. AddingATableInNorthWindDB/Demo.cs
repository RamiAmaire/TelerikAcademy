﻿using System;
using System.Collections;
using System.Data.SqlClient;

public class Demo
{
    public static void Main()
    {
        SqlConnection dbCon = new SqlConnection("Server=RAMIPC; " +
            "Database=northwind; Integrated Security=true");
        dbCon.Open();

        using (dbCon)
        {
            SqlCommand cmdInsertProduct = new SqlCommand(
            @"INSERT INTO Products(
                ProductName, SupplierID, CategoryID,
                QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder,
                ReorderLevel, Discontinued) 
            VALUES (
            @ProductName, @SupplierID, @CategoryID, @QuantityPerUnit,
            @UnitPrice, @UnitsInStock, @UnitsOnOrder, @ReorderLevel, @Discontinued", dbCon);

            cmdInsertProduct.Parameters.AddWithValue("@ProductName", "Sax");
            cmdInsertProduct.Parameters.AddWithValue("@SupplierID", 1);
            cmdInsertProduct.Parameters.AddWithValue("@CategoryID", 1);
            cmdInsertProduct.Parameters.AddWithValue("@QuantityPerUnit", "Hardcore");
            cmdInsertProduct.Parameters.AddWithValue("@UnitPrice", 64);
            cmdInsertProduct.Parameters.AddWithValue("@UnitsInStock", 1);
            cmdInsertProduct.Parameters.AddWithValue("@UnitsOnOrder", 1);
            cmdInsertProduct.Parameters.AddWithValue("@ReorderLevel", 10);
            cmdInsertProduct.Parameters.AddWithValue("@Discontinued", 1); // bug
            cmdInsertProduct.ExecuteNonQuery();
        }
    }
}


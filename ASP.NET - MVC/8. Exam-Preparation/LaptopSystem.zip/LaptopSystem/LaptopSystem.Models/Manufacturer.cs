﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LaptopSystem.Models
{
    public class Manufacturer
    {
        public Manufacturer()
        {
            this.Laptops = new HashSet<Laptop>();
        }

        [Key]
        public int Id { get; set; }

        [Required, MinLength(4), MaxLength(20)]
        public string Name { get; set; }

        public virtual ICollection<Laptop> Laptops { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LaptopSystem.Models
{
    public class Laptop
    {
        public Laptop()
        {
            this.Votes = new HashSet<Vote>();
            this.Comments = new HashSet<Comment>();
        }

        [Key]
        public int Id { get; set; }

        [Required, MinLength(4), MaxLength(30)]
        public string Model { get; set; }

        [Required, Range(10, 30)]
        public double Inches { get; set; }

        [Required, Range(10, 1000)]
        public double HardDisk { get; set; }

        [Required, Range(1, 16)]
        public double Ram { get; set; }

        [Required]
        public string Image { get; set; }

        [Required, Range(600, 5000)]
        public decimal Price { get; set; }

        [Range(1, 3)]
        public double Weight { get; set; }

        [MinLength(6), MaxLength(1000)]
        public string AdditionalParts { get; set; }

        [MinLength(6), MaxLength(2000)]
        public string Description { get; set; }

        public int ManufacturerId { get; set; }

        public virtual Manufacturer Manufacturer { get; set; }

        public virtual ICollection<Vote> Votes { get; set; }

        public virtual ICollection<Comment> Comments { get; set; }
    }
}

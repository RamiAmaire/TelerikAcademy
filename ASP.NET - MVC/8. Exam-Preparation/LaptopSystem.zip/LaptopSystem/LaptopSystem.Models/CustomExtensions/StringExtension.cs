﻿using System;

namespace LaptopSystem.Models.CustomExtensions
{
    public static class StringExtension
    {
        public static string TrimFrontIfLongerThan(this string value, int maxLength)
        {
            if (value.Length > maxLength)
            {
                return value.Substring(0, maxLength) + "...";
            }

            return value;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LaptopSystem.Models
{
    public class Comment
    {
        [Key]
        public int Id { get; set; }

        public string UserId { get; set; }

        public virtual ApplicationUser User { get; set; }

        public int LaptopId { get; set; }

        public virtual Laptop Laptop { get; set; }

        [Required, MinLength(6), MaxLength(1000)]
        public string Content { get; set; }
    }
}

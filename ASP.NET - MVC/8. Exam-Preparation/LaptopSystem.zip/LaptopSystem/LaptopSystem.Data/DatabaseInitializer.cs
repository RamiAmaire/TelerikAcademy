﻿using LaptopSystem.Models;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaptopSystem.Data
{
    public class DatabaseInitializer : DbMigrationsConfiguration<ApplicationDbContext>
    {
        public DatabaseInitializer()
        {
            this.AutomaticMigrationsEnabled = true;
            this.AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(ApplicationDbContext context)
        {
            if (context.Laptops.Count() > 0)
            {
                return;
            }

            // This method creates admin user with username - admin and password - admin123
            SeedUserAdmin(context);
            Random rand = new Random();
            Manufacturer sampleManufacturer = new Manufacturer { Name = "Lenovo" };
            // not admin user
            ApplicationUser user = new ApplicationUser() { UserName = "TestUser", Email = "TestMail@test.com" };

            for (int i = 0; i < 10; i++)
            {
                Laptop laptop = new Laptop();
                laptop.HardDisk = rand.Next(10, 1000);
                laptop.Image = "http://laptop.bg/system/images/26207/thumb/toshiba_satellite_l8501v8.jpg";
                laptop.Manufacturer = sampleManufacturer;
                laptop.Model = "IdeaPad";
                laptop.Inches = rand.Next(10, 30);
                laptop.Price = rand.Next(600, 3000);
                laptop.Ram = rand.Next(1, 16);
                laptop.Weight = 3;

                var votesCount = rand.Next(0, 10);
                for (int j = 0; j < votesCount; j++)
                {
                    laptop.Votes.Add(new Vote { Laptop = laptop, User = user });
                }

                var commentsCount = rand.Next(0, 10);
                for (int j = 0; j < commentsCount; j++)
                {
                    laptop.Comments.Add(new Comment { Content = "Mnou qk laptop brat.", User = user });
                }

                context.Laptops.Add(laptop);
            }

            context.SaveChanges();
            base.Seed(context);
        }

        private static void SeedUserAdmin(ApplicationDbContext context)
        {
            if (context.Users.Any())
            {
                return;
            }

            var db = new ApplicationDbContext();

            var userAdmin = new ApplicationUser()
            {
                UserName = "admin",
                Email = "admin@gmail.com",
                Logins = new Collection<UserLogin>()
                {
                    new UserLogin()
                    {
                        LoginProvider = "Local",
                        ProviderKey = "admin",
                    }
                },
                Roles = new Collection<UserRole>()
                {
                    new UserRole()
                    {
                        Role = new Role("Admin")
                    }
                }
            };

            db.Users.Add(userAdmin);
            db.UserSecrets.Add(new UserSecret("admin",
                "ACQbq83L/rsvlWq11Zor2jVtz2KAMcHNd6x1SN2EXHs7VuZPGaE8DhhnvtyO10Nf5Q=="));// Password - admin123
            db.SaveChanges();
        }
    }
}

﻿using System;
using LaptopSystem.Models;
using System.Linq.Expressions;

namespace LaptopSystem.Web.Models
{
    public class CommentViewModel
    {
        public static Expression<Func<Comment, CommentViewModel>> FromComment
        {
            get
            {
                return comment => new CommentViewModel
                {
                    Author = comment.User.UserName,
                    Content = comment.Content
                };
            }
        }

        public string Author { get; set; }

        [ShouldNotContainEmailAttribute]
        public string Content { get; set; }
    }
}
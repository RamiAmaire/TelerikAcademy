﻿using LaptopSystem.Models;
using System;
using System.Linq.Expressions;

namespace LaptopSystem.Web.Models
{
    public class LaptopModelViewModel
    {
        public static Expression<Func<Laptop, LaptopModelViewModel>> FromLaptop
        {
            get
            {
                return laptop => new LaptopModelViewModel
                {
                    Model = laptop.Model
                };
            }
        }

        public string Model { get; set; }
    }
}
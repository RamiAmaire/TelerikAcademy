﻿using System;

namespace LaptopSystem.Web.Models
{
    public class SearchModel
    {
        public string ModelSearch { get; set; }

        public string ManufacturerSearch { get; set; }

        public decimal PriceSearch { get; set; }
    }
}
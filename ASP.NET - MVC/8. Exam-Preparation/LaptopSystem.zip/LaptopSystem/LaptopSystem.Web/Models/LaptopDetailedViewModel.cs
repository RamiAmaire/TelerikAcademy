﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using LaptopSystem.Models;

namespace LaptopSystem.Web.Models
{
    public class LaptopDetailedViewModel
    {
        public LaptopDetailedViewModel()
        {
            this.Comments = new HashSet<CommentViewModel>();
        }

        [Key]
        public int Id { get; set; }

        [Required, MinLength(4), MaxLength(30)]
        public string Model { get; set; }

        [Required, Range(10, 30)]
        public double Inches { get; set; }

        [Required, Range(10, 1000)]
        public double HardDisk { get; set; }

        [Required, Range(1, 16)]
        public double Ram { get; set; }

        [Required]
        public string Image { get; set; }

        [Required, Range(600, 5000)]
        public decimal Price { get; set; }

        [Range(1, 3)]
        public double Weight { get; set; }

        [MinLength(6), MaxLength(1000)]
        public string AdditionalParts { get; set; }

        [MinLength(6), MaxLength(2000)]
        public string Description { get; set; }

        public string ManufacturerName { get; set; }

        public ICollection<CommentViewModel> Comments { get; set; }

        public long VotesCount { get; set; }

        public bool UserCanVote { get; set; }
    }
}
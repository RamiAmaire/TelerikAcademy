﻿using LaptopSystem.Models;
using System;

namespace LaptopSystem.Web.Models
{
    public class CommentSubmitViewModel
    {
        public int LaptopId { get; set; }

        public string AuthorId { get; set; }

        [ShouldNotContainEmailAttribute]
        public string Content { get; set; }
    }
}
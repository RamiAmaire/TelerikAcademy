﻿using LaptopSystem.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;

namespace LaptopSystem.Web.Models
{
    public class CommentAdminViewModel
    {
        public static Expression<Func<Comment, CommentAdminViewModel>> FromComment
        {
            get
            {
                return comment => new CommentAdminViewModel
                {
                    Id = comment.Id,
                    LaptopName = comment.Laptop.Manufacturer.Name + " " + comment.Laptop.Model,
                    Content = comment.Content,
                    AuthorName = comment.User.UserName
                };
            }
        }

        [ScaffoldColumn(false)]
        public int Id { get; set; }

        public string LaptopName { get; set; }

        [Required]
        [ShouldNotContainEmail]
        [MinLength(6), MaxLength(1000)]
        public string Content { get; set; }

        public string AuthorName { get; set; }
    }
}
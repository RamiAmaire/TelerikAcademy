﻿using LaptopSystem.Models;
using System;
using System.Linq.Expressions;
namespace LaptopSystem.Web.Models
{
    public class LaptopViewModel
    {
        public static Expression<Func<Laptop, LaptopViewModel>> FromLaptop
        {
            get
            {
                return laptop => new LaptopViewModel
                {
                   Id = laptop.Id,
                   ManufacturerName = laptop.Manufacturer.Name,
                   Model = laptop.Model,
                   Price = laptop.Price,
                   Image = laptop.Image
                };
            }
        }
        public int Id { get; set; }

        public string ManufacturerName { get; set; }

        public string Model { get; set; }

        public decimal Price { get; set; }

        public string Image { get; set; }
    }
}
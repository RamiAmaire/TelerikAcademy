﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LaptopSystem.Web.Models;
using Microsoft.AspNet.Identity;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using LaptopSystem.Models;

namespace LaptopSystem.Web.Controllers
{
    public class LaptopsController : BaseController
    {
        [Authorize]
        public ActionResult Search([DataSourceRequest] DataSourceRequest request, SearchModel model)
        {
            var laptops = this.GetAllLaptops();
            if (!(String.IsNullOrEmpty(model.ModelSearch)))
            {
                laptops = laptops.Where(lap => lap.Model.ToLower().Contains(model.ModelSearch.ToLower()));
            }

            if (model.ManufacturerSearch != "All")
            {
                laptops = laptops.Where(lap => lap.ManufacturerName == model.ManufacturerSearch);    
            }

            if (model.PriceSearch != 0)
            {
                laptops = laptops.Where(lap => lap.Price <= model.PriceSearch);
            }

            return View(laptops);
        }

        [Authorize]
        public JsonResult GetLaptopManufacturers()
        {
            var laptopManufacturers = this.Data.Laptops.All().
                Select(m => new {ManufacturerName = m.Manufacturer.Name }).Distinct().ToList();
            laptopManufacturers.Insert(0, new { ManufacturerName = "All" });

            return Json(laptopManufacturers, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        public JsonResult GetLaptopModels(string model)
        {
            var selectedLaptopModels = this.Data.Laptops.All().
                Where(lap => lap.Model.Contains(model)).
                Select(LaptopModelViewModel.FromLaptop).Distinct();
           
            return Json(selectedLaptopModels, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [ValidateAntiForgeryToken]
        public ActionResult Comment(CommentSubmitViewModel comment)
        {
            if (comment != null && ModelState.IsValid)
            {
                var currentLaptop = this.Data.Laptops.GetById(comment.LaptopId);
                var newComment = new Comment() { Content = comment.Content,
                    Laptop = currentLaptop, UserId = comment.AuthorId };
                currentLaptop.Comments.Add(newComment);
                this.Data.SaveChanges();

                var commentViewModel = new CommentViewModel()
                { 
                    Author = User.Identity.GetUserName(),
                    Content = comment.Content
                };

                return PartialView("_CommentPartial", commentViewModel);
            }

            return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest,
                ModelState.Values.First().ToString());
        }

        [Authorize]
        public ActionResult Vote(int id)
        {
            var laptop = this.Data.Laptops.All().FirstOrDefault(v => v.Id == id);
            laptop.Votes.Add(new Vote() { Laptop = laptop, UserId = User.Identity.GetUserId() });
            this.Data.Laptops.Update(laptop);
            this.Data.SaveChanges();
            var votes = this.Data.Laptops.GetById(id).Votes.Count;
            return Content(votes.ToString());
        }

        [Authorize]
        public IQueryable<LaptopViewModel> GetAllLaptops()
        {
            var laptops = this.Data.Laptops.All()
                .Select(LaptopViewModel.FromLaptop)
                .OrderBy(lap => lap.Id);
            return laptops;
        }

        [Authorize]
        public JsonResult ReadLaptops([DataSourceRequest] DataSourceRequest request, SearchModel model)
        {
            var laptops = this.GetAllLaptops();
            return Json(this.GetAllLaptops().ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        public ActionResult List()
        {
            return View();
        }

        public ActionResult Details(int id)
        {
            string userId = User.Identity.GetUserId();
            var laptopModel = this.Data.Laptops.All().
                Where(lap => lap.Id == id).
                Select(lap => new LaptopDetailedViewModel
                {
                    ManufacturerName = lap.Manufacturer.Name,
                    Model = lap.Model,
                    Price = lap.Price,
                    Weight = lap.Weight,
                    AdditionalParts = lap.AdditionalParts,
                    HardDisk = lap.HardDisk,
                    Ram = lap.Ram,
                    Inches = lap.Inches,
                    Image = lap.Image,
                    Description = lap.Description,
                    Id = lap.Id,
                    Comments = lap.Comments.Select(c => new CommentViewModel 
                    { Author = c.User.UserName, Content = c.Content}).ToList(),
                    VotesCount = lap.Votes.Count,
                    UserCanVote = !(lap.Votes.Any(v => v.UserId ==userId))
                }
            ).FirstOrDefault();

            return View(laptopModel);
        }
	}
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using LaptopSystem.Web.Models;

namespace LaptopSystem.Web.Controllers
{
    [Authorize(Roles="Admin")]
    public class CommentsAdministrationController : BaseController
    {
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetComments([DataSourceRequest]DataSourceRequest request)
        {
            var comments = this.Data.Comments.All().Select(CommentAdminViewModel.FromComment);
            return Json(comments.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateComment([DataSourceRequest] DataSourceRequest request, CommentAdminViewModel comment)
        {
            if (comment != null && ModelState.IsValid)
            {
                var existingComment = this.Data.Comments.GetById(comment.Id);
                existingComment.Content = comment.Content;
                this.Data.Comments.Update(existingComment);
                this.Data.SaveChanges();
            }

            return Json((new[] { comment }.ToDataSourceResult(request, ModelState)), JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteComment([DataSourceRequest]DataSourceRequest request, CommentAdminViewModel comment)
        {
            var commentToDelete = this.Data.Comments.GetById(comment.Id);
            if (commentToDelete != null)
            {
                this.Data.Comments.Delete(commentToDelete);
                this.Data.SaveChanges();
            }

            return Json(new[] { comment }, JsonRequestBehavior.AllowGet);
        }
	}
}
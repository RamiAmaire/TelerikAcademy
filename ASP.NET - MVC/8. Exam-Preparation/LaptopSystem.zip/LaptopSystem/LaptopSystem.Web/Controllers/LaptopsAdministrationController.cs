﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using LaptopSystem.Models;
using LaptopSystem.Data;

namespace LaptopSystem.Web.Controllers
{
    public class LaptopsAdministrationController : BaseController
    {
        public ActionResult Index()
        {
            var laptops = this.Data.Laptops.All();
            return View(laptops);
        }

        public ActionResult Details(int id)
        {
            Laptop laptop = this.Data.Laptops.GetById(id);
            if (laptop == null)
            {
                return HttpNotFound();
            }

            return View(laptop);
        }

        public ActionResult Create()
        {
            ViewBag.ManufacturerId = new SelectList(this.Data.Manufacturers.All(), "Id", "Name");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Laptop laptop)
        {
            if (ModelState.IsValid)
            {
                this.Data.Laptops.Add(laptop);
                this.Data.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ManufacturerId = new SelectList(this.Data.Manufacturers.All(), "Id", "Name", laptop.ManufacturerId);
            return View(laptop);
        }

        public ActionResult Edit(int id)
        {
            Laptop laptop = this.Data.Laptops.GetById(id);
            if (laptop == null)
            {
                return HttpNotFound();
            }

            ViewBag.ManufacturerId = new SelectList(this.Data.Manufacturers.All(), "Id", "Name", laptop.ManufacturerId);
            return View(laptop);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Laptop laptop)
        {
            if (ModelState.IsValid)
            {
                this.Data.Laptops.Update(laptop);
                this.Data.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ManufacturerId = new SelectList(this.Data.Manufacturers.All(), "Id", "Name", laptop.ManufacturerId);
            return View(laptop);
        }

        public ActionResult Delete(int id)
        {
            Laptop laptop = this.Data.Laptops.GetById(id);
            if (laptop == null)
            {
                return HttpNotFound();
            }

            return View(laptop);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Laptop laptop = this.Data.Laptops.GetById(id);
            this.Data.Laptops.Delete(laptop);
            this.Data.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}

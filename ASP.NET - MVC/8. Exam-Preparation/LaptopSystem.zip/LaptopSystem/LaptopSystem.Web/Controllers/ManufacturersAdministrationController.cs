﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using LaptopSystem.Models;
using LaptopSystem.Data;

namespace LaptopSystem.Web.Controllers
{
    [Authorize(Roles="Admin")]
    public class ManufacturersAdministrationController : BaseController
    {
        public ActionResult Index()
        {
            return View(this.Data.Manufacturers.All());
        }

        public ActionResult Details(int id)
        {
            Manufacturer manufacturer = this.Data.Manufacturers.GetById(id);
            if (manufacturer == null)
            {
                return HttpNotFound();
            }

            return View(manufacturer);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Manufacturer manufacturer)
        {
            bool nameIsUnique = !(this.Data.Manufacturers.All().
                Any(m => m.Name.ToLower().Contains(manufacturer.Name.ToLower())));
            if (!nameIsUnique)
            {
                ModelState.AddModelError("Name", "Name already exists.");
            }

            if (ModelState.IsValid)
            {
                this.Data.Manufacturers.Add(manufacturer);
                this.Data.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(manufacturer);
        }

        public ActionResult Edit(int id)
        {
            Manufacturer manufacturer = this.Data.Manufacturers.GetById(id);
            if (manufacturer == null)
            {
                return HttpNotFound();
            }

            return View(manufacturer);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Manufacturer manufacturer)
        {
            bool nameIsUnique = !(this.Data.Manufacturers.All().
                Any(m => m.Name.ToLower().Contains(manufacturer.Name.ToLower())));
            if (!nameIsUnique)
            {
                ModelState.AddModelError("Name", "Name already exists.");
            }

            if (ModelState.IsValid && nameIsUnique)
            {
                this.Data.Manufacturers.Update(manufacturer);
                this.Data.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(manufacturer);
        }

        public ActionResult Delete(int id)
        {
            Manufacturer manufacturer = this.Data.Manufacturers.GetById(id);
            if (manufacturer == null)
            {
                return HttpNotFound();
            }

            return View(manufacturer);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Manufacturer manufacturer = this.Data.Manufacturers.GetById(id);
            foreach (var laptop in manufacturer.Laptops.ToList())
            {
                foreach (var comment in laptop.Comments.ToList())
                {
                    this.Data.Comments.Delete(comment);
                }

                foreach (var vote in laptop.Votes.ToList())
                {
                    this.Data.Votes.Delete(vote);
                }

                this.Data.Laptops.Delete(laptop);
            }

            this.Data.Manufacturers.Delete(manufacturer);
            this.Data.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}

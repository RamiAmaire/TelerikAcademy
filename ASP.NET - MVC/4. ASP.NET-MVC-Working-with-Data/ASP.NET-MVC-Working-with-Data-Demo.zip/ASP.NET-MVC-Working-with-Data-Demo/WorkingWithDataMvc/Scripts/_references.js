﻿/// <reference path="jquery-2.0.3.js" />
/// <autosync enabled="true" />
/// <reference path="modernizr-2.6.2.js" />
/// <reference path="bootstrap.js" />

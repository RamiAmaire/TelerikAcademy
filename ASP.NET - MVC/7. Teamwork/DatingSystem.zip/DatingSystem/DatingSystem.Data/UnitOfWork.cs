﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatingSystem.Models;
using Microsoft.AspNet.Identity.EntityFramework;

namespace DatingSystem.Data
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly DataContext context;
        private readonly Dictionary<Type, object> repositories = new Dictionary<Type, object>();

        public UnitOfWork()
            : this(new DataContext())
        {
        }

        public UnitOfWork(DataContext context)
        {
            this.context = context;
        }



        public IRepository<FriendRequest> FriendRequests
        {
            get
            {
                return this.GetRepository<FriendRequest>();
            }
        }

        public IRepository<GalleryImage> GalleryImages
        {
            get
            {
                return this.GetRepository<GalleryImage>();
            }
        }

        public IRepository<ApplicationUser> Users
        {
            get
            {
                return this.GetRepository<ApplicationUser>();
            }
        }

        public IRepository<UserLogin> UsersLogins
        {
            get
            {
                return this.GetRepository<UserLogin>();
            }
        }

        public IRepository<UserManagement> UserManagement
        {
            get
            {
                return this.GetRepository<UserManagement>();
            }
        }

        public IRepository<Message> Messages
        {
            get
            {
                return this.GetRepository<Message>();
            }
        }

        public IRepository<Friendship> Friendships
        {
            get
            {
                return this.GetRepository<Friendship>();
            }
        }

        public IRepository<Notification> Notifications
        {
            get
            {
                return this.GetRepository<Notification>();
            }
        }

        private IRepository<T> GetRepository<T>() where T : class
        {
            if (!this.repositories.ContainsKey(typeof(T)))
            {
                var type = typeof(GenericRepository<T>);

                this.repositories.Add(typeof(T), Activator.CreateInstance(type, this.context));
            }

            return (IRepository<T>)this.repositories[typeof(T)];
        }

        public int SaveChanges()
        {
            return this.context.SaveChanges();
        }

        public void Dispose()
        {
            this.context.Dispose();
        }
    }
}

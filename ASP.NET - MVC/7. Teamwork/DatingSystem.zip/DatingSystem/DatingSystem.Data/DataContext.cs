﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatingSystem.Data.Migrations;
using DatingSystem.Models;
using Microsoft.AspNet.Identity.EntityFramework;

namespace DatingSystem.Data
{
    public class DataContext : IdentityDbContextWithCustomUser<ApplicationUser>
    {
        public DbSet<GalleryImage> GalleryImages { get; set; }

        public DbSet<Notification> Notifications { get; set; }

        public DbSet<Message> Messages { get; set; }

        public DbSet<FriendRequest> FriendRequests { get; set; }

        public DbSet<Friendship> FriendShips { get; set; }
    }
}

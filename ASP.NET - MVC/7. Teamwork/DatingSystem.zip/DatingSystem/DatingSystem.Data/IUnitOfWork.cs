﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatingSystem.Models;
using Microsoft.AspNet.Identity.EntityFramework;

namespace DatingSystem.Data
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<Message> Messages { get; }

        IRepository<GalleryImage> GalleryImages { get; }

        IRepository<FriendRequest> FriendRequests { get; }

        IRepository<Notification> Notifications { get; }

        IRepository<ApplicationUser> Users { get; }

        IRepository<UserLogin> UsersLogins { get; }

        IRepository<UserManagement> UserManagement { get; }

        IRepository<Friendship> Friendships { get; }


        int SaveChanges();
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DatingSystem.Models
{
    public class NameNoSpecialSignsRestriction : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            string valueAsString = value as string;
            if (valueAsString == null)
            {
                return true;
            }

            if (Regex.IsMatch(valueAsString, @"^[a-zA-Z -]*$"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity.EntityFramework;

namespace DatingSystem.Models
{
    public class ApplicationUser: User
    {
        public ApplicationUser()
        {
            this.Age = 18;
            this.Town = "Sofia";

            this.Friends = new HashSet<ApplicationUser>();
            this.Notifications = new HashSet<Notification>();
            this.FriendRequests = new HashSet<FriendRequest>();
            this.Messages = new HashSet<Message>();
        }

        public enum SexType
        {
            Undefined = 0,
            Male = 1,
            Female = 2
        }

        public Byte[] ProfilePicture { get; set; }

        public virtual ICollection<ApplicationUser> Friends { get; set; }

        public virtual ICollection<Notification> Notifications { get; set; }

        public virtual ICollection<FriendRequest> FriendRequests { get; set; }

        public virtual ICollection<Message> Messages { get; set; }

        [MinLength(2)]
        [MaxLength(20)]
        [NameNoSpecialSignsRestriction
            (ErrorMessage = "First Name should contain only latin letters.")]
        public string FirstName { get; set; }

        [MinLength(2)]
        [MaxLength(20)]
        [NameNoSpecialSignsRestriction
            (ErrorMessage = "Last Name should contain only latin letters.")]
        public string LastName { get; set; }

        [Range(18,100)]
        public int Age { get; set; }

        [MinLength(2)]
        [MaxLength(20)]
        [NameNoSpecialSignsRestriction
            (ErrorMessage="Town name should contain only latin letters.")]
        public string Town { get; set; }

        public SexType Sex { get; set; }

        public SexType LookingFor { get; set; }

        [MaxLength(300)]
        [DescriptionSpecialSignsRestriction
            (ErrorMessage="About description should not contain special characters")]
        public string About { get; set; }

        public DateTime? RegistrationDate { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatingSystem.Models
{
    public class GalleryImage
    {
        public int Id { get; set; }

        public virtual ApplicationUser Owner { get; set; }

        [Required]
        public string Name { get; set; }

        public byte[] Data { get; set; }
    }
}

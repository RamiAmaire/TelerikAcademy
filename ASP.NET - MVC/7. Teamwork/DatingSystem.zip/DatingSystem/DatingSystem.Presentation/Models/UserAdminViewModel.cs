﻿using DatingSystem.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;

namespace DatingSystem.Presentation.Models
{
    public class UserAdminViewModel
    {
        public static Expression<Func<ApplicationUser, UserAdminViewModel>> FromApplicationUser
        {
            get
            {
                return user => new UserAdminViewModel
                {
                    Id = user.Id,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Town = user.Town,
                    Sex = user.Sex,
                    LookingFor = user.LookingFor,
                    About = user.About,
                    RegistrationDate = user.RegistrationDate
                };
            }
        }

        [ScaffoldColumn(false)]
        public string Id { get; set; }

        [Required, MinLength(4), MaxLength(20)]
        public string FirstName { get; set; }

        [Required, MinLength(4), MaxLength(20)]
        public string LastName { get; set; }

        [Required, MinLength(4), MaxLength(20)]
        public string Town { get; set; }

        [Required]
        [UIHint("SexEditor")]
        public DatingSystem.Models.ApplicationUser.SexType Sex { get; set; }

        [Required]
        [UIHint("SexEditor")]
        public DatingSystem.Models.ApplicationUser.SexType LookingFor { get; set; }

        public string About { get; set; }

        [Required]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? RegistrationDate { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using SignalRChat.Common;
using System.Collections.Concurrent;
using DatingSystem.Data;

namespace SignalRChat.Hubs
{
    public class ChatHub : Hub
    {
        #region Data Members

        static ConcurrentDictionary<string, string> ConnectedUsers = new ConcurrentDictionary<string, string>();
        static ConcurrentQueue<MessageDetail> CurrentMessages = new ConcurrentQueue<MessageDetail>();
        //static List<UserDetail> ConnectedUsers = new List<UserDetail>();
        //static List<MessageDetail> CurrentMessages = new List<MessageDetail>();

        #endregion

        #region Methods

        public void Connect(string userName)
        {
            userName = Context.User.Identity.Name;

            var id = Context.ConnectionId;

            if (userName.Length > 0 && ConnectedUsers.Count(x => x.Value == id) == 0 && ConnectedUsers.Count(x => x.Key == userName) == 0)
            {
                userName = Context.User.Identity.Name;
                ConnectedUsers.AddOrUpdate(userName, id, (p, q) => id);

                var db = new UnitOfWork();
                var currentUser = db.Users.All().FirstOrDefault(x => x.UserName == userName);

                //Send notification to all online friends
                //string friendconnectionId;
                //foreach (var friend in currentUser.Friends)
                //{
                //    if (ConnectedUsers.ContainsKey(friend.UserName))
                //    {
                //        friendconnectionId = ConnectedUsers[friend.UserName];
                //        Clients.Client(friendconnectionId).onNewUserConnected(id, userName);
                //    }
                //}

                // send to caller
                Clients.Caller.onConnected(
                    id,
                    userName,
                    ConnectedUsers.Select(
                    x => new UserDetail
                    {
                        UserName = x.Key,
                        ConnectionId = x.Value
                    }),
                    CurrentMessages.ToList<MessageDetail>());

                // send to all except caller client
                Clients.AllExcept(id).onNewUserConnected(id, userName);
            }

        }

        public void SendMessageToAll(string userName, string message)
        {
            // store last 100 messages in cache
            AddMessageinCache(userName, message);

            // Broad cast message
            Clients.All.messageReceived(userName, message);
        }

        public void SendPrivateMessage(string toUserId, string message)
        {
            string fromUserId = Context.ConnectionId;

            var toUser = ConnectedUsers.FirstOrDefault(x => x.Value == toUserId).Key;
            var fromUser = ConnectedUsers.FirstOrDefault(x => x.Value == fromUserId).Key;

            if (toUser != null && fromUser != null)
            {
                // send to 
                Clients.Client(toUserId).sendPrivateMessage(fromUserId, fromUser, message);

                // send to caller user
                Clients.Caller.sendPrivateMessage(toUserId, fromUser, message);
            }
        }

        public override System.Threading.Tasks.Task OnDisconnected()
        {
            var item = ConnectedUsers.FirstOrDefault(x => x.Value == Context.ConnectionId).Key;
            if (item != null && item.Length > 0)
            {
                string deleteConnectionId;
                //ConnectedUsers.TryTake(out item);
                ConnectedUsers.TryRemove(item, out deleteConnectionId);

                var id = Context.ConnectionId;
                Clients.All.onUserDisconnected(id, item);

            }

            return base.OnDisconnected();
        }


        #endregion

        #region private Messages

        private void AddMessageinCache(string userName, string message)
        {
            CurrentMessages.Enqueue(new MessageDetail { UserName = userName, Message = message });

            //CurrentMessages.Add(new MessageDetail { UserName = userName, Message = message });


            if (CurrentMessages.Count > 100)
            {
                //CurrentMessages.RemoveAt(0);

                var deleteMessage = new MessageDetail();
                while (!CurrentMessages.TryDequeue(out deleteMessage)) ;
            }
        }

        #endregion
    }
}
﻿using DatingSystem.Models;
using System;
using System.Linq.Expressions;

namespace DatingSystem.Presentation.Models
{
    public class SearchResultViewModel
    {
        public string Id { get; set; }

        public string UserName { get; set; }

        public string Town { get; set; }

        public int Age { get; set; }

        public string ProfileUrl { get; set; }

        public string ImageUrl { get; set; }
    }
}
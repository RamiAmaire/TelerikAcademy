﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DatingSystem.Models;

namespace DatingSystem.Presentation.Models
{
    public class ProfileFullViewModel
    {
        public string Id { get; set; }

        public string Username { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int Age { get; set; }

        public string Town { get; set; }

        public ApplicationUser.SexType Sex { get; set; }

        public ApplicationUser.SexType LookingFor { get; set; }

        public string About { get; set; }

        public IEnumerable<GalleryImageViewModel> Gallery { get; set; }

        public int RelationWithCurrentUser { get; set; }
    }
}
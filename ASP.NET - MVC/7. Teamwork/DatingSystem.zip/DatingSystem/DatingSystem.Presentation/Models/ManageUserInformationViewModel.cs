﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using DatingSystem.Models;
using DatingSystem.Presentation.Common;


namespace DatingSystem.Presentation.Models
{
    public class ManageUserInformationViewModel
    {
        public byte[] ProfilePicture { get; set; }

        [Required(ErrorMessage = "First Name is required!")]
        [DisplayName("First Name")]
        [StringLength(33, MinimumLength = 2, ErrorMessage = "Lenght must be between {1} and {2} symbols")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required!")]
        [DisplayName("Last Name")]
        [StringLength(33, MinimumLength = 2, ErrorMessage = "Lenght must be between {1} and {2} symbols")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please write down your age")]
        [ValidateLegitimeAge(18,120)]
        public int Age { get; set; }

        [StringLength(50)]
        public string Town { get; set; }

        public ApplicationUser.SexType Sex { get; set; }

        public ApplicationUser.SexType LookingFor { get; set; }

        [StringLength(250,MinimumLength = 5)]
        public string About { get; set; }
    }
}
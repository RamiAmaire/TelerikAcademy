﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DatingSystem.Presentation.Models
{
    public class GalleryImageViewModel
    {
        public string Name { get; set; }
        public string ImageSrc { get; set; }
        public int ImageId { get; set; }

        public byte[] ImageRaw { get; set; }

        public string ImageConvertedSrc
        {
            get
            {
                if (ImageRaw == null)
                {
                    return null;
                }

                return string.Format("data:image/gif;base64,{0}", Convert.ToBase64String(ImageRaw));
            }
        }
    }
}
﻿using System;

namespace DatingSystem.Presentation.Models
{
    public class SearchViewModel
    {
        public string UserNameSearch { get; set; }

        public string SexSearch { get; set; }

        public int MinimumAgeSearch { get; set; }

        public int MaximumAgeSearch { get; set; }
    }
}
﻿using System;

namespace DatingSystem.Presentation.Models
{
    public class SearchResultModel
    {
        public string Id { get; set; }

        public string UserName { get; set; }
    }
}
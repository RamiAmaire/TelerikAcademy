﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(DatingSystem.Presentation.Startup))]
namespace DatingSystem.Presentation
{
    public partial class Startup 
    {
        public void Configuration(IAppBuilder app) 
        {
            ConfigureAuth(app);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DatingSystem.Presentation.Common
{
    public class ValidateLegitimeAgeAttribute:ValidationAttribute
    {
        private int _minAge;
        private int _maxAge;
        public ValidateLegitimeAgeAttribute(int minAge, int maxAge)
        {
            this._minAge = minAge;
            this._maxAge = maxAge;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {

            var passedValue = value as int?;

            if (passedValue > _maxAge)
            {
                var error = "you are too old for this site";
                return new ValidationResult(error);
            }

            if (passedValue < _minAge)
            {
                var error = "you are too young for this site";
                return new ValidationResult(error);
            }

            return ValidationResult.Success;
        }
    }
}
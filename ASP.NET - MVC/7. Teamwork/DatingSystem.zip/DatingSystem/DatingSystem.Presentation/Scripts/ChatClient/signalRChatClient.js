﻿$(function () {
        // Declare a proxy to reference the hub.
        var chatHub = $.connection.chatHub;

        registerClientMethods(chatHub);

        // Start Hub
        $.connection.hub.start().done(function () {

            registerEvents(chatHub);
            chatHub.server.connect("name");

        });


    });

function registerEvents(chatHub) {


    $('#btnSendMsg').click(function () {

        var msg = $("#txtMessage").val();
        if (msg.length > 0) {

            var userName = $('#hdUserName').val();
            chatHub.server.sendMessageToAll(userName, msg);
            $("#txtMessage").val('');
        }
    });


    $("#txtNickName").keypress(function (e) {
        if (e.which == 13) {
            $("#btnStartChat").click();
        }
    });

    $("#txtMessage").keypress(function (e) {
        if (e.which == 13) {
            $('#btnSendMsg').click();
        }
    });


}

function registerClientMethods(chatHub) {

    // Calls when user successfully logged in
    chatHub.client.onConnected = function (id, userName, allUsers, messages) {

        $('#hdId').val(id);
        $('#hdUserName').val(userName);
        $('#spanUser').html(userName);

        console.log(allUsers);
        console.log(messages);
        // Add All Users
        for (i = 0; i < allUsers.length; i++) {

            AddUser(chatHub, allUsers[i].ConnectionId, allUsers[i].UserName);
        }

        // Add Existing Messages
        for (i = 0; i < messages.length; i++) {
            AddMessage(messages[i].UserName, messages[i].Message);
        }
    }

    // On New User Connected
    chatHub.client.onNewUserConnected = function (id, name) {
        AddUser(chatHub, id, name);
            
        //show message for new friend coming online
        var connectedUserDiv = $('<div class="connecteduser">"' + name + '" logged in!</div>');
        $(connectedUserDiv).hide();
        $('#divusers').prepend(connectedUserDiv);
        $(connectedUserDiv).fadeIn(200).delay(2000).fadeOut(200);
    }


    // On User Disconnected
    chatHub.client.onUserDisconnected = function (id, userName) {

        $('#' + id).remove();

        var ctrId = 'private_' + id;
        if ($('#' + ctrId).parent().hasClass("k-window")) {
            $('#' + ctrId).data("kendoWindow").destroy();
        }
        else {
            $('#' + ctrId).remove();
        }


        var disc = $('<div class="disconnect">"' + userName + '" logged off.</div>');

        $(disc).hide();
        $('#divusers').prepend(disc);
        $(disc).fadeIn(200).delay(2000).fadeOut(200);

    }

    chatHub.client.messageReceived = function (userName, message) {

        AddMessage(userName, message);
    }


    //Sending messages
    chatHub.client.sendPrivateMessage = function (windowId, fromUserName, message) {

        console.log($("#newMessage-image-path").val());
        var ctrId = 'private_' + windowId;


        if ($('#' + ctrId).length == 0) {
            createPrivateChatContents(chatHub, windowId, ctrId, fromUserName);
        }

        $('#' + ctrId).find('#divMessage').append('<div class="message">'
            + '[' + (new Date()).toLocaleTimeString() + '] '
            + '<span class="userName">' + fromUserName + '</span>: '
            + '<span id="chatMessage"></span></div>');

        //If the chat window is no visible, show reminder icon
        if (!($('#' + ctrId).is(':visible'))) {
            $('#msgImg_' + windowId).show();
        }

        //chat character escaping
        $('#' + ctrId + ' .message:last-child #chatMessage').text(message).html();

        // set scrollbar
        var height = $('#' + ctrId).find('#divMessage')[0].scrollHeight;
        $('#' + ctrId).find('#divMessage').scrollTop(height);

    }

}

//Add new user to list
function AddUser(chatHub, id, name) {

    var userId = $('#hdId').val();

    var code = "";

    if (userId == id) {

        code = $('<div class="loginUser">' + name + "</div>");

    }
    else {

        code = $('<a id="' + id + '" class="user" >' + name + '<img id="msgImg_' + id + '"  src="' + $("#newMessage-image-path").val() + '" style="display: none; width: 20px; float: right" />' + '<a>'
        );

        $(code).dblclick(function () {

            var id = $(this).attr('id');

            if (userId != id)
                OpenPrivateChatWindow(chatHub, id, name);
            $('#msgImg_' + id).hide();
        });
    }

    $("#divusers").append(code);
}

function AddMessage(userName, message) {
    $('#divChatWindow').append('<div class="message"><span class="userName">' + userName + '</span>: ' + message + '</div>');

    var height = $('#divChatWindow')[0].scrollHeight;
    $('#divChatWindow').scrollTop(height);
}

function OpenPrivateChatWindow(chatHub, id, userName) {
        
    var ctrId = 'private_' + id;

    if ($('#' + ctrId).length > 0) {
        if ($('#' + ctrId).parent().hasClass("k-window")) {
            $('#' + ctrId).data("kendoWindow").open();
        } else {
            CreateNewWindow($('#' + ctrId), userName);
        }
        return;
    }

    createPrivateChatContents(chatHub, id, ctrId, userName);
    CreateNewWindow($('#' + ctrId), userName);
}

function createPrivateChatContents(chatHub, userId, ctrId, userName) {

    var div = '<div id="' + ctrId + '" rel="0" style="display:none">' +
                '<div id="divMessage" class="messageArea">' +

                '</div>' +
                '<div class="buttonBar">' +
                  '<div class="send-message-textfield"><input id="txtPrivateMessage" class="msgText k-textbox" type="text"   /></div>' +
                  '<div class="send-message-button"><input id="btnSendMessage" class="submitButton button k-button" type="button" value="Send"   /></div>' +
                '</div>' +
              '</div>';

    var $div = $(div);

    // Send Button event
    $div.find("#btnSendMessage").click(function () {

        $textBox = $div.find("#txtPrivateMessage");
        var msg = $textBox.val();
        if (msg.length > 0) {

            chatHub.server.sendPrivateMessage(userId, msg);
            $textBox.val('');
        }
    });

    // Text Box event
    $div.find("#txtPrivateMessage").keypress(function (e) {
        if (e.which == 13) {
            $div.find("#btnSendMessage").click();
        }
    });

    $('#chatContainer').append($div);

    //CreateNewWindow($div, userName);
}

//Creating new chat window
function CreateNewWindow($div, toUserName) {
    var newdiv = $div;

    if (!newdiv.data("kendoWindow")) {
        newdiv.kendoWindow({
            width: "250px",
            title: toUserName + " chat",
            actions: [
                "Pin",
                "Minimize",
                "Maximize",
                "Close"
            ],
            close: function () {
                console.log("window closed.");
                //$div.remove();
                newdiv.parent().hide();
            }
        });
    }
        
    newdiv.data("kendoWindow").open();
}
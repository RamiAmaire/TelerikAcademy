﻿using DatingSystem.Data;
using DatingSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DatingSystem.Presentation.Models;
using Microsoft.AspNet.Identity;
using Kendo.Mvc.UI;

namespace DatingSystem.Presentation.Controllers
{
    public class HomeController : BaseController
    {

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Profiler(string id)
        {
            return RedirectToAction("Index", "Profile", new { id = id });
        }

        public JsonResult GetUserNames()
        {
            var userNames = this.Data.Users.All().
                Select(u => new { Id = u.Id, UserName = u.UserName }).Distinct().ToList();
            return Json(userNames, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetSexes()
        {
            var sexes = new List<SexViewModel>()
            {
                new SexViewModel{Id = 0, Name = "All"},
                new SexViewModel{Id = 1, Name = "Male"},
                new SexViewModel{Id = 2, Name = "Female"},
            };

            return Json(sexes, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Search([DataSourceRequest] DataSourceRequest request, SearchViewModel model)
        {
            var users = this.Data.Users.All();
            if (!string.IsNullOrEmpty(model.UserNameSearch))
            {
                users = users.Where(u => u.UserName.ToLower().Contains(model.UserNameSearch.ToLower()));
            }

            if (model.SexSearch != "All")
            {
                int sexValue;
                if (model.SexSearch == "Male")
                {
                    sexValue = 1;
                }
                else
                {
                    sexValue = 2;
                }

                users = users.Where(u => (int)u.Sex == sexValue);
            }

            if (model.MinimumAgeSearch != 0)
            {
                users = users.Where(u => u.Age >= model.MinimumAgeSearch);
            }

            if (model.MaximumAgeSearch > model.MinimumAgeSearch)
            {
                users = users.Where(u => u.Age >= model.MinimumAgeSearch && u.Age <= model.MaximumAgeSearch);
            }

            var models = users.Select(u => new SearchResultViewModel
            {
                Age = u.Age,
                Id = u.Id,
                ProfileUrl = "Profiler/" + u.Id,
                Town = u.Town,
                UserName = u.UserName,
                ImageUrl = "http://t3.gstatic.com/images?q=tbn:ANd9GcRhzb_MRUCVyZD60I50m92XhLKYsDJfY3YiZ3RbZq0KKC-W_iuz"
            });

            return View(models);
        }

        #region Chat
        public ActionResult TestChat()
        {
            ViewBag.Message = "Test Chat.";

            ViewBag.Username = User.Identity.Name;

            return View();
        }
        #endregion
    }
}
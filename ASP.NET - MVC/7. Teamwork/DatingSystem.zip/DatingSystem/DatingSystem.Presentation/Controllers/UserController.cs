﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DatingSystem.Data;
using DatingSystem.Models;
using DatingSystem.Presentation.Models;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;
using Microsoft.Ajax.Utilities;
using Microsoft.AspNet.Identity;
using System.Web.Script.Serialization;
using System.Text.RegularExpressions;

namespace DatingSystem.Presentation.Controllers
{
    public class UserController : BaseController
    {
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UploadPhoto(string id)
        {
            var message = "User not specified in request.";
            if (id != null)
            {
                var user = this.Data.Users.All().FirstOrDefault(u => u.Id == id);
                message = "User not found in database";
                if (user != null)
                {
                    var file = Request.Files.Get("image-file-upload");
                    message = "No file in the request";
                    if (file != null && file.FileName.EndsWith(".jpg") || file.FileName.EndsWith(".png"))
                    {
                        var bytes = new byte[file.ContentLength];
                        //TODO - add check of first 8 bytes to make sure it's image file.
                        file.InputStream.Read(bytes, 0, file.ContentLength);
                        user.ProfilePicture = bytes;
                        ViewBag.ProfilePic = bytes;
                        this.Data.SaveChanges();
                        return Json(new { Message = "<span class='text-info'>Updated!</span>" });
                    }
                    else
                    {
                        if (file != null)
                        {
                            message = "File must be jpg or png";
                        }
                    }
                }
            }

            return Content("<span class='text-error'>" + message + " </span>");
        }

        [Authorize]
        public ActionResult SaveAvatar(HttpPostedFileBase files)
        {
            byte[] data;
            var currentUsername = User.Identity.GetUserName();
            var currentUser = Data.Users.All()
                .FirstOrDefault(x => x.UserName == currentUsername);

            using (Stream inputStream = files.InputStream)
            {
                MemoryStream memoryStream = inputStream as MemoryStream;
                if (memoryStream == null)
                {
                    memoryStream = new MemoryStream();
                    inputStream.CopyTo(memoryStream);
                }
                currentUser.ProfilePicture = memoryStream.ToArray();
                Data.SaveChanges();
            }



            return Content("");
        }

        [Authorize]
        public ActionResult ShowUserImage(string id)
        {
            var currentUsername = User.Identity.GetUserName();
            var currentUser = Data.Users.All()
                .FirstOrDefault(x => x.UserName == currentUsername);
            var imageData = currentUser.ProfilePicture;

            if (id != null)
            {
                var anotherUser = Data.Users.All()
                .FirstOrDefault(x => x.Id == id);
                imageData = anotherUser.ProfilePicture;
            }

            if (imageData != null)
            {
                return File(imageData, "image/jpg");
            }
            else
            {
                return base.File("~/img/default-avatar.png", "image/jpg");
            }

        }

        [HttpGet]
        public ActionResult Manage()
        {
            var currentUserName = User.Identity.GetUserName();
            var u = Data.Users.All().FirstOrDefault(x => x.UserName == currentUserName);

            var model = new ManageUserInformationViewModel()
            {
                Age = u.Age,
                FirstName = u.FirstName,
                LastName = u.LastName,
                About = u.About,
                Sex = u.Sex,
                LookingFor = u.LookingFor,
                Town = u.Town
            };
            if (model != null)
            {
                return View("Index", model);
            }
            return View("Index");
        }

        [HttpPost]
        public ActionResult Manage(ManageUserInformationViewModel user)
        {

            //var currentUser = User.Identity.GetUserName();
            //var currentUSerRegistrationDate = Data.Users.All().First(x => x.UserName == currentUser).RegistrationDate;
            if (ModelState.IsValid)
            {
                var userToUpdate = new ApplicationUser()
                {
                    Id = User.Identity.GetUserId(),
                    UserName = User.Identity.GetUserName(),
                    Age = user.Age,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Sex = user.Sex,
                    Town = user.Town,
                    RegistrationDate = DateTime.Now,
                    LookingFor = user.LookingFor,
                    About = user.About
                };

                Data.Users.Update(userToUpdate);
                Data.SaveChanges();

                return RedirectToAction("Index", "Home");
            }

            return View("Index", user);

        }
    }
}
using System.Drawing;
using System.IO;
using DatingSystem.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DatingSystem.Models;
using DatingSystem.Presentation.Models;
using Microsoft.AspNet.Identity;
using System.Web.Security;
using System.Text.RegularExpressions;
using Kendo.Mvc.UI;
using Kendo.Mvc.Extensions;

namespace DatingSystem.Presentation.Controllers
{
    public class ProfileController : BaseController
    {
        //
        // GET: /Profile/
        public ActionResult Index(string id)
        {
            int relationWithCurrentUser = GetRelationBetween(User.Identity.GetUserId(), id);

            var user = Data.Users.All().FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                //return RedirectToAction("Index", "User", new {id = id});
                var currenUserId = User.Identity.GetUserId();
                user = Data.Users.All().FirstOrDefault(u => u.Id == currenUserId);

                relationWithCurrentUser = 0;
            }

            var profileFullModel = new ProfileFullViewModel()
            {
                Username = user.UserName,
                Id= user.Id,
                Age = user.Age,
                About = user.About,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Sex = user.Sex,
                LookingFor = user.LookingFor,
                Town = user.Town,
                Gallery = ShowUserGallery(user.Id),
                RelationWithCurrentUser = relationWithCurrentUser
            };

            return View(profileFullModel);
        }

        public IEnumerable<GalleryImageViewModel> ShowUserGallery(string userId)
        {
            return GetGalleryImages(userId);
        }

        [Authorize]
        //Sending Friend Requests
        public ActionResult SendInvitation(string id)
        {
            ApplicationUser currentUser = Data.Users.All().Single(u => u.UserName == User.Identity.Name);

            var targetUser = Data.Users.All().FirstOrDefault(u => u.Id == id);
            if (targetUser.UserName != currentUser.UserName)
            {
                if (targetUser.Friends.Where(f => f.UserName == currentUser.UserName).Count() == 0)
                {
                    targetUser.Notifications.Add(new Notification
                    {
                        Text = String.Format("{0} wants to be friend with you!",
                        currentUser.UserName),
                        Date = DateTime.Now,
                        sendBy = currentUser.Id
                    });
                    Data.SaveChanges();
                }
            }

            this.Data.Friendships.Add(new Friendship { FromPersonId = User.Identity.GetUserId(), ToPersonId = id});
            Data.SaveChanges();

            return RedirectToAction("MyFriends", "Profile");
        }

        [Authorize]
        //Approving Friend requests
        public ActionResult ApproveFriendship(string id)
        {
            this.Data.Friendships.Add(new Friendship { FromPersonId = id, ToPersonId = User.Identity.GetUserId() });
            Data.SaveChanges();

            return RedirectToAction("MyFriends", "Profile");
        }

        public ActionResult MyFriends()
        {
            var userId = User.Identity.GetUserId();
            var user = Data.Users.All()
                .FirstOrDefault(x => x.Id == userId);

            if (user == null)
            {
                return Content("Error!!!");
            }

            var myFriends = Data.Friendships.All()
                .Where(w => w.ToPersonId == userId)
                .Select(x => x.FromPerson).ToList();

            List<FriendViewModel> friendViewModels = new List<FriendViewModel>();

            foreach (var otherUser in myFriends)
            {
                friendViewModels.Add(new FriendViewModel
                {
                    Id = otherUser.Id,
                    UserName = otherUser.UserName,
                    Town = otherUser.Town,
                    FirstName = otherUser.FirstName,
                    LastName = otherUser.LastName
                });
            }

            return View(friendViewModels);
        }

        //make everybody my frind if not already
        public ActionResult MakeMeFamous()
        {
            var username = User.Identity.Name;
            var user = Data.Users.All()
                .FirstOrDefault(x => x.UserName == username);

            var allOthers = Data.Users.All().Where(x => x.UserName != username);

            foreach (var otherUser in allOthers)
            {
                if (Data.Friendships.All().FirstOrDefault(x => x.FromPersonId == otherUser.Id && x.ToPersonId == user.Id) == null)
                {
                    Friendship newFriendShipLeft = new Friendship { FromPerson = otherUser, ToPerson = user };
                    Data.Friendships.Add(newFriendShipLeft);
                }

                if (Data.Friendships.All().FirstOrDefault(x => x.FromPersonId == user.Id && x.ToPersonId == otherUser.Id) == null)
                {
                    Friendship newFriendShipRight = new Friendship { FromPerson = user, ToPerson = otherUser };
                    Data.Friendships.Add(newFriendShipRight);
                }
            }

            Data.SaveChanges();

            return RedirectToAction("MyFriends");
        }

        [Authorize]
        public ActionResult MakeMeAdmin()
        {
            var currentUser = this.Data.Users.All().FirstOrDefault();

            if (!User.IsInRole("Admin"))
            {
                Roles.AddUserToRole(User.Identity.GetUserName(), "Admin");
            }

            return RedirectToAction("Index");
        }


        public int GetRelationBetween(string userId, string anotherUserId)
        {
            if (userId == null || anotherUserId == null || userId == anotherUserId)
            {
                return 0;
            }

            var leftFriend = this.Data.Friendships.All().FirstOrDefault(x => x.FromPersonId == userId && x.ToPersonId == anotherUserId);

            var rightFriend = this.Data.Friendships.All().FirstOrDefault(x => x.FromPersonId == anotherUserId && x.ToPersonId == userId);

            if (leftFriend != null && rightFriend != null)
            {
                return 3;
            }
            else
            {
                if (leftFriend != null && rightFriend == null)
                {
                    return 1;
                }
                else
                {
                    if (leftFriend == null && rightFriend != null)
                    {
                        return 2;
                    }
                    else
                    {
                        return 4;
                    }
                }
            }
        }


        public ActionResult GalleryImages_Read([DataSourceRequest] DataSourceRequest request, string id)
        {
            //return Json(GetGalleryImages(null).ToDataSourceResult(request));

            var jsonResult = Json(GetGalleryImages(id).ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
            jsonResult.MaxJsonLength = int.MaxValue;
            return jsonResult;
        }

        public IEnumerable<GalleryImageViewModel> GetGalleryImages(string userId)
        {
            if (String.IsNullOrEmpty(userId))
            {
                userId = User.Identity.GetUserId();
            }

            var currentUserImageGallery = Data.GalleryImages.All().Where(x => x.Owner.Id == userId);

            if (currentUserImageGallery != null)
            {
                List<GalleryImageViewModel> resultImageViewModels = new List<GalleryImageViewModel>();



                string strPath = Server.MapPath("~");
                string userImagesFolderPath = strPath + "/App_Data/TempImages/" + userId;
                System.IO.Directory.CreateDirectory(userImagesFolderPath);

                foreach (var imageRaw in currentUserImageGallery)
                {
                    string newImagePath = userImagesFolderPath + "/" + imageRaw.Name;

                    //System.IO.File.WriteAllBytes(newImagePath, imageRaw.Data);

                    MemoryStream ms = new MemoryStream(imageRaw.Data);
                    Image returnImage = Image.FromStream(ms);
                    returnImage.Save(newImagePath);

                    resultImageViewModels.Add(new GalleryImageViewModel
                    {
                        ImageId = imageRaw.Id,
                        Name = imageRaw.Name,
                        ImageSrc = string.Format("data:image/gif;base64,{0}", Convert.ToBase64String(imageRaw.Data)),
                        //ImageData = imageRaw.Data
                    });
                }
                return resultImageViewModels;
            }

            else
            {
                return new List<GalleryImageViewModel>().AsQueryable();
            }
        }

        //public ActionResult GetImageDataResult(int imageId)
        //{
        //    var dbImage = Data.GalleryImages.All().FirstOrDefault(x => x.Id == imageId);

        //    if (dbImage == null)
        //    {
        //        return null;
        //    }
        //    else
        //    {
        //        return File(dbImage.Data, "image/jpg");
        //    }
        //}


        //Uploading Images to user gallery
        [Authorize]
        public ActionResult UploadGalleryImages(string id)
        {
            var message = "User not specified in request.";
            if (id != null)
            {
                var user = this.Data.Users.All().FirstOrDefault(u => u.Id == id);

                message = "User not found in database";
                if (user != null)
                {
                    var file = Request.Files.Get("image-file-upload-album");

                    if (isUploadedFileCorrect(file, user.Id, out message))
                    {
                        var bytes = new byte[file.ContentLength];

                        file.InputStream.Read(bytes, 0, file.ContentLength);

                        var NewImage = new GalleryImage()
                        {
                            Data = bytes,
                            Name = file.FileName,
                            Owner = user
                        };

                        Data.GalleryImages.Add(NewImage);
                        this.Data.SaveChanges();

                        message = "Uploaded!";
                        return Json(new { message = message }, "text/plain");
                    }
                }
            }

            return Content(message);
        }

        //Check whether uploaded image is correct
        private bool isUploadedFileCorrect(HttpPostedFileBase inputFile, string userId, out string message)
        {
            var searchanohteFileWithTheSameName =
                Data.GalleryImages.All()
                .Where(x => x.Owner.Id == userId && x.Name == inputFile.FileName)
                .FirstOrDefault();

            if (!Regex.IsMatch(inputFile.FileName, @"^[\w\-._ ]+$"))
            {
                message = "File name is not valid. user only latin letters, numbers and -._ symbols";
                return false;
            }

            if (!(inputFile.FileName.EndsWith(".jpg")
                        || inputFile.FileName.EndsWith(".png")))
            {
                message = "Accepted files are .jpg and .png";
                return false;
            }

            if (searchanohteFileWithTheSameName != null)
            {
                message = "File name " + inputFile.FileName + " already exists.";
                return false;
            }

            if (inputFile == null)
            {
                message = "No file uploaded.";
                return false;
            }

            if (inputFile.ContentLength > 200000)
            {
                message = "File too large. Use files less than 200KB";
                return false;
            }

            message = "File is correct.";
            return true;
        }
    }
}

﻿using DatingSystem.Data;
using Kendo.Mvc.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Kendo.Mvc.Extensions;
using DatingSystem.Presentation.Models;

namespace DatingSystem.Presentation.Controllers
{
    [Authorize(Roles="Admin")]
    public class UserAdministrationController : BaseController
    {

        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetUsers([DataSourceRequest]DataSourceRequest request)
        {
            var users = this.Data.Users.All().Select(UserAdminViewModel.FromApplicationUser);
            return Json(users.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateUser([DataSourceRequest] DataSourceRequest request, UserAdminViewModel user)
        {
            if (user != null && ModelState.IsValid)
            {
                var existingUser = this.Data.Users.All().FirstOrDefault(u => u.Id == user.Id);
                existingUser.FirstName = user.FirstName;
                existingUser.LastName = user.LastName;
                existingUser.Town = user.Town;
                existingUser.Sex = user.Sex;
                existingUser.LookingFor = user.LookingFor;
                this.Data.Users.Update(existingUser);
                this.Data.SaveChanges();
            }

            return Json((new[] { user }.ToDataSourceResult(request, ModelState)), JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteUser([DataSourceRequest]DataSourceRequest request, UserAdminViewModel user)
        {
            var userToDelete = this.Data.Users.All().FirstOrDefault(u => u.Id == user.Id);
            if (userToDelete != null)
            {
                foreach (var userLogin in userToDelete.Logins.ToList())
                {
                    this.Data.UsersLogins.Delete(userLogin);
                }

                this.Data.UserManagement.Delete(userToDelete.Management);
                this.Data.Users.Delete(userToDelete);
                this.Data.SaveChanges();
            }

            return Json(new[] { user }, JsonRequestBehavior.AllowGet);
        }
    }
}
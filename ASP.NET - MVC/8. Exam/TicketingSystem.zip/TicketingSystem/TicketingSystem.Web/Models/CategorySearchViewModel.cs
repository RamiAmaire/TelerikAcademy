﻿using System;

namespace TicketingSystem.Web.Models
{
    public class CategorySearchViewModel
    {
        public string CategorySearch { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Twitter.Models
{
    public class Tag
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Tag title is required.")]
        [StringLength(20, MinimumLength = 2, ErrorMessage = "Tag title should be between {2} and {1} symbols.")]
        public string Title { get; set; }
        public virtual ICollection<Tweet> Twits { get; set; }

        public Tag()
        {
            this.Twits = new HashSet<Tweet>();
        }
    }
}

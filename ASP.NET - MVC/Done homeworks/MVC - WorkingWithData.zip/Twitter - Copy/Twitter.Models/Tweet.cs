﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace Twitter.Models
{
    public class Tweet
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Tweet cannot be empty.")]
        [StringLength(20, MinimumLength = 2, ErrorMessage = "Tweet content should be between {2} and {1} symbols.")]
        public string Content { get; set; }
        [Display(Name = "Owner")]
        public virtual ApplicationUser Onwer { get; set; }
        public virtual ICollection<Tag> Tags { get; set; }

        public Tweet()
        {
            this.Tags = new HashSet<Tag>();
        }
    }
}

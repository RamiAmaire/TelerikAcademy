﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Twitter.Data;
using Twitter.Models;
using Twitter.MVC.ViewModels;

namespace Twitter.MVC.Controllers
{
    [Authorize]
    public class TweetsController : Controller
    {
        IUnitOfWork db;

        public TweetsController(IUnitOfWork db)
        {
            this.db = db;
        }

        public TweetsController()
        {
            db = new UnitOfWork();
        }

        //
        // GET: /Tweets/
        public ActionResult MyTweets()
        {
            var currentUser = User.Identity.Name;
            //var model = db.Users.All().FirstOrDefault(u => u.UserName == currentUser).Tweets.ToList();
            var model = db.Tweets.All().Where(t => t.Onwer.UserName == currentUser).ToList();
            return View(model);
        }


        public ActionResult New(Tweet model)
        {
            if (ModelState.IsValid)
            {
                var currentUser = User.Identity.Name;
                var owner = db.Users.All().FirstOrDefault(u => u.UserName == currentUser);

                string[] modelTags = model.Content.Split(new char[] { ' ' });

                List<Tag> tags = new List<Tag>();

                foreach (var tag in modelTags)
                {
                    Tag checkedTag = db.Tags.All().FirstOrDefault(t => t.Title == tag);

                    if (checkedTag == null)
                    {
                        checkedTag = new Tag()
                       {
                           Title = tag
                       };
                        db.Tags.Add(checkedTag);
                        db.SaveChanges();
                    }

                    tags.Add(checkedTag);
                }

                var newTweet = new Tweet()
                {
                    Onwer = owner,
                    Content = model.Content,
                    Tags = tags
                };

                db.Tweets.Add(newTweet);
                db.SaveChanges();

                foreach (var tag in tags)
                {
                    tag.Twits.Add(newTweet);
                    db.SaveChanges();
                }
                return RedirectToAction("MyTweets");
            }

            return View(model);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Twitter.Data;

namespace Twitter.MVC.Controllers
{
    public class TagsController : Controller
    {
         IUnitOfWork db;

        public TagsController(IUnitOfWork db)
        {
            this.db = db;
        }

        public TagsController()
        {
            db = new UnitOfWork();
        }

        //
        // GET: /Tweets/
        [OutputCache(Duration = 3600)]
        public ActionResult Index(string tag)
        {
            var model = db.Tags.All().Where(t => t.Title == tag).ToList();
            return View(model);
        }
	}
}
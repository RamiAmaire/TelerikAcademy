﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _02.WebCalculator.ViewModels
{
    public class TypeSize
    {
        public string Name { get; set; }
        
        public string Value { get; set; }

        public double Size { get; set; }
    }

}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace _03.SeveralControllersAndStaff
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional },
                //Constraints for Admin Uncomment the row down
                //constraints: new { controller="^Admin.*"},
                namespaces: new[] { "_03.SeveralControllersAndStaff.Controllers" }
            );
        }
    }
}

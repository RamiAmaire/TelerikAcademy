﻿using System.Web.Mvc;

namespace _03.SeveralControllersAndStaff.Areas.LoggedUsers
{
    public class LoggedUsersAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "LoggedUsers";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "LoggedUsers_default",
                "LoggedUsers/{controller}/{action}/{id}",
                new { controller= "Home",action = "Index", id = UrlParameter.Optional },
                namespaces: new[] { "_03.SeveralControllersAndStaff.Areas.LoggedUsers.Controllers" }
            );
        }
    }
}
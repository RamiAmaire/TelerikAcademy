﻿using System;
using System.Collections.Generic;

namespace MovieAppMenual.Models
{
    public class Movie
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Director { get; set; }
        public int Year { get; set; }
        public virtual Actor LeadingMaleRole { get; set; }
        public virtual Actor LeadingFemaleRole { get; set; }
        public string Studio { get; set; }
        public string StudioAdress { get; set; }
    }
}
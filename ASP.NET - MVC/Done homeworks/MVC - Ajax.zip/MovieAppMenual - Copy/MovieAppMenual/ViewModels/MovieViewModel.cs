﻿using Microsoft.Ajax.Utilities;
using MovieAppMenual.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;

namespace MovieAppMenual.ViewModels
{
    public class MovieViewModel
    {
        public static Expression<Func<Movie, MovieViewModel>> FromMovie
        {
            get
            {
                return m => new MovieViewModel()
                {
                    Id = m.Id,
                    Title = m.Title,
                    Director = m.Director,
                    Year = m.Year,
                    LeadingFemaleRole = m.LeadingFemaleRole.Name,
                    LeadingMaleRole = m.LeadingMaleRole.Name,
                    Studio = m.Studio,
                    StudioAdress = m.StudioAdress
                };
            }
        }

        public int Id { get; set; }
        public string Title { get; set; }
        public string Director { get; set; }
        public int Year { get; set; }
        public string LeadingMaleRole { get; set; }
        public string LeadingFemaleRole { get; set; }
        public string Studio { get; set; }
        public string StudioAdress { get; set; }
    }
}
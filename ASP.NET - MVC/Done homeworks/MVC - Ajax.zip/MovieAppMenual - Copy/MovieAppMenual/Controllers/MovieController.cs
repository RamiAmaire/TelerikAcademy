﻿using MovieAppMenual.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MovieAppMenual.ViewModels;

namespace MovieAppMenual.Controllers
{
    public class MovieController : Controller
    {
        //
        // GET: /Movie/
        public ActionResult Index(int? id)
        {

            ApplicationDbContext db = new ApplicationDbContext();

            if (id != null && Request.IsAjaxRequest())
            {
                var ajaxData = db.Movies.FirstOrDefault(m => m.Id == id);
                var partialResult = "<div><h1>Additional Info for " + ajaxData.Title + "</h1>" +
                                    "<p>Year: " + ajaxData.Year + "</p>" +
                                    "<p>Director: " + ajaxData.Director + "</p>" +
                                    "<p>Leading Male Role: " + ajaxData.LeadingMaleRole.Name + "</p>" +
                                    "<p>Leading Female Role: " + ajaxData.LeadingFemaleRole.Name + "</p>" +
                                    "<p>Studio: " + ajaxData.Studio + "</p>" +
                                    "<p>Studio Adress: " + ajaxData.StudioAdress + "</p>" +
                                    "</div> ";
                return Content(partialResult);

            }

            var data = db.Movies.Select(MovieViewModel.FromMovie).ToList();
            return View(data);
        }

        public ActionResult Create()
        {
            return View();
        }

        public ActionResult Add(NewMovieViewModel model)
        {
            //todo new viewModel i da vpadatdsdsy
            //todo is ajaxrequest

            if (model.Title != null && Request.IsAjaxRequest())
            {
                ApplicationDbContext db = new ApplicationDbContext();

                var maleRoleActor = db.Actors.FirstOrDefault(a => a.Name == model.LeadingMaleRole);
                
                if (maleRoleActor == null)
                {
                    maleRoleActor = new Actor()
                    {
                        Age = model.MaleAge,
                        Name = model.LeadingMaleRole
                    };

                    db.Actors.Add(maleRoleActor);
                    db.SaveChanges();
                }

                var femaleRoleActor = db.Actors.FirstOrDefault(a => a.Name == model.LeadingFemaleRole);

                if (femaleRoleActor == null)
                {
                    femaleRoleActor = new Actor()
                    {
                        Age = model.FemaleAge,
                        Name = model.LeadingFemaleRole
                    };

                    db.Actors.Add(femaleRoleActor);
                    db.SaveChanges();
                }

                Movie newMovie = new Movie()
                {
                    Title = model.Title,
                    Director = model.Director,
                    Year = Convert.ToInt32(model.Year),
                    Studio = model.Studio,
                    StudioAdress = model.StudioAddress,
                    LeadingFemaleRole = femaleRoleActor,
                    LeadingMaleRole = maleRoleActor
                };

                db.Movies.Add(newMovie);
                db.SaveChanges();

            }

            return PartialView("_NewMovieForm");
        }

        public ActionResult DeleteAsk(int id)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            Movie movie = db.Movies.FirstOrDefault(m => m.Id == id);
            return PartialView("_DeleteConfirm", movie);
        }

        public ActionResult DeleteConfirmed(int id)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            Movie movie = db.Movies.FirstOrDefault(m => m.Id == id);
            db.Movies.Remove(movie);
            db.SaveChanges();

            var data = db.Movies.Select(MovieViewModel.FromMovie).ToList();
            //return View("Index", data);
            return this.Index(null);
        }

        public ActionResult Edit(MovieViewModel model)
        {
            return View(model);
        }

        public ActionResult EditSave(EditMovieViewModel model)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            Movie movie = db.Movies.FirstOrDefault(m => m.Id == model.Id);
            movie.Year = Convert.ToInt32(model.Year);
            movie.Title = model.Title;
            movie.StudioAdress = model.StudioAddress;
            movie.Studio = model.Studio;
            //todo: check for actors; implement changing actor logic
            movie.Director = model.Director;
            db.SaveChanges();
            return View();
        }
    }
}
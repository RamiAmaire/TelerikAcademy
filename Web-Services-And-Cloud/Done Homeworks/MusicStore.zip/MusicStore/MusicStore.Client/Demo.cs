﻿using System;
using System.Collections.Generic;
using System.Linq;
using MusicStore.Data;
using MusicStoreWebApi;
using System.Net.Http;
using System.Net.Http.Headers;

namespace MusicStore.Client
{
    public class Demo
    {
        private static void ListAllArtists(HttpClient client)
        {
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync("api/artists").Result;

            if (response.IsSuccessStatusCode)
            {
                var artists = response.Content
                    .ReadAsAsync<IEnumerable<Artist>>().Result;
                foreach (var a in artists)
                {
                    Console.WriteLine(a.Name + " " + a.Country + " " + a.DateOfBirth);
                }
            }
            else
            {
                Console.WriteLine("{0} ({1})",
                    (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        private static void AddNewArtist(HttpClient client, string name, string country, DateTime dateOfBirth, List<Album> albums, List<Song> songs)
        {
            Artist newArtist = new Artist() { Name = name, Country = country, DateOfBirth = dateOfBirth, Albums = albums, Songs = songs };
            var response = client.PostAsJsonAsync("api/artists", newArtist).Result;
            //var response = client.PostAsXmlAsync("api/artists", newArtist).Result;
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Artist added!");
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        private static void DeleteArtist(HttpClient client, string name, string country)
        {
            using (MusicStore.Data.MusicStoreEntities dbContext = new MusicStore.Data.MusicStoreEntities())
            {
                var artistIds = dbContext.Artists.Where(a => a.Name == name && a.Country == country).Select(a => a.ID);
                foreach (var id in artistIds)
                {
                    var response = client.DeleteAsync("api/artists/" + id).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine(string.Format("Artist {0}, from {1} deleted !", name, country));
                    }
                    else
                    {
                        Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                    }
                }
            }
        }

        private static void UpdateArtist(HttpClient client, int id, Artist value)
        {
            //var response = client.PutAsXmlAsync<Artist>("api/artists/" + id, value).Result;
            var response = client.PutAsJsonAsync<Artist>("api/artists/" + id, value).Result;
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Artist updated !");
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        private static Artist GetArtist(HttpClient client, string name, string country)
        {
            Artist artist = null;
            using (MusicStore.Data.MusicStoreEntities dbContext = new MusicStore.Data.MusicStoreEntities())
            {
                var artistId = dbContext.Artists.Where(a => a.Name == name && a.Country == country).Select(a => a.ID).FirstOrDefault();
                var response = client.GetAsync("api/artists/" + artistId).Result;
                if (response.IsSuccessStatusCode)
                {
                    artist = response.Content.ReadAsAsync<Artist>().Result;
                }
                else
                {
                    Console.WriteLine("Artist not found !");
                    Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                }
            }

            return artist;
        }

        public static void Main()
        {
            var client = new HttpClient
            {
                BaseAddress = new Uri("http://localhost:58256/")
            };

            //AddNewArtist(client, "Vanko1", "BG", DateTime.Now, new List<Album>(), new List<Song>());
            //ListAllArtists(client);
            //DeleteArtist(client, "50 Cent", "USA");
            //GetArtist(client, "Britney", "USA");
            //UpdateArtist(client, 2, new Artist()
            //{
            //    ID = 2,
            //    Name = "Kircho1",
            //    Country = "India",
            //    DateOfBirth = DateTime.Now,
            //    Albums = new List<Album>(),
            //    Songs = new List<Song>()
            //});

            // The logic is same for other objects (Albums, Songs)
        }
    }
}

﻿namespace _02.ConsoleClient.ServiceReference1
{


    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(ConfigurationName = "ServiceReference1.IDateService")]
    public interface IDateService
    {

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IDateService/GetDayOfWeek", ReplyAction = "http://tempuri.org/IDateService/GetDayOfWeekResponse")]
        string GetDayOfWeek(System.DateTime date);

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IDateService/GetDayOfWeek", ReplyAction = "http://tempuri.org/IDateService/GetDayOfWeekResponse")]
        System.Threading.Tasks.Task<string> GetDayOfWeekAsync(System.DateTime date);
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public interface IDateServiceChannel : _02.ConsoleClient.ServiceReference1.IDateService, System.ServiceModel.IClientChannel
    {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public partial class DateServiceClient : System.ServiceModel.ClientBase<_02.ConsoleClient.ServiceReference1.IDateService>, _02.ConsoleClient.ServiceReference1.IDateService
    {

        public DateServiceClient()
        {
        }

        public DateServiceClient(string endpointConfigurationName) :
            base(endpointConfigurationName)
        {
        }

        public DateServiceClient(string endpointConfigurationName, string remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public DateServiceClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public DateServiceClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
            base(binding, remoteAddress)
        {
        }

        public string GetDayOfWeek(System.DateTime date)
        {
            return base.Channel.GetDayOfWeek(date);
        }

        public System.Threading.Tasks.Task<string> GetDayOfWeekAsync(System.DateTime date)
        {
            return base.Channel.GetDayOfWeekAsync(date);
        }
    }
}
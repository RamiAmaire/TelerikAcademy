﻿using System;
using System.Collections.Generic;

namespace BlogDb.WebAPI.Models
{
    public class PostCreateModel
    {
        public PostCreateModel()
        {
            this.Tags = new HashSet<string>();
        }

        public string Title { get; set; }

        public string Text { get; set; }

        public IEnumerable<string> Tags { get; set; }
    }
}
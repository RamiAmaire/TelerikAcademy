﻿using System;

namespace BlogDb.WebAPI.Models
{
    public class CommentSimpleModel
    {
        public CommentSimpleModel()
        {
        }

        public string Text { get; set; }
    }
}
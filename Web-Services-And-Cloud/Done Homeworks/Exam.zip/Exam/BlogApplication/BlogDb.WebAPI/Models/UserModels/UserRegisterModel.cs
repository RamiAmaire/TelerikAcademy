﻿using System;

namespace BlogDb.WebAPI.Models
{
    public class UserRegisterModel
    {
        public UserRegisterModel()
        {
        }

        public string Username { get; set; }

        public string Displayname { get; set; }

        public string AuthCode { get; set; }
    }
}
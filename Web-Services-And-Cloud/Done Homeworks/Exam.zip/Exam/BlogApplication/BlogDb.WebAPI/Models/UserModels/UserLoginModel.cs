﻿using System;

namespace BlogDb.WebAPI.Models
{
    public class UserLoginModel
    {
        public UserLoginModel()
        {
        }

        public string Username { get; set; }

        public string AuthCode { get; set; }
    }
}
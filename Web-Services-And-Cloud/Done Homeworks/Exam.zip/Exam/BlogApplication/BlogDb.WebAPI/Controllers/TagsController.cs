﻿using System;
using System.Linq;
using System.Web.Http;
using BlogDb.WebAPI.Models;
using BlogDb.Models;

namespace BlogDb.WebAPI.Controllers
{
    public class TagsController : BaseApiController
    {
        private const int SessionKeyLength = 50;

        public IQueryable<TagModel> GetAll(string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    this.ValidateSessionKey(sessionKey);
                    var context = new BlogDbEntities();
                    var tags = context.Tags;
                    var tagModels = (from tag in tags
                                    select new TagModel()
                                    {
                                        Id = tag.Id,
                                        Name = tag.Name,
                                        Posts = tag.Posts.Count
                                    }).OrderBy(t => t.Name);

                    return tagModels;
                });

            return responseMsg;
        }

        [HttpGet]
        [ActionName("posts")]
        public IQueryable<PostModel> GetPostsByTag(int tagId, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    this.ValidateSessionKey(sessionKey);
                    var context = new BlogDbEntities();
                    var currentTag = context.Tags.FirstOrDefault(t => t.Id == tagId);
                    if (currentTag == null)
                    {
                        throw new ArgumentNullException("Invalid tag.");
                    }

                    var posts = currentTag.Posts;
                    var postModels = (from post in posts
                                      select new PostModel()
                                      {
                                          Title = post.Title,
                                          Id = post.Id,
                                          PostDate = post.PostDate,
                                          PostedBy = post.User.DisplayName,
                                          Text = post.Text,
                                          Comments = from comment in post.Comments
                                                     select new CommentModel()
                                                     {
                                                         Text = comment.Text,
                                                         PostDate = comment.CommentDate,
                                                         CommentedBy = comment.User.DisplayName
                                                     },
                                          Tags = from tag in post.Tags
                                                 select tag.Name
                                      }).OrderByDescending(p => p.PostDate).AsQueryable();

                    return postModels;
                });

            return responseMsg;
        }

        private void ValidateSessionKey(string sessionKey)
        {
            if (sessionKey == null || sessionKey == string.Empty || sessionKey.Length != SessionKeyLength)
            {
                throw new ArgumentOutOfRangeException("Invalid session key");
            }
        }
    }
}

FoursquareApp
=============

Simple app for Web-Services Course

﻿using System;

namespace BlogDb.WebAPI.Models
{
    public class UserLoggedModel
    {
        public UserLoggedModel()
        {
        }

        public string Displayname { get; set; }

        public string SessionKey { get; set; }
    }
}
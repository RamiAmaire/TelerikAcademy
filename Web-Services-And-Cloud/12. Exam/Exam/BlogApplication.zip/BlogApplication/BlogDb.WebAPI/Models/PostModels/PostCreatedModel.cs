﻿using System;

namespace BlogDb.WebAPI.Models
{
    public class PostCreatedModel
    {
        public PostCreatedModel()
        {
        }

        public string Title { get; set; }

        public int Id { get; set; }
    }
}
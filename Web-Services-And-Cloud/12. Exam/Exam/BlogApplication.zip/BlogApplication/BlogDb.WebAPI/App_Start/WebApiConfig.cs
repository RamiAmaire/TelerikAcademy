﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace BlogDb.WebAPI
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.Routes.MapHttpRoute(
                name: "PostsPostsByTagnamesApi",
                routeTemplate: "api/posts/tags/{tagname}/{sessionKey}",
                defaults: new
                {
                    controller = "posts",
                    action = "tags"
                }
            );

            config.Routes.MapHttpRoute(
                name: "TagsPostsByTagApi",
                routeTemplate: "api/tags/{tagId}/posts/{sessionKey}",
                defaults: new
                {
                    controller = "tags",
                    action = "posts"
                }
            );

            config.Routes.MapHttpRoute(
                name: "PostsCommentApi",
                routeTemplate: "api/posts/{postId}/comment/{sessionKey}",
                defaults: new
                {
                    controller = "posts",
                    action = "comment"
                }
            );

            config.Routes.MapHttpRoute(
                name: "PostsKeywordSearchApi",
                routeTemplate: "api/posts/keyword/{keyword}/{sessionKey}",
                defaults: new
                {
                    controller = "posts",
                    action = "keyword"
                }
            );

            config.Routes.MapHttpRoute(
                name: "PostsPageApi",
                routeTemplate: "api/posts/page/{page}/{count}/{sessionKey}",
                defaults: new
                {
                    controller = "posts",
                    action = "page"
                }
            );

            config.Routes.MapHttpRoute(
                name: "UsersLogoutApi",
                routeTemplate: "api/users/logout/{sessionKey}",
                defaults: new
                {
                    controller = "users",
                    action = "logout"
                }
            );

            config.Routes.MapHttpRoute(
                name: "UsersApi",
                routeTemplate: "api/users/{action}",
                defaults: new
                {
                    controller = "users"
                }
            );

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{sessionKey}",
                defaults: new { sessionKey = RouteParameter.Optional }
            );
        }
    }
}

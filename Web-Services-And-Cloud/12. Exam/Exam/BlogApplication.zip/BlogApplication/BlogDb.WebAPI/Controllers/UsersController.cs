﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BlogDb.WebAPI.Models;
using System.Text;
using BlogDb.Models;

namespace BlogDb.WebAPI.Controllers
{
    public class UsersController : BaseApiController
    {
        #region Constants
        private const int MinUsernameLength = 6;
        private const int MaxUsernameLength = 30;
        private const string ValidUsernameCharacters =
            "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM1234567890_.";
        private const string ValidDisplaynameCharacters =
            "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM1234567890_. -";
        private const string SessionKeyChars =
            "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM";
        private static readonly Random rand = new Random();
        private const int SessionKeyLength = 50;
        private const int Sha1Length = 40;
        #endregion

        [HttpPost]
        [ActionName("register")]
        public HttpResponseMessage Register(UserRegisterModel model)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    var context = new BlogDbEntities();
                    using (context)
                    {
                        this.ValidateUsername(model.Username);
                        this.ValidateDisplayname(model.Displayname);
                        this.ValidateAuthCode(model.AuthCode);

                        var usernameToLower = model.Username.ToLower();
                        var displaynameToLower = model.Displayname.ToLower();
                        var user = context.Users.FirstOrDefault(usr => usr.Username == usernameToLower || usr.DisplayName.ToLower() == displaynameToLower);
                            
                        if (user != null)
                        {
                            throw new InvalidOperationException("Username or displayname already exists");
                        }

                        user = new User()
                        {
                            Username = usernameToLower,
                            DisplayName = model.Displayname,
                            AuthCode = model.AuthCode
                        };

                        context.Users.Add(user);
                        context.SaveChanges();
                        user.SessionKey = this.GenerateSessionKey(user.Id);
                        context.SaveChanges();

                        var loggedModel = new UserLoggedModel()
                        {
                            Displayname = user.DisplayName,
                            SessionKey = user.SessionKey
                        };

                        var response = this.Request.CreateResponse(HttpStatusCode.Created, loggedModel);               
                        return response;
                    }
                });

            return responseMsg;
        }

        [HttpPost]
        [ActionName("login")]
        public HttpResponseMessage Login(UserLoginModel model)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    var context = new BlogDbEntities();
                    using (context)
                    {
                        this.ValidateUsername(model.Username);
                        this.ValidateAuthCode(model.AuthCode);

                        var usernameToLower = model.Username.ToLower();
                        var user = context.Users.FirstOrDefault(usr => usr.Username == usernameToLower || usr.AuthCode == model.AuthCode);

                        if (user.SessionKey != null)
                        {
                            throw new InvalidOperationException("User is already logged.");
                        }

                        user.SessionKey = this.GenerateSessionKey(user.Id);
                        context.SaveChanges();

                        var loggedModel = new UserLoggedModel()
                        {
                            Displayname = user.DisplayName,
                            SessionKey = user.SessionKey
                        };

                        var response = this.Request.CreateResponse(HttpStatusCode.Created, loggedModel);
                        return response;
                    }
                });

            return responseMsg;
        }

        [HttpPut]
        [ActionName("logout")]
        public HttpResponseMessage Logout(string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    var context = new BlogDbEntities();
                    using (context)
                    {
                        this.ValidateSessionKey(sessionKey);
                        var currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionKey);
                        if (currentUser == null)
                        {
                            throw new ArgumentNullException("Invalid sessionkey.");    
                        }

                        currentUser.SessionKey = null;
                        context.SaveChanges();

                        var response = this.Request.CreateResponse(HttpStatusCode.OK, sessionKey);
                        return response;
                    }
                });

            return responseMsg;
        }

        #region Validations
        private string GenerateSessionKey(int userId)
        {
            StringBuilder skeyBuilder = new StringBuilder(SessionKeyLength);
            skeyBuilder.Append(userId);
            while (skeyBuilder.Length < SessionKeyLength)
            {
                var index = rand.Next(SessionKeyChars.Length);
                skeyBuilder.Append(SessionKeyChars[index]);
            }
            return skeyBuilder.ToString();
        }

        private void ValidateSessionKey(string sessionKey)
        {
            if (sessionKey == null || sessionKey == string.Empty || sessionKey.Length != SessionKeyLength)
            {
                throw new ArgumentOutOfRangeException("Invalid session key");
            }
        }

        private void ValidateAuthCode(string authCode)
        {
            if (authCode == null || authCode.Length != Sha1Length)
            {
                throw new ArgumentOutOfRangeException("Password should be encrypted");
            }
        }

        private void ValidateDisplayname(string displayname)
        {
            if (displayname == null)
            {
                throw new ArgumentNullException("Displayname cannot be null");
            }
            else if (displayname.Length < MinUsernameLength)
            {
                throw new ArgumentOutOfRangeException(
                    string.Format("Displayname must be at least {0} characters long",
                    MinUsernameLength));
            }
            else if (displayname.Length > MaxUsernameLength)
            {
                throw new ArgumentOutOfRangeException(
                    string.Format("Displayname must be less than {0} characters long",
                    MaxUsernameLength));
            }
            else if (displayname.Any(ch => !ValidUsernameCharacters.Contains(ch)))
            {
                throw new ArgumentOutOfRangeException(
                    "Displayname must contain only Latin letters, digits .,_ -");
            }
        }

        private void ValidateUsername(string username)
        {
            if (username == null)
            {
                throw new ArgumentNullException("Username cannot be null");
            }
            else if (username.Length < MinUsernameLength)
            {
                throw new ArgumentOutOfRangeException(
                    string.Format("Username must be at least {0} characters long",
                    MinUsernameLength));
            }
            else if (username.Length > MaxUsernameLength)
            {
                throw new ArgumentOutOfRangeException(
                    string.Format("Username must be less than {0} characters long",
                    MaxUsernameLength));
            }
            else if (username.Any(ch => !ValidUsernameCharacters.Contains(ch)))
            {
                throw new ArgumentOutOfRangeException(
                    "Username must contain only Latin letters, digits .,_");
            }
        }
        #endregion
    }
}

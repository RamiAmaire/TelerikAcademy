﻿using System;
using System.Collections.Generic;

namespace BlogDb.WebAPI.Models
{
    public class CommentModel
    {
        public CommentModel()
        {
        }

        public string Text { get; set; }

        public string CommentedBy { get; set; }

        public DateTime PostDate { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;

namespace BlogDb.WebAPI.Models
{
    public class TagModel
    {
        public TagModel()
        {
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public long Posts { get; set; }
    }
}
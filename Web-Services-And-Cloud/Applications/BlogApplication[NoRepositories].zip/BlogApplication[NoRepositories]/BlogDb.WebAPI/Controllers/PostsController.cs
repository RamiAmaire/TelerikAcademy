﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BlogDb.WebAPI.Models;
using BlogDb.Models;

namespace BlogDb.WebAPI.Controllers
{
    public class PostsController : BaseApiController
    {
        private const int SessionKeyLength = 50;

        public IQueryable<PostModel> GetAll(string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    var context = new BlogDbEntities();
                    this.ValidateSessionKey(sessionKey);

                    var posts = context.Posts;
                    var postModels = (from post in posts
                                        select new PostModel()
                                        {
                                            Title = post.Title,
                                            Id = post.Id,
                                            PostDate = post.PostDate,
                                            PostedBy = post.User.DisplayName,
                                            Text = post.Text,
                                            Comments = from comment in post.Comments
                                                    select new CommentModel()
                                                    {
                                                        Text = comment.Text,
                                                        PostDate = comment.CommentDate,
                                                        CommentedBy = comment.User.DisplayName
                                                    },
                                        Tags = from tag in post.Tags
                                                select tag.Name
                                        }).OrderByDescending(p => p.PostDate);

                    return postModels;
                });

            return responseMsg;
        }

        [HttpGet]
        [ActionName("page")]
        public IQueryable<PostModel> GetPostsByPageAndCount(int page, int count, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    this.ValidateSessionKey(sessionKey);
                    var postModels = this.GetAll(sessionKey).Skip(page * count).Take(count).
                        OrderByDescending(p => p.PostDate);
                    return postModels;
                });

            return responseMsg;
        }

        [HttpPost]
        public HttpResponseMessage CreatePost(PostCreateModel model, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    using(var context = new BlogDbEntities())
	                {
		                this.ValidateSessionKey(sessionKey);
                        var currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionKey);
                        if (currentUser == null)
                        {
                            throw new ArgumentNullException("Invalid sessionkey.");
                        }

                        Post newPost = new Post()
                        {
                            Title = model.Title,
                            Text = model.Text,
                            PostDate = DateTime.Now,
                            Tags = (from tag in model.Tags
                                    select new Tag()
                                    {
                                        Name = tag
                                    }).ToList(),
                            User = currentUser,
                            UserId = currentUser.Id,
                        };

                        context.Posts.Add(newPost);
                        context.SaveChanges();

                        PostCreatedModel createdPostModel = new PostCreatedModel()
                        {
                            Id = newPost.Id,
                            Title = newPost.Title
                        };

                        var response = this.Request.CreateResponse(HttpStatusCode.Created, createdPostModel);
                        return response;
	                }
                });

            return responseMsg;
        }

        [HttpGet]
        [ActionName("keyword")]
        public IQueryable<PostModel> SearchForPostsByKeyword(string keyword, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    this.ValidateSessionKey(sessionKey);
                    this.ValidateKeyword(keyword);
                    var postModelsContainingKeyword = this.GetAll(sessionKey).
                        Where(p => p.Title.Contains(keyword)).OrderByDescending(p => p.PostDate);
                    return postModelsContainingKeyword;
                });

            return responseMsg;
        }

        [HttpGet]
        [ActionName("tags")]
        public IQueryable<PostModel> PostsByTagnames(string tagname, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    this.ValidateSessionKey(sessionKey);
                    return this.GetAll(sessionKey);
                });

            return responseMsg;
        }

        [HttpPut]
        [ActionName("comment")]
        public HttpResponseMessage CommentPost(int postId, CommentSimpleModel model, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(
                () =>
                {
                    this.ValidateSessionKey(sessionKey);
                    using (var context = new BlogDbEntities())
                    {
                        var currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionKey);
                        if (currentUser == null)
                        {
                            throw new ArgumentNullException("Invalid sessionkey.");
                        }

                        var currentPost = context.Posts.FirstOrDefault(p => p.Id == postId);
                        if (currentPost == null)
                        {
                            throw new ArgumentNullException("Invalid post.");
                        }

                        Comment newComment = new Comment()
                        {
                            Text = model.Text,
                            User = currentUser,
                            UserId = currentUser.Id,
                            CommentDate = DateTime.Now,
                            Post = currentPost,
                            PostId = currentPost.Id
                        };

                        currentPost.Comments.Add(newComment);
                        context.SaveChanges();

                        string nullStr = null;
                        var response = this.Request.CreateResponse(HttpStatusCode.OK, nullStr);
                        return response;
                    }
                });

            return responseMsg;
        }

        private void ValidateSessionKey(string sessionKey)
        {
            if (sessionKey == null || sessionKey == string.Empty || sessionKey.Length != SessionKeyLength)
            {
                throw new ArgumentOutOfRangeException("Invalid session key");
            }
        }

        private void ValidateKeyword(string keyword)
        {
            if (keyword == null || keyword == string.Empty)
            {
                throw new ArgumentException("Invalid keyword.");
            }
        }
    }
}

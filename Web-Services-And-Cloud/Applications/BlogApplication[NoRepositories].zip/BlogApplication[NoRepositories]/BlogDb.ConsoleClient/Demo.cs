﻿using System;
using System.Collections.Generic;
using System.Linq;
using BlogDb.Models;

namespace BlogDb.ConsoleClient
{
    public class Demo
    {
        public static void Main()
        {
            //using (var context = new BlogDbEntities())
            //{
            //    var user = new User()
            //    {
            //        Username = "Rami",
            //        DisplayName = "Amaire",
            //        AuthCode = "killer91",
            //        SessionKey = "asdad"
            //    };

            //    context.Users.Add(user);
            //    context.SaveChanges();
            //}
        }
    }
}

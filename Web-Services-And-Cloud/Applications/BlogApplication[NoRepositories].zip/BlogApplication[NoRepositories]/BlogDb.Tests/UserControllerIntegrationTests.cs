﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BlogDb.Models;
using BlogDb.WebAPI.Models;
using BlogDb.WebAPI.Models;
using BlogDb.WebAPI.Controllers;
using System.Web.Http;
using Newtonsoft.Json;
using System.Net;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;

namespace BlogDb.Tests
{
    [TestClass]
    public class ThreadsControllerIntegrationTests
    {
        private static TransactionScope tran;
        private InMemoryHttpServer httpServer;
        private string validSessionKey = "2nzdvalIAqVLeGxJnhZSTeptJPsAPyTxbjrqGvCQNsLEBUnHLF";
        private readonly string invalidSessionKey = "2nzdvalIAqVLeGxJnhZSTeptJPsAPyTxbjrqGvCQNsLEBUnHLk";
        private readonly int validPostId = 4;
        private readonly int invalidPostId = 200;

        [TestInitialize]
        public void TestInit()
        {
            var type = typeof(UsersController);
            tran = new TransactionScope();
            var routes = new List<Route>
                {
                    new Route(
                        "PostsCommentApi",
                        "api/posts/{postId}/comment/{sessionKey}",
                        new { controller = "posts", action = "comment" }),

                    new Route(
                        "UsersLogoutApi",
                        "api/users/logout/{sessionKey}",
                        new { controller = "users", action = "logout" }),

                    new Route(
                        "UsersApi",
                        "api/users/{action}",
                        new { controller = "users" }),
                
                    new Route(
                        "DefaultApi",
                        "api/{controller}/{sessionKey}",
                        new { sessionKey = RouteParameter.Optional }),
                };

            this.httpServer = new InMemoryHttpServer("http://localhost:26205/", routes);
        }

        [TestCleanup]
        public void TearDown()
        {
            tran.Dispose();
        }

        [TestMethod]
        public void Register_WhenUserModelValid_ShouldSaveToDatabase()
        {
            using (tran)
            {
                var testUser = new UserRegisterModel()
                {
                    Username = "PeterPetrov",
                    Displayname = "Peshoto",
                    AuthCode = "1ad1f2167dc4e2d5e306b1dccfcec56ce5fa2c25"
                };

                using (var context = new BlogDbEntities())
                {
                    int usersCount = context.Users.Count();
                    var response = httpServer.Post("api/users/register", testUser);
                    Assert.AreEqual(HttpStatusCode.Created, response.StatusCode);
                    Assert.AreEqual(context.Users.Count(), usersCount + 1);

                    var contentString = response.Content.ReadAsStringAsync().Result;
                    var userModel = JsonConvert.DeserializeObject<UserLoggedModel>(contentString);
                    Assert.AreEqual(testUser.Displayname, userModel.Displayname);
                    Assert.IsNotNull(userModel.SessionKey);
                }
            }
        }

        [TestMethod]
        public void Register_WhenUserModelInvalid_ShouldNotSaveToDatabase()
        {
            using (tran)
            {
                var testUser = new UserRegisterModel()
                {
                    Username = "Pete",
                    Displayname = "Peshoto",
                    AuthCode = "1ad1f2167dc4e2d5e306b1dccfcec56ce5fa2c25"
                };

                using (var context = new BlogDbEntities())
                {
                    int usersCount = context.Users.Count();
                    var response = httpServer.Post("api/users/register", testUser);

                    string errMsg = response.Content.ReadAsStringAsync().Result;
                    MessageModel msg = JsonConvert.DeserializeObject<MessageModel>(errMsg);

                    bool contains = msg.Message.Contains("Username must be at least 6 characters long");
                    Assert.IsTrue(contains);

                    Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
                    Assert.AreEqual(context.Users.Count(), usersCount);

                    var contentString = response.Content.ReadAsStringAsync().Result;
                    var userModel = JsonConvert.DeserializeObject<UserLoggedModel>(contentString);
                    Assert.IsNull(userModel.SessionKey);
                    Assert.IsNull(userModel.Displayname);
                }
            }
        }

        [TestMethod]
        public void Logout_ValidSessionKey_ShouldSaveToDatabase()
        {
            using (tran)
            {
                var testUser = new UserRegisterModel()
                {
                    Username = "PeterPetrov",
                    Displayname = "Peshoto",
                    AuthCode = "1ad1f2167dc4e2d5e306b1dccfcec56ce5fa2c25"
                };

                using (var context = new BlogDbEntities())
                {
                    var currentUser = context.Users.FirstOrDefault(u => u.SessionKey == validSessionKey);
                    Assert.IsNotNull(currentUser);

                    var response = httpServer.Put("api/users/logout/" + validSessionKey, testUser);
                    var contentString = response.Content.ReadAsStringAsync().Result;
                    Assert.IsTrue(contentString.Contains(validSessionKey));

                    currentUser = context.Users.FirstOrDefault(u => u.SessionKey == validSessionKey);
                    Assert.IsNull(currentUser);
                }
            }
        }

        [TestMethod]
        public void Logout_InvalidSessionKey_ShouldNotSaveToDatabase()
        {
            using (tran)
            {
                var testUser = new UserRegisterModel()
                {
                    Username = "PeterPetrov",
                    Displayname = "Peshoto",
                    AuthCode = "1ad1f2167dc4e2d5e306b1dccfcec56ce5fa2c25"
                };

                using (var context = new BlogDbEntities())
                {
                    var currentUser = context.Users.FirstOrDefault(u => u.SessionKey == invalidSessionKey);
                    Assert.IsNull(currentUser);

                    var response = httpServer.Put("api/users/logout/" + invalidSessionKey, testUser);
                    var contentString = response.Content.ReadAsStringAsync().Result;
                    Assert.IsTrue(contentString.Contains("Invalid sessionkey"));
                }
            }
        }

        [TestMethod]
        public void CreatePost_Valid_ShouldSaveToDatabase()
        {
            using (tran)
            {
                var postCreateModel = new PostCreateModel()
                {
                    Title = "Fitness",
                    Text = "Arnold",
                    Tags = new HashSet<string>() {"lud", "tejko" }
                };

                using (var context = new BlogDbEntities())
                {
                    int postsCount = context.Posts.Count();
                    var response = httpServer.Post("api/posts/" + validSessionKey, postCreateModel);
                    Assert.AreEqual(HttpStatusCode.Created, response.StatusCode);
                    Assert.AreEqual(context.Posts.Count(), postsCount + 1);

                    var createdPost = context.Posts.FirstOrDefault(p => p.Title == postCreateModel.Title);
                    Assert.IsNotNull(createdPost);

                    var contentString = response.Content.ReadAsStringAsync().Result;
                    var postCreatedModel = JsonConvert.DeserializeObject<PostCreatedModel>(contentString);
                    Assert.AreEqual(postCreateModel.Title, postCreatedModel.Title);
                    Assert.AreEqual(createdPost.Id, postCreatedModel.Id);
                }
            }
        }

        [TestMethod]
        public void CreatePost_Invalid_ShouldNotSaveToDatabase_NoText()
        {
            using (tran)
            {
                var postCreateModel = new PostCreateModel()
                {
                    Title = "Fitness",
                    Tags = new HashSet<string>() { "lud", "tejko" }
                };

                using (var context = new BlogDbEntities())
                {
                    int postsCount = context.Posts.Count();
                    var response = httpServer.Post("api/posts/" + validSessionKey, postCreateModel);
                    Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
                    Assert.AreEqual(context.Posts.Count(), postsCount);

                    var createdPost = context.Posts.FirstOrDefault(p => p.Title == postCreateModel.Title);
                    Assert.IsNull(createdPost);

                    var contentString = response.Content.ReadAsStringAsync().Result;
                    bool validationFailed = contentString.Contains("Validation failed");
                    Assert.IsTrue(validationFailed);

                    var postCreatedModel = JsonConvert.DeserializeObject<PostCreatedModel>(contentString);
                    Assert.AreEqual(postCreatedModel.Title, null);
                    Assert.AreEqual(postCreatedModel.Id, 0);
                }
            }
        }

        [TestMethod]
        public void CreatePost_Invalid_ShouldNotSaveToDatabase_InvalidSessionkey()
        {
            using (tran)
            {
                var postCreateModel = new PostCreateModel()
                {
                    Title = "Fitness",
                    Text = "Arnold",
                    Tags = new HashSet<string>() { "lud", "tejko" }
                };

                using (var context = new BlogDbEntities())
                {
                    int postsCount = context.Posts.Count();
                    var response = httpServer.Post("api/posts/" + invalidSessionKey, postCreateModel);
                    Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
                    Assert.AreEqual(context.Posts.Count(), postsCount);

                    var createdPost = context.Posts.FirstOrDefault(p => p.Title == postCreateModel.Title);
                    Assert.IsNull(createdPost);

                    var contentString = response.Content.ReadAsStringAsync().Result;
                    bool invalidSessionkey = contentString.Contains("Invalid sessionkey.");
                    Assert.IsTrue(invalidSessionkey);

                    var postCreatedModel = JsonConvert.DeserializeObject<PostCreatedModel>(contentString);
                    Assert.AreEqual(postCreatedModel.Title, null);
                    Assert.AreEqual(postCreatedModel.Id, 0);
                }
            }
        }

        [TestMethod]
        public void CommentPost_Valid_ShouldSaveToDataBase()
        {
            using (tran)
            {
                string text = "bla bla bla";
                var commentSimple = new CommentSimpleModel()
                {
                    Text = text
                };

                using (var context = new BlogDbEntities())
                {
                    int commentsCount = context.Comments.Count();
                    var response = httpServer.Put(string.Format("api/posts/{0}/comment/{1}", validPostId, validSessionKey), commentSimple);
                    Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
                    Assert.AreEqual(context.Comments.Count(), commentsCount + 1);

                    var contentString = response.Content.ReadAsStringAsync().Result;
                    Assert.AreEqual("null", contentString);
                }
            }
        }

        [TestMethod]
        public void CommentPost_Invalid_ShouldNotSaveToDataBase_NoText()
        {
            using (tran)
            {
                var commentSimple = new CommentSimpleModel();
                using (var context = new BlogDbEntities())
                {
                    int commentsCount = context.Comments.Count();
                    var response = httpServer.Put(string.Format("api/posts/{0}/comment/{1}", validPostId, validSessionKey), commentSimple);
                    Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
                    Assert.AreEqual(context.Comments.Count(), commentsCount);

                    var contentString = response.Content.ReadAsStringAsync().Result;
                    bool validationFailed = contentString.Contains("Validation failed");
                    Assert.IsTrue(validationFailed);
                }
            }
        }

        [TestMethod]
        public void CommentPost_Invalid_ShouldNotSaveToDataBase_InvalidPostId()
        {
            using (tran)
            {
                var commentSimple = new CommentSimpleModel();
                using (var context = new BlogDbEntities())
                {
                    int commentsCount = context.Comments.Count();
                    var response = httpServer.Put(string.Format("api/posts/{0}/comment/{1}", invalidPostId, validSessionKey), commentSimple);
                    Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
                    Assert.AreEqual(context.Comments.Count(), commentsCount);

                    var contentString = response.Content.ReadAsStringAsync().Result;
                    bool invalidPost = contentString.Contains("Invalid post.");
                    Assert.IsTrue(invalidPost);
                }
            }
        }

        [TestMethod]
        public void CommentPost_Invalid_ShouldNotSaveToDataBase_InvalidSessionkey()
        {
            using (tran)
            {
                var commentSimple = new CommentSimpleModel();
                using (var context = new BlogDbEntities())
                {
                    int commentsCount = context.Comments.Count();
                    var response = httpServer.Put(string.Format("api/posts/{0}/comment/{1}", validPostId, invalidSessionKey), commentSimple);
                    Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
                    Assert.AreEqual(context.Comments.Count(), commentsCount);

                    var contentString = response.Content.ReadAsStringAsync().Result;
                    bool invalidSessionkey = contentString.Contains("Invalid sessionkey.");
                    Assert.IsTrue(invalidSessionkey);
                }
            }
        }
    }
}

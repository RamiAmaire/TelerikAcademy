﻿using System;

namespace BlogDb.Tests
{
    public class MessageModel
    {
        public MessageModel()
        {
        }

        public string Message { get; set; }
    }
}

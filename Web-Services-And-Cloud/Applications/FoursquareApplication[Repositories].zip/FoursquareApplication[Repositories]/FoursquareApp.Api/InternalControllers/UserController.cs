﻿using FoursquareApp.Api.Models;
using FoursquareApp.Data;
using FoursquareApp.Models;
using FoursquareApp.Repos;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Web;

namespace FoursquareApp.Api.InternalControllers
{
    public class UserController
    {

    }
}
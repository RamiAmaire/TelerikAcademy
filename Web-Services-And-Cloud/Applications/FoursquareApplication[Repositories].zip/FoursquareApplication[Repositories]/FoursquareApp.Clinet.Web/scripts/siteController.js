﻿$(function () {
    console.log("SiteContorllerLoad");
    var controller = controllers.get();
    controller.loadUI("#content");
});
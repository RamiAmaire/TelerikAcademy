﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace ForumDb.WebAPI
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.Routes.MapHttpRoute(
                name: "PostsVotesApi",
                routeTemplate: "api/posts/{postId}/votes/{sessionKey}",
                defaults: new
                {
                    controller = "posts",
                    action = "votes"
                }
            );

            config.Routes.MapHttpRoute(
                name: "PostsCommentsApi",
                routeTemplate: "api/posts/{postId}/comments/{sessionKey}",
                defaults: new
                {
                    controller = "posts",
                    action = "comments"
                }
            );

            config.Routes.MapHttpRoute(
                name: "PostsCommentApi",
                routeTemplate: "api/posts/{postId}/comment/{sessionKey}",
                defaults: new
                {
                    controller = "posts",
                    action = "comment"
                }
            );

            config.Routes.MapHttpRoute(
                name: "PostsVoteApi",
                routeTemplate: "api/posts/{postId}/vote/{sessionKey}",
                defaults: new
                {
                    controller = "posts",
                    action = "vote"
                }
            );

            config.Routes.MapHttpRoute(
                name: "PostsCreateApi",
                routeTemplate: "api/posts/create/{threadId}/{sessionKey}",
                defaults: new
                {
                    controller = "posts",
                    action = "create"
                }
            );

            config.Routes.MapHttpRoute(
                name: "PostsPageApi",
                routeTemplate: "api/posts/page/{page}/{count}/{sessionKey}",
                defaults: new
                {
                    controller = "posts",
                    action = "page"
                }
            );

            config.Routes.MapHttpRoute(
                name: "ThreadsPostsApi",
                routeTemplate: "api/threads/{threadId}/posts/{sessionKey}",
                defaults: new
                {
                    controller = "threads",
                    action = "posts"
                }
            );

            config.Routes.MapHttpRoute(
                name: "ThreadsCategoryApi",
                routeTemplate: "api/threads/category/{categoryName}/{sessionKey}",
                defaults: new
                {
                    controller = "threads",
                    action = "category"
                }
            );

            config.Routes.MapHttpRoute(
                name: "ThreadsPageApi",
                routeTemplate: "api/threads/page/{page}/{count}/{sessionKey}",
                defaults: new
                {
                    controller = "threads",
                    action = "page"
                }
            );

            config.Routes.MapHttpRoute(
                name: "DefaultActionApi",
                routeTemplate: "api/{controller}/{action}/{sessionKey}",
                defaults: new
                {
                    sessionKey = RouteParameter.Optional
                }
            );

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{sessionKey}",
                defaults: new { }
            );
        }
    }
}

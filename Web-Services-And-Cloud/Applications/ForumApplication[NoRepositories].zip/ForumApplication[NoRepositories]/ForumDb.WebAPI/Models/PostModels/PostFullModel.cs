﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ForumDb.WebAPI.Models;
using ForumDb.Models;

namespace ForumDb.WebAPI.Models
{
    public class PostFullModel : PostModel
    {
        public PostFullModel()
            :base()
        {
            this.Comments = new HashSet<Comment>();
            this.Votes = new HashSet<Vote>();
        }

        public IEnumerable<Comment> Comments { get; set; }

        public Thread Thread { get; set; }

        public User User { get; set; }

        public IEnumerable<Vote> Votes { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ForumDb.WebAPI.Models
{
    public class VoteModel
    {
        public VoteModel()
        {
        }

        public int Value { get; set; }
    }
}
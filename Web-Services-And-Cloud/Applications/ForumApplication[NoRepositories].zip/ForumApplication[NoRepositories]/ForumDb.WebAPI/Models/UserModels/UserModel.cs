﻿using System;

namespace ForumDb.WebAPI.Models
{
    public class UserModel
    {
        public UserModel()
        {
        }

        public UserModel(string username, string nickname, string authcode)
        {
            this.Username = username;
            this.Nickname = nickname;
            this.AuthCode = authcode;
        }

        public string Username { get; set; }

        public string Nickname { get; set; }

        public string AuthCode { get; set; }
    }
}
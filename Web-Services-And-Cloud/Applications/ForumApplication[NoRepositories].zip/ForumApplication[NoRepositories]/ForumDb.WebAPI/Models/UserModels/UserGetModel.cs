﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ForumDb.WebAPI.Models
{
    public class UserGetModel
    {
        public UserGetModel()
        {
        }

        public string Username { get; set; }

        public string NickName { get; set; }

        public int PostsCount { get; set; }

        public int ThreadsCount { get; set; }

        public int CommentsCount { get; set; }

        public int VotesCount { get; set; }
    }
}
﻿using System;

namespace ForumDb.WebAPI.Models
{
    public class LoggedUserModel
    {
        public LoggedUserModel(string nickname, string sessionKey)
        {
            this.Nickname = nickname;
            this.SessionKey = sessionKey;
        }

        public string Nickname { get; set; }

        public string SessionKey { get; set; }
    }
}
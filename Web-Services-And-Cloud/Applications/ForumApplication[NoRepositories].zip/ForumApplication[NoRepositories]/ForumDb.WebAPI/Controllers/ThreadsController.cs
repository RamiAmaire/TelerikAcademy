﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ForumDb.Models;
using ForumDb.WebAPI.Models;

namespace ForumDb.WebAPI.Controllers
{
    public class ThreadsController : BaseApiController
    {
        private void SessionKeyValidation(string sessionsKey)
        {
            if (sessionsKey == null)
            {
                throw new Exception("Only logged users can see threads.");
            }

            using (var context = new ForumDbEntities())
            {
                User currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionsKey);
                if (currentUser == null)
                {
                    throw new Exception("Only logged users can see threads.");
                }
            }
        }

        [HttpGet]
        [ActionName("get-all")]
        public IQueryable<ThreadModel> GetAll(string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                this.SessionKeyValidation(sessionKey);
                var context = new ForumDbEntities();
                var threads = context.Threads;
                var threadModels =
                    (from thread in threads
                        select new ThreadModel()
                        {
                            Id = thread.Id,
                            Title = thread.Title,
                            DateCreated = thread.DateCreated,
                            Content = thread.Content,
                            CreatedBy = thread.User.Nickname,
                            Posts = (from postEntity in thread.Posts
                                    select new PostModel()
                                    {
                                        Content = postEntity.Content,
                                        PostDate = postEntity.PostDate,
                                        PostedBy = postEntity.User.Nickname
                                    }),
                            Categories = (from categoryEntity in thread.Categories
                                        select categoryEntity.Name)
                        }).OrderByDescending(thr => thr.DateCreated);

                return threadModels;
            });

            return responseMsg;
        }

        [HttpGet]
        [ActionName("page")]
        public IQueryable<ThreadModel> GetPage(int page, int count, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                var threadModels = this.GetAll(sessionKey).Skip(page * count).Take(count);
                return threadModels;
            });

            return responseMsg;
        }

        [HttpGet]
        [ActionName("category")]
        public IQueryable<ThreadModel> GetThreadsByCategory(string categoryName, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                var threadModels = this.GetAll(sessionKey).Where(t => t.Categories.Any(c => c == categoryName));
                return threadModels;
            });

            return responseMsg;
        }

        [HttpGet]
        [ActionName("posts")]
        public IEnumerable<PostModel> GetPostsFromThread(int threadId, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                var currentThread = this.GetAll(sessionKey).Where(t => t.Id == threadId).FirstOrDefault();
                if (currentThread == null)
                {
                    throw new Exception("Thread doesn't exist.");
                }

                var postModels = from post in currentThread.Posts
                                 select new PostModel()
                                 {
                                     Content = post.Content,
                                     Rating = post.Rating,
                                     PostedBy = post.PostedBy,
                                     PostDate = post.PostDate
                                 };

                return postModels;
            });

            return responseMsg;
        }

        [HttpPost]
        [ActionName("create")]
        public HttpResponseMessage CreateThread(ThreadModel thread, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                using (var context = new ForumDbEntities())
                {
                    this.SessionKeyValidation(sessionKey);
                    User currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionKey);

                    Thread newThread = new Thread()
                    {
                        Title = thread.Title,
                        Content = thread.Content,
                        DateCreated = thread.DateCreated,
                        CreatedBy = currentUser.Nickname,
                        User = currentUser,
                        UserId = currentUser.Id,
                        Categories = (from cat in thread.Categories
                                      select new Category()
                                      {
                                          Name = thread.Categories.FirstOrDefault()
                                      }).ToList()
                    };

                    context.Threads.Add(newThread);
                    context.SaveChanges();
                    return this.Request.CreateResponse(HttpStatusCode.OK, thread);
                }
            });

            return responseMsg;
        }
    }
}

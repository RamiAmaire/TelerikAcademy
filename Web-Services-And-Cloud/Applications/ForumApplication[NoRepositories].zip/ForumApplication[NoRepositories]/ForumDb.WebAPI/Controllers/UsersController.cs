﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ForumDb.Models;
using ForumDb.WebAPI.Models;

namespace ForumDb.WebAPI.Controllers
{
    public class UsersController : BaseApiController
    {
        private const string SessionKeyChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        private const int SessionKeyLen = 50;
        private static Random rand = new Random();

        private static string GenerateSessionKey(int userId)
        {
            StringBuilder keyChars = new StringBuilder(50);
            keyChars.Append(userId.ToString());
            while (keyChars.Length < SessionKeyLen)
            {
                int randomCharNum;
                lock (rand)
                {
                    randomCharNum = rand.Next(SessionKeyChars.Length);
                }
                char randomKeyChar = SessionKeyChars[randomCharNum];
                keyChars.Append(randomKeyChar);
            }
            string sessionKey = keyChars.ToString();
            return sessionKey;
        }

        private void RegistrationValidation(UserModel user)
        {
            if (user.Username == null || user.Username.Length < 6 || user.Username.Length > 30)
            {
                throw new Exception("Invalid username.");
            }
            else if (user.Nickname == null || user.Nickname.Length < 6 || user.Nickname.Length > 30)
            {
                throw new Exception("Invalid nickname.");
            }
            else if (user.AuthCode.Length != 54)
            {
                throw new Exception("Invalid authcode.");
            }

            using (var context = new ForumDbEntities())
            {
                User usr = context.Users.FirstOrDefault(u => u.Username == user.Username || u.Nickname == user.Nickname);
                if (usr != null)
                {
                    throw new Exception("Username or nickname already exists.");
                }
            }
        }

        private void LoginValidation(UserModel user)
        {
            if (user.Username == null || user.Username.Length < 6 || user.Username.Length > 30)
            {
                throw new Exception("Invalid username.");
            }
            else if (user.AuthCode.Length != 54)
            {
                throw new Exception("Invalid authcode.");
            }

            using (var context = new ForumDbEntities())
            {
                User usr = context.Users.FirstOrDefault(u => u.Username == user.Username && u.AuthCode == user.AuthCode);
                if (usr == null)
                {
                    throw new Exception("User doesn't exist. Please register first.");
                }
                else if (usr.SessionKey != null)
                {
                    throw new Exception("User is already logged in.");
                }
            }
        }

        private void LogoutValidation(string sessionsKey)
        {
            if (sessionsKey == null)
            {
                throw new Exception("No logged user.");
            }

            using (var context = new ForumDbEntities())
            {
                User currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionsKey);
                if (currentUser == null)
                {
                    HttpError err = new HttpError("Invalid sessionKey.");
                    throw new Exception("Invalid sessionKey.");
                }
            }
        }

        private void SessionKeyValidation(string sessionsKey)
        {
            if (sessionsKey == null)
            {
                throw new Exception("Only logged users can see other users.");
            }

            using (var context = new ForumDbEntities())
            {
                User currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionsKey);
                if (currentUser == null)
                {
                    throw new Exception("Only logged users can see other users.");
                }
            }
        }

        [HttpGet]
        [ActionName("get-all")]
        public IQueryable<UserGetModel> GetAll(string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                var context = new ForumDbEntities();
                this.SessionKeyValidation(sessionKey);
                var users = context.Users;
                var userModels = (from user in users
                                    select new UserGetModel()
                                    {
                                        Username = user.Username,
                                        NickName = user.Nickname,
                                        PostsCount = user.Posts.Count,
                                        ThreadsCount = user.Threads.Count,
                                        CommentsCount = user.Comments.Count,
                                        VotesCount = user.Votes.Count
                                    });

                return userModels;
            });

            return responseMsg;
        }

        [HttpPost]
        [ActionName("register")]
        public HttpResponseMessage Register(UserModel user)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                this.RegistrationValidation(user);
                User newUser = new User()
                {
                    Username = user.Username,
                    Nickname = user.Nickname,
                    AuthCode = user.AuthCode,
                };

                using (var context = new ForumDbEntities())
                {
                    context.Users.Add(newUser);
                    context.SaveChanges();
                    newUser.SessionKey = GenerateSessionKey(newUser.Id);
                    context.SaveChanges();

                    LoggedUserModel loggedUser = new LoggedUserModel(newUser.Nickname, newUser.SessionKey);
                    return this.Request.CreateResponse(HttpStatusCode.OK, loggedUser);
                }
            });

            return responseMsg;
        }

        [HttpPost]
        [ActionName("login")]
        public HttpResponseMessage Login(UserModel user)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                this.LoginValidation(user);
                using (var context = new ForumDbEntities())
                {
                    User currentUser = context.Users.FirstOrDefault(u => u.Username == user.Username && u.AuthCode == user.AuthCode);
                    currentUser.SessionKey = GenerateSessionKey(currentUser.Id);
                    context.SaveChanges();

                    LoggedUserModel loggedUser = new LoggedUserModel(currentUser.Nickname, currentUser.SessionKey);
                    return this.Request.CreateResponse(HttpStatusCode.OK, loggedUser);
                }
            });

            return responseMsg;
        }

        [HttpPut]
        [ActionName("logout")]
        public HttpResponseMessage Logout(string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                this.LogoutValidation(sessionKey);
                using (var context = new ForumDbEntities())
                {
                    User currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionKey);
                    currentUser.SessionKey = null;
                    context.SaveChanges();
                    return this.Request.CreateResponse(HttpStatusCode.OK, currentUser.SessionKey);
                }
            });

            return responseMsg;
        }
    }
}

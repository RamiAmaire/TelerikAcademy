﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ForumDb.WebAPI.Models;
using ForumDb.Models;

namespace ForumDb.WebAPI.Controllers
{
    public class PostsController : BaseApiController
    {
        private void SessionKeyValidation(string sessionsKey)
        {
            if (sessionsKey == null)
            {
                throw new Exception("Only logged users can see posts.");
            }

            using (var context = new ForumDbEntities())
            {
                User currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionsKey);
                if (currentUser == null)
                {
                    throw new Exception("Only logged users can see posts.");
                }
            }
        }

        private void ThreadValidation(int threadId)
        {
            using (var context = new ForumDbEntities())
            {
                Thread currentThread = context.Threads.FirstOrDefault(t => t.Id == threadId);
                if (currentThread == null)
                {
                    throw new Exception("Thread doesn't exist.");
                }
            }
        }

        private void PostValidation(int postId)
        {
            using (var context = new ForumDbEntities())
            {
                Post currentPost = context.Posts.FirstOrDefault(t => t.Id == postId);
                if (currentPost == null)
                {
                    throw new Exception("Post doesn't exist.");
                }
            }
        }

        [HttpGet]
        [ActionName("get-all")]
        public IQueryable<PostModel> GetAll(string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                this.SessionKeyValidation(sessionKey);
                var context = new ForumDbEntities();
                var posts = context.Posts;
                var postModels = (from post in posts
                                select new PostModel()
                                {
                                    Content = post.Content,
                                    PostDate = post.PostDate,
                                    PostedBy = post.PostedBy,
                                    Rating = post.Rating,
                                }).OrderByDescending(p => p.PostDate);

                return postModels;
            });

            return responseMsg;
        }

        [HttpGet]
        [ActionName("page")]
        public IQueryable<PostModel> GetPage(int page, int count, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                var postModels = this.GetAll(sessionKey).Skip(page * count).Take(count);
                return postModels;
            });

            return responseMsg;
        }

        [HttpPost]
        [ActionName("create")]
        public HttpResponseMessage CreatePost(PostModel post, int threadId, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                using (var context = new ForumDbEntities())
                {
                    this.SessionKeyValidation(sessionKey);
                    this.ThreadValidation(threadId);
                    User currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionKey);
                    Thread currentThread = context.Threads.FirstOrDefault(t => t.Id == threadId);

                    Post newPost = new Post()
                    {
                        Content = post.Content,
                        PostDate = post.PostDate,
                        PostedBy = currentUser.Nickname,
                        Rating = post.Rating,
                        User = currentUser,
                        UserId = currentUser.Id,
                        Thread = currentThread,
                        ThreadId = currentThread.Id
                    };

                    context.Posts.Add(newPost);
                    context.SaveChanges();
                    return this.Request.CreateResponse(HttpStatusCode.OK, post);
                }
            });

            return responseMsg;
        }

        [HttpPost]
        [ActionName("vote")]
        public HttpResponseMessage Vote(VoteModel vote, int postId, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                this.PostValidation(postId);
                this.SessionKeyValidation(sessionKey);
                using (var context = new ForumDbEntities())
                {
                    Post currentPost = context.Posts.FirstOrDefault(p => p.Id == postId);
                    User currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionKey);
                    Vote newVote = new Vote()
                    {
                        Value = vote.Value,
                        Post = currentPost,
                        PostId = currentPost.Id,
                        User = currentUser,
                        UserId = currentUser.Id
                    };

                    currentPost.Votes.Add(newVote);
                    context.SaveChanges();
                    return this.Request.CreateResponse(HttpStatusCode.OK, vote);
                }
            });

            return responseMsg;
        }

        [HttpPost]
        [ActionName("comment")]
        public HttpResponseMessage CommentPost(CommentModel comment, int postId, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                this.PostValidation(postId);
                this.SessionKeyValidation(sessionKey);
                using (var context = new ForumDbEntities())
                {
                    User currentUser = context.Users.FirstOrDefault(u => u.SessionKey == sessionKey);
                    Post currentPost = context.Posts.FirstOrDefault(p => p.Id == postId);
                    Comment newComment = new Comment()
                    {
                        Content = comment.Content,
                        User = currentUser,
                        UserId = currentUser.Id,
                        Post = currentPost,
                        PostId = currentPost.Id
                    };

                    currentPost.Comments.Add(newComment);
                    context.SaveChanges();
                    return this.Request.CreateResponse(HttpStatusCode.OK, comment);
                }
            });

            return responseMsg;
        }

        [HttpGet]
        [ActionName("comments")]
        public IQueryable<CommentGetModel> GetAllComments(int postId, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                this.PostValidation(postId);
                this.SessionKeyValidation(sessionKey);
                using (var context = new ForumDbEntities())
                {
                    Post currentPost = context.Posts.FirstOrDefault(p => p.Id == postId);
                    var commentGetModels = (from comment in currentPost.Comments
                                            select new CommentGetModel()
                                            {
                                                Content = comment.Content,
                                                CommentedBy = comment.User.Nickname,
                                            }).AsQueryable<CommentGetModel>();

                    return commentGetModels;
                }
            });

            return responseMsg;
        }

        [HttpGet]
        [ActionName("votes")]
        public IQueryable<VoteModel> GetAllVotes(int postId, string sessionKey)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                this.PostValidation(postId);
                this.SessionKeyValidation(sessionKey);
                using (var context = new ForumDbEntities())
                {
                    Post currentPost = context.Posts.FirstOrDefault(p => p.Id == postId);
                    var voteModels = (from vote in currentPost.Votes
                                            select new VoteModel()
                                            {
                                                Value = vote.Value
                                            }).AsQueryable<VoteModel>();

                    return voteModels;
                }
            });

            return responseMsg;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using ForumDb.Models;
using ForumDb.WebAPI.Models;
using System.Text;
namespace ForumDb.ConsoleClient
{
    public class ThreadsDAO
    {
        private HttpClient client;

        public ThreadsDAO(HttpClient inputClient)
        {
            this.client = inputClient;
        }

        public IEnumerable<ThreadModel> GetAllThreads(string sessionKey)
        {
            HttpResponseMessage response = this.client.GetAsync("api/threads/get-all/" + sessionKey).Result;
            if (response.IsSuccessStatusCode)
            {
                var threads = response.Content.ReadAsAsync<IEnumerable<ThreadModel>>().Result;
                foreach (var thread in threads)
                {
                    Console.WriteLine(thread.Title + ", created by : " + thread.CreatedBy);
                }

                return threads;
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                return null;
            }
        }

        public void CreateThread(string title, string content, DateTime dateCreated, HashSet<string> categories, string sessionKey)
        {
            ThreadCreateModel thread = new ThreadCreateModel()
            {
                 Title = title,
                 Content = content,
                 DateCreated = dateCreated,
                 Categories = categories
            };

            var response = this.client.PostAsJsonAsync("api/threads/create/" + sessionKey, thread).Result;
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Thread {0} created!", title);
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public IEnumerable<ThreadModel> GetThreadsByPaging(int page, int count, string sessionKey)
        {
            HttpResponseMessage response = this.client.GetAsync(string.Format("api/threads/{0}/{1}/{2}/{3}", "page", page, count, sessionKey)).Result;
            if (response.IsSuccessStatusCode)
            {
                var threads = response.Content.ReadAsAsync<IEnumerable<ThreadModel>>().Result;
                foreach (var thread in threads)
                {
                    Console.WriteLine(thread.Title + ", created by : " + thread.CreatedBy);
                }

                return threads;
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                return null;
            }
        }

        public IEnumerable<ThreadModel> GetThreadsByCategory(string categoryName, string sessionKey)
        {
            HttpResponseMessage response = this.client.GetAsync(string.Format("api/threads/{0}/{1}/{2}", "category", categoryName, sessionKey)).Result;
            if (response.IsSuccessStatusCode)
            {
                var threads = response.Content.ReadAsAsync<IEnumerable<ThreadModel>>().Result;
                foreach (var thread in threads)
                {
                    Console.WriteLine(thread.Title + ", created by : " + thread.CreatedBy);
                }

                return threads;
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                return null;
            }
        }

        public IEnumerable<PostModel> GetAllPostsFromThread(int threadId, string sessionKey)
        {
            HttpResponseMessage response = this.client.GetAsync(string.Format("api/threads/{0}/{1}/{2}",
                threadId, "posts", sessionKey)).Result;
            if (response.IsSuccessStatusCode)
            {
                var posts = response.Content.ReadAsAsync<IEnumerable<PostModel>>().Result;
                foreach (var post in posts)
                {
                    Console.WriteLine(post.Content + ", posted by : " + post.PostedBy);
                }

                return posts;
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                return null;
            }
        }
    }
}

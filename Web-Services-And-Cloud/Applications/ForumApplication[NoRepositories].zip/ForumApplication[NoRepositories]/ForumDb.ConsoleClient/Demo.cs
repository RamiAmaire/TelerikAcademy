﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using ForumDb.Models;
using ForumDb.WebAPI.Models;

namespace ForumDb.ConsoleClient
{
    public class Demo
    {
        public static void Main()
        {
            HttpClient Client = new HttpClient { BaseAddress = new Uri("http://localhost:55860/") };
            Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            //UsersDAO userClient = new UsersDAO(Client);
            //userClient.RegisterUser("RamiAmaire", "RamiSmart", "killer91");
            //userClient.LoginUser("Rami91", "killer91");
            //userClient.LoginUser("RamiAmaire", "killer91");
            //userClient.Logout("14Vu5bPsfKwcb4NOi2glfPrmZqfM4TL6Q5Y5a6xbbm92ooOtWm");
            //userClient.GetAllUsers("2xc16adCjKEv3oCypBWWHob549tGoxkRmqHWi4JUusrlifYxw3");

            //ThreadsDAO threadClient = new ThreadsDAO(Client);
            //threadClient.CreateThread("Sofia", "Optimum GYM", DateTime.Now, new HashSet<string>() {"Sport", "Fitness", "Health" },
                //"4EXFSPksRczTrQDcqIeCZHYc56Yjm6a3BDcrz8BXaTYmL3LfYn");
            //threadClient.GetAllThreads("4EXFSPksRczTrQDcqIeCZHYc56Yjm6a3BDcrz8BXaTYmL3LfYn");
            //threadClient.GetThreadsByPaging(0, 2, "4EXFSPksRczTrQDcqIeCZHYc56Yjm6a3BDcrz8BXaTYmL3LfYn");
            //threadClient.GetThreadsByCategory("Sport", "4EXFSPksRczTrQDcqIeCZHYc56Yjm6a3BDcrz8BXaTYmL3LfYn");
            //threadClient.GetAllPostsFromThread(1, "4EXFSPksRczTrQDcqIeCZHYc56Yjm6a3BDcrz8BXaTYmL3LfYn");

            //PostModel post = new PostModel()
            //{
            //    Content = "Az sum velikiq Rami :D",
            //    Rating = 0,
            //    PostDate = DateTime.Now,
            //    PostedBy = "Rami"
            //};

            //string postJson = JsonConvert.SerializeObject(post);
        }
    }
}

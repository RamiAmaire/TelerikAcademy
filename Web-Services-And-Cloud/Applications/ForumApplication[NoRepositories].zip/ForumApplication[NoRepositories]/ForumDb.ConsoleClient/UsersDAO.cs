﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using ForumDb.Models;
using ForumDb.WebAPI.Models;
using System.Text;
using System.Security.Cryptography;

namespace ForumDb.ConsoleClient
{
    public class UsersDAO
    {
        private HttpClient client;

        public UsersDAO(HttpClient inputClient)
        {
            this.client = inputClient;
        }

        private string GetSHA1HashData(string data)
        {
            SHA1 sha1 = SHA1.Create();
            byte[] hashData = sha1.ComputeHash(Encoding.Default.GetBytes(data));
            StringBuilder returnValue = new StringBuilder();
            
            for (int i = 0; i < hashData.Length; i++)
            {
                returnValue.Append(hashData[i].ToString());
            }

            return returnValue.ToString();
        }

        public IEnumerable<UserGetModel> GetAllUsers(string sessionKey)
        {
            HttpResponseMessage response = this.client.GetAsync("api/users/get-all/" + sessionKey).Result;
            if (response.IsSuccessStatusCode)
            {
                var users = response.Content.ReadAsAsync<IEnumerable<UserGetModel>>().Result;
                foreach (var user in users)
                {
                    Console.WriteLine(user.Username + " " + user.NickName);
                }

                return users;
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                return null;
            }
        }

        public void RegisterUser(string username, string nickname, string authCode)
        {
            var encryptedAuthCode = GetSHA1HashData(authCode);
            UserModel user = new UserModel(username, nickname, encryptedAuthCode);
            var response = this.client.PostAsJsonAsync("api/users/register", user).Result;
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("User {0} registered!", username);
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public void LoginUser(string username, string authCode)
        {
            var encryptedAuthCode = GetSHA1HashData(authCode);
            UserModel user = new UserModel(username, null, encryptedAuthCode);
            var response = this.client.PostAsJsonAsync("api/users/login", user).Result;
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("User {0} logined succesfully.!", username);
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public void Logout(string sessionKey)
        {
            var response = this.client.PutAsJsonAsync("api/users/logout/" + sessionKey, sessionKey).Result;
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("User logout succesfully.!");
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }
    }
}

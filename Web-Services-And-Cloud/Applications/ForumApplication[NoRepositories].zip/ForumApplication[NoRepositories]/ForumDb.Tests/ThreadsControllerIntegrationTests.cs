﻿using System;
using System.Net.Http;
using System.Transactions;
using ForumDb.WebAPI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Web.Http;
using ForumDb.WebAPI.Controllers;
using ForumDb.Models;
using System.Linq;

namespace ForumDb.Tests
{
    [TestClass]
    public class ThreadsControllerIntegrationTests
    {
        private static TransactionScope tran;
        private InMemoryHttpServer httpServer;
        private readonly string sessionKey = "8ZpZ29suGi7xV6xo7VCVse1LEkKjEgoq2PWgwfN8bs4LcdcaA3";

        [TestInitialize]
        public void TestInit()
        {
            var type = typeof(UsersController);
            tran = new TransactionScope();
            var routes = new List<Route>
            {
                new Route(
                    "DefaultActionApi",
                    "api/{controller}/{action}/{sessionKey}",
                    new { sessionKey = RouteParameter.Optional }),

                new Route(
                    "DefaultApi",
                    "api/{controller}/{id}",
                    new { id = RouteParameter.Optional }),
            };

            this.httpServer = new InMemoryHttpServer("http://localhost:55860/", routes);
        }

        [TestCleanup]
        public void TearDown()
        {
            tran.Dispose();
        }

        [TestMethod]
        public void RegisterValidUser()
        {
            using (tran)
            {
                var testUser = new UserModel()
                {
                    Username = "RamiVALID",
                    Nickname = "RamiNick",
                    AuthCode = "262092422212519622621322761772202072061971082292504435"
                };

                var response = httpServer.Post("api/users/register", testUser);
                Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

                using (var context = new ForumDbEntities())
                {
                    var registeredUser = context.Users.FirstOrDefault(u => u.Username == testUser.Username &&
                        u.Nickname == testUser.Nickname);
                    Assert.IsNotNull(registeredUser);
                    Assert.IsNotNull(registeredUser.SessionKey);
                }
            }
        }

        [TestMethod]
        public void Register_Invalid_RegisterAlreadyRegisteredUser()
        {
            using (tran)
            {
                var testUser = new UserModel()
                {
                    Username = "RamiVALID",
                    Nickname = "RamiNick",
                    AuthCode = "262092422212519622621322761772202072061971082292504435"
                };

                var response = httpServer.Post("api/users/register", testUser);
                Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

                var testUser1 = new UserModel()
                {
                    Username = "RamiVALID",
                    Nickname = "RamiNick",
                    AuthCode = "262092422212519622621322761772202072061971082292504435"
                };

                response = httpServer.Post("api/users/register", testUser1);
                //var msg = response.Content.ReadAsStringAsync();
                //var excMessage = msg.Result;
                Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode);
            }
        }

        [TestMethod]
        public void GetAllUsers()
        {
            using (tran)
            {
                var testUser = new UserModel()
                {
                    Username = "RamiVALID",
                    Nickname = "RamiNick",
                    AuthCode = "262092422212519622621322761772202072061971082292504435"
                };

                var getAllUsersResponse = httpServer.Get("api/users/get-all/" + sessionKey);
                var users = getAllUsersResponse.Content.ReadAsAsync<IEnumerable<UserGetModel>>().Result;
                int usersCount = users.Count();

                var registerUserResponse = httpServer.Post("api/users/register", testUser);
                Assert.AreEqual(HttpStatusCode.OK, registerUserResponse.StatusCode);
 
                var getAllUsersUpdatedResponse = httpServer.Get("api/users/get-all/" + sessionKey);
                var updatedUsers = getAllUsersResponse.Content.ReadAsAsync<IEnumerable<UserGetModel>>().Result;
                Assert.AreEqual(usersCount + 1, updatedUsers.Count());
            }
        }

        [TestMethod]
        public void LoginUser_Valid()
        {
            using (tran)
            {
                var testUser = new UserModel()
                {
                    Username = "RamiAmaire",
                    AuthCode = "262092422212519622621322761772202072061971082292504435"
                };

                var loginUserResponse = httpServer.Post("api/users/login", testUser);
                Assert.AreEqual(HttpStatusCode.OK, loginUserResponse.StatusCode);
                using (var context = new ForumDbEntities())
                {
                    var user = context.Users.FirstOrDefault(u => u.Username == testUser.Username);
                    Assert.IsNotNull(user);
                    Assert.IsNotNull(user.SessionKey);
                }
            }
        }

        [TestMethod]
        public void LoginUser_Invalid_LoggingAlreadyLoggedUser()
        {
            using (tran)
            {
                var testUser = new UserModel()
                {
                    Username = "RamiAmaire",
                    AuthCode = "262092422212519622621322761772202072061971082292504435"
                };

                var loginUserResponse = httpServer.Post("api/users/login", testUser);
                Assert.AreEqual(HttpStatusCode.OK, loginUserResponse.StatusCode);

                var loginUserUpdatedResponse = httpServer.Post("api/users/login", testUser);
                Assert.AreEqual(HttpStatusCode.BadRequest, loginUserUpdatedResponse.StatusCode);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Http.Dependencies;
using CSN.Api.Controllers;
using DSN.Models;
using DSN.Repos;

namespace CSN.Api.Resolvers
{
    public class DbDependencyResolver : IDependencyResolver
    {
        private static CSNDbEntities dbContext = new CSNDbEntities();
        private static IRepository<User> usersRepo = new EfRepository<User>(dbContext);
        private static IRepository<Article> articlesRepo = new EfRepository<Article>(dbContext);
        private static IRepository<Comment> commentsRepo = new EfRepository<Comment>(dbContext);
        private static IRepository<Vote> votesRepo = new EfRepository<Vote>(dbContext);

        public IDependencyScope BeginScope()
        {
            return this;
        }

        public object GetService(Type serviceType)
        {
            if (serviceType == typeof(UsersController))
            {
                return new UsersController(usersRepo, articlesRepo, votesRepo, commentsRepo);
            }
            else if (serviceType == typeof(ArticlesController))
            {
                return new ArticlesController(articlesRepo, usersRepo);
            }
            else if (serviceType == typeof(VotesController))
            {
                return new VotesController(votesRepo);
            }
            else if (serviceType == typeof(CommentsController))
            {
                return new CommentsController(commentsRepo);
            }
            else
            {
                return null;
            }
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            return new List<object>();
        }

        public void Dispose()
        {
        }
    }
}
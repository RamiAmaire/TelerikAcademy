﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CSN.Api.Models
{
    public class FullUserModel : UserModel
    {
        public FullUserModel()
            :base()
        {
            this.Articles = new HashSet<ArticleModel>();
            this.Votes = new HashSet<VoteModel>();
            this.Comments = new HashSet<CommentModel>();
        }

        public virtual ICollection<ArticleModel> Articles { get; set; }

        public virtual ICollection<VoteModel> Votes { get; set; }

        public virtual ICollection<CommentModel> Comments { get; set; }
    }
}
﻿using System;

namespace CSN.Api.Models
{
    public class LoggedUserModel
    {
        public string Username { get; set; }

        public string SessionKey { get; set; }
    }
}
﻿using System;

namespace CSN.Api.Models
{
    public class ArticleModel
    {
        public string Title { get; set; }

        public string Content { get; set; }
    }
}
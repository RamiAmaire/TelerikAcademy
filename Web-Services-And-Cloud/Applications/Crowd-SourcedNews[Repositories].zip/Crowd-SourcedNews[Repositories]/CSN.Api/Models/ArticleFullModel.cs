﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CSN.Api.Models
{
    public class ArticleFullModel : ArticleModel
    {
        public ArticleFullModel()
            :base()
        {
            this.Votes = new HashSet<VoteModel>();
            this.Comments = new HashSet<CommentModel>();
        }

        public virtual ICollection<VoteModel> Votes { get; set; }

        public virtual ICollection<CommentModel> Comments { get; set; }

        public int UserId { get; set; }

        public virtual UserModel User { get; set; }
    }
}
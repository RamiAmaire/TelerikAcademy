﻿using DSN.Repos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DSN.Models;
using CSN.Api.Models;
using System.Text;
using Newtonsoft.Json;

namespace CSN.Api.Controllers
{
    public class UsersController : ApiController
    {
        private const string SessionKeyChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        private const int SessionKeyLen = 50;
        private static Random rand = new Random();
        private IRepository<User> userRepo;
        private IRepository<Article> articleRepo;
        private IRepository<Vote> voteRepo;
        private IRepository<Comment> commentRepo;
        
        public UsersController(IRepository<User> inputUserRepo, IRepository<Article> inputArticleRepo,
            IRepository<Vote> inputVoteRepo, IRepository<Comment> inputCommentRepo)
        {
            this.userRepo = inputUserRepo;
            this.articleRepo = inputArticleRepo;
            this.voteRepo = inputVoteRepo;
            this.commentRepo = inputCommentRepo;
        }

        private static string GenerateSessionKey(int userId)
        {
            StringBuilder keyChars = new StringBuilder(50);
            keyChars.Append(userId.ToString());
            while (keyChars.Length < SessionKeyLen)
            {
                int randomCharNum;
                lock (rand)
                {
                    randomCharNum = rand.Next(SessionKeyChars.Length);
                }
                char randomKeyChar = SessionKeyChars[randomCharNum];
                keyChars.Append(randomKeyChar);
            }
            string sessionKey = keyChars.ToString();
            return sessionKey;
        }

        [HttpGet]
        [ActionName("get-all")]
        public IEnumerable<UserModel> GetAll()
        {
            var userEntities = this.userRepo.All();
            var userModelEntities = from userEntity in userEntities
                                    select new UserModel()
                                    {
                                        Username = userEntity.Username,
                                        Password = userEntity.Password
                                    };
            return userModelEntities;
        }

        [HttpGet]
        [ActionName("get-single")]
        public FullUserModel GetSingle(int id)
        {
            User user = this.userRepo.Get(id);
            FullUserModel userModel = new FullUserModel()
            {
                Username = user.Username,
                Password = user.Password,
                Articles = (from userArticle in user.Articles
                           select new ArticleModel()
                           {
                                Title = userArticle.Title,
                                Content = userArticle.Content
                           }).ToList(),
                Votes = (from vote in user.Votes
                            select new VoteModel()
                            {
                                ArticleId = vote.ArticleId,
                                Value = vote.Value
                            }).ToList(),
                Comments = (from comment in user.Comments
                         select new CommentModel()
                         {
                            ArticleId = comment.ArticleId,
                            Content  = comment.Content,
                            Title = comment.Title
                         }).ToList()
            };

            return userModel;
        }

        [HttpPost]
        [ActionName("Register")]
        public HttpResponseMessage Register([FromBody] UserModel user)
        {
            if (userRepo.All().FirstOrDefault(u => u.Username == user.Username && u.Password == user.Password) != null)
            {
                this.Request.CreateErrorResponse(HttpStatusCode.BadGateway, "Username already exists.");
            }

            User us = new User()
            {
                Username = user.Username,
                Password = user.Password
            };

            userRepo.Add(us);
            us.SessionKey = GenerateSessionKey(us.Id);
            userRepo.Update(us.Id, us);
            LoggedUserModel loggedUser = new LoggedUserModel() { Username = us.Username, SessionKey = us.SessionKey };
            return this.Request.CreateResponse(HttpStatusCode.OK, loggedUser);
        }

        [HttpGet]
        [ActionName("Logout")]
        public void Logout(string sessionKey)
        {
            User user = userRepo.All().FirstOrDefault(u => u.SessionKey == sessionKey);
            user.SessionKey = null;
            userRepo.Update(user.Id, user);
        }

        [HttpPost]
        [ActionName("Login")]
        public HttpResponseMessage Login([FromBody] UserModel user)
        {
            User us = userRepo.All().FirstOrDefault(u => u.Username == user.Username && u.Password == user.Password);
            us.SessionKey = GenerateSessionKey(us.Id);
            userRepo.Update(us.Id, us);
            LoggedUserModel loggedUser = new LoggedUserModel() { Username = us.Username, SessionKey = us.SessionKey };
            return this.Request.CreateResponse(HttpStatusCode.OK, loggedUser);
        }

        [HttpPost]
        [ActionName("update")]
        public HttpResponseMessage Update(string sessionKey, UserModel us)
        {
            User user = this.userRepo.All().FirstOrDefault(u => u.SessionKey == sessionKey);
            user.Username = us.Username;
            user.Password = us.Password;
            this.userRepo.Update(user.Id, user);
            LoggedUserModel loggedUser = new LoggedUserModel(){ Username = user.Username, SessionKey = user.SessionKey};
            return this.Request.CreateResponse(HttpStatusCode.OK, loggedUser);
        }

        [HttpGet]
        [ActionName("delete")]
        public void Delete(string sessionKey)
        {
            User user = this.userRepo.All().FirstOrDefault(u => u.SessionKey == sessionKey);
            this.userRepo.Delete(user);
        }

        [HttpPost]
        [ActionName("publish")]
        public HttpResponseMessage Publish(string sessionKey, ArticleModel art)
        {
            User user = this.userRepo.All().FirstOrDefault(u => u.SessionKey == sessionKey);
            Article article = new Article() { Title = art.Title, Content = art.Content };
            user.Articles.Add(article);
            this.userRepo.Update(user.Id, user);
            return this.Request.CreateResponse(HttpStatusCode.OK, art);
        }

        [HttpPost]
        [ActionName("Vote")]
        public HttpResponseMessage Vote(string sessionKey, VoteModel v)
        {
            User user = this.userRepo.All().FirstOrDefault(u => u.SessionKey == sessionKey);
            int voteId = this.voteRepo.All().Count() + 1;
            Vote vote = new Vote() { Id = voteId, Value = v.Value, ArticleId = v.ArticleId, UserId = user.Id };
            this.voteRepo.Add(vote);
            user.Votes.Add(vote);
            this.userRepo.Update(user.Id, user);
            return this.Request.CreateResponse(HttpStatusCode.OK, v);
        }

        [HttpPost]
        [ActionName("Comment")]
        public HttpResponseMessage Comment(string sessionKey, CommentModel value)
        {
            User user = this.userRepo.All().FirstOrDefault(u => u.SessionKey == sessionKey);
            Comment comment = new Comment() { Title = value.Title, Content = value.Content, ArticleId = value.ArticleId, UserId = user.Id };
            this.commentRepo.Add(comment);
            user.Comments.Add(comment);
            this.userRepo.Update(user.Id, user);
            return this.Request.CreateResponse(HttpStatusCode.OK, value);
        }
    }
}

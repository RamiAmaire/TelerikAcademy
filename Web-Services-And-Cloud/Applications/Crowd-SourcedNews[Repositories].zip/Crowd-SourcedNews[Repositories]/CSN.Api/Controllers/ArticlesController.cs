﻿using CSN.Api.Models;
using DSN.Models;
using DSN.Repos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CSN.Api.Controllers
{
    public class ArticlesController : ApiController
    {
        private IRepository<Article> articlesRepo;
        private IRepository<User> usersRepo;

        public ArticlesController(IRepository<Article> inputArticleRepo, IRepository<User> inputUserRepo)
        {
            this.articlesRepo = inputArticleRepo;
            this.usersRepo = inputUserRepo;
        }

        [HttpGet]
        [ActionName("get-all")]
        public IEnumerable<ArticleModel> GetAll()
        {
            var articleEntities = this.articlesRepo.All();
            var articleModelEntities = from articleEntity in articleEntities
                                    select new ArticleModel()
                                    {
                                        Content = articleEntity.Content,
                                        Title = articleEntity.Title
                                    };
            return articleModelEntities;
        }

        [HttpGet]
        [ActionName("get-single")]
        public ArticleFullModel GetSingle(int id)
        {
            Article article = this.articlesRepo.Get(id);
            ArticleFullModel articleModel = new ArticleFullModel()
            {
                Content = article.Content,
                Title = article.Title,
                User = new UserModel() {Username = article.User.Username, Password = article.User.Password },
                UserId = article.UserId,
                Votes = (from vote in article.Votes
                         select new VoteModel()
                         {
                             ArticleId = vote.ArticleId,
                             Value = vote.Value
                         }).ToList(),
                Comments = (from comment in article.Comments
                            select new CommentModel()
                            {
                                ArticleId = comment.ArticleId,
                                Title = comment.Title,
                                Content = comment.Content
                            }).ToList(),
            };

            return articleModel;
        }

        [HttpPost]
        [ActionName("update")]
        public HttpResponseMessage Update(int id, [FromBody]ArticleModel value)
        {
            Article article = this.articlesRepo.All().FirstOrDefault(a => a.Id == id);
            article.Title = value.Title;
            article.Content = value.Content;
            this.articlesRepo.Update(article.Id, article);
            return this.Request.CreateResponse(HttpStatusCode.OK, value);
        }

        // DELETE articles/5
        public void Delete(int id)
        {
            this.articlesRepo.Delete(id);
        }
    }
}

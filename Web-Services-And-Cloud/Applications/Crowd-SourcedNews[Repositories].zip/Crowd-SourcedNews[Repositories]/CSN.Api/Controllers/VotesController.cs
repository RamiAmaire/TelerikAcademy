﻿using CSN.Api.Models;
using DSN.Models;
using DSN.Repos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CSN.Api.Controllers
{
    public class VotesController : ApiController
    {
        private IRepository<Vote> votesRepo;

        public VotesController(IRepository<Vote> inputRepo)
        {
            this.votesRepo = inputRepo;
        }

        [HttpGet]
        [ActionName("get-all")]
        public IEnumerable<VoteModel> Get()
        {
            var voteEntities = this.votesRepo.All();
            var voteModelEntities = from voteEntity in voteEntities
                                    select new VoteModel()
                                    {
                                        Value = voteEntity.Value,
                                        ArticleId = voteEntity.ArticleId
                                    };

            return voteModelEntities;
        }

        [HttpGet]
        [ActionName("get-single")]
        public VoteModel Get(int id)
        {
            Vote currentVote = this.votesRepo.Get(id);
            VoteModel voteModel = new VoteModel() { Value = currentVote.Value, ArticleId = currentVote.ArticleId };
            return voteModel;
        }

        //// POST api/votes
        //public void Post([FromBody]string value)
        //{
        //}

        //// PUT api/votes/5
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        // DELETE api/votes/5
        public void Delete(int id)
        {
            this.votesRepo.Delete(id);
        }
    }
}

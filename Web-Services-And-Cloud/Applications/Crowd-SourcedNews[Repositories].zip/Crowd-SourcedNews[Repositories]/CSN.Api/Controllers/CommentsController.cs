﻿using CSN.Api.Models;
using DSN.Models;
using DSN.Repos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CSN.Api.Controllers
{
    public class CommentsController : ApiController
    {
        private IRepository<Comment> commentsRepo;

        public CommentsController(IRepository<Comment> inputRepo)
        {
            this.commentsRepo = inputRepo;
        }

        [HttpGet]
        [ActionName("get-all")]
        public IEnumerable<CommentModel> Get()
        {
            var commentEtities = this.commentsRepo.All();
            var commentModelEntities = from commentModelEntity in commentEtities
                                       select new CommentModel()
                                       {
                                           Title = commentModelEntity.Title,
                                           Content = commentModelEntity.Content,
                                           ArticleId = commentModelEntity.ArticleId
                                       };

            return commentModelEntities;
        }

        [HttpGet]
        [ActionName("get-single")]
        public CommentFullModel Get(int id)
        {
            Comment comment = this.commentsRepo.Get(id);
            CommentFullModel commentFullModel = new CommentFullModel()
            {
                Title = comment.Title,
                Content = comment.Content,
                Article = new ArticleModel(){ Title = comment.Article.Title, Content = comment.Article.Content},
                User = new UserModel(){ Username = comment.User.Username, Password = comment.User.Password},
                ArticleId = comment.ArticleId,
                UserId = comment.UserId   
            };

            return commentFullModel;
        }

        [HttpPost]
        [ActionName("update")]
        public HttpResponseMessage Update(int id, [FromBody]CommentModel value)
        {
            Comment comment = this.commentsRepo.All().FirstOrDefault(a => a.Id == id);
            comment.Title = value.Title;
            comment.Content = value.Content;
            comment.ArticleId = value.ArticleId;
            this.commentsRepo.Update(comment.Id, comment);
            return this.Request.CreateResponse(HttpStatusCode.OK, value);
        }

        // DELETE comment/5
        public void Delete(int id)
        {
            this.commentsRepo.Delete(id);
        }
    }
}

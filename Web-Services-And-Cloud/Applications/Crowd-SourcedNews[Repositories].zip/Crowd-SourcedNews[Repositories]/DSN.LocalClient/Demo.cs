﻿using System;
using System.Collections.Generic;
using System.Linq;
using DSN.Models;
using System.Net.Http;
using System.Net.Http.Headers;

namespace DSN.LocalClient
{
    public class Demo
    {
        public static IEnumerable<User> ListUsers()
        {
            HttpResponseMessage response = Client.GetAsync("api/users").Result;
            if (response.IsSuccessStatusCode)
            {
                var users = response.Content.ReadAsAsync<IEnumerable<User>>().Result;
                foreach (var user in users)
                {
                    Console.WriteLine(user.Id + " " + user.Username + " " + user.Password);
                }

                return users;
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                return null;
            }
        }

        public static void AddNewUser(string username, string password)
        {
            User user = new User() { Username = username, Password = password };
            var response = Client.PostAsJsonAsync("api/users", user).Result;
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("User {0} added!", username);
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        private static HttpClient Client = new HttpClient { BaseAddress = new Uri("http://localhost:64242/") };

        public static void Main()
        {
            //Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //ListUsers();
            //AddNewUser("Rambo", "killer");

            CSNDbEntities dbContext = new CSNDbEntities();
            using (dbContext)
            {
                foreach (var vote in dbContext.Votes)
                {
                    Console.WriteLine(vote.User.Username + "/" + vote.Article.Title + "-" + vote.Article.Content + " - " + vote.Value);
                }

                dbContext.SaveChanges();
            }
        }
    }
}

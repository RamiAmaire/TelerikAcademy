﻿using Error_Handler_Control;
using LibrarySystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.ModelBinding;

namespace LibrarySystem.Web.Admin
{
    public partial class EditCategories : System.Web.UI.Page
    {
        private bool inEdit = false;
        private bool inDelete = false;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public IQueryable<Category> GridViewCategories_GetData()
        {
            var context = new LibrarySystemEntities();
            var categories = context.Categories.Include("Books").AsQueryable<Category>();
            return categories;
        }

        protected void LinkButtonEditCategory_Click(object sender, EventArgs e)
        {
            inEdit = true;
        }

        protected void LinkButtonDeleteCategory_Click(object sender, EventArgs e)
        {
            inDelete = true;
        }

        protected void LinkButtonCreateNewCategory_Click(object sender, EventArgs e)
        {
            this.PanelCreateCategory.Visible = true;
            this.PanelDeleteCategory.Visible = false;
            this.PanelEditCategory.Visible = false;
        }

        public void FormViewCreateCategory_InsertItem()
        {
            var category = new Category();
            TryUpdateModel(category);
            if (ModelState.IsValid)
            {
                var context = new LibrarySystemEntities();
                foreach (var cat in context.Categories)
                {
                    if (cat.Name == category.Name)
                    {
                        ModelState.AddModelError("", 
                            "Such category name already exists. Creating new category failed.");
                        return;
                    }
                }

                context.Categories.Add(category);
                try
                {
                    context.SaveChanges();
                    ErrorSuccessNotifier.AddSuccessMessage("Category " + category.Name + " created.");
                    this.GridViewCategories.DataBind();
                    this.PanelCreateCategory.Visible = false;
                }
                catch (Exception ex)
                {
                    ErrorSuccessNotifier.AddErrorMessage(ex);
                }
            }
        }

        protected void CancelCreateCategory_Click(object sender, EventArgs e)
        {
            this.PanelCreateCategory.Visible = false;
        } 

        protected void GridViewCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (inEdit == true)
            {
                this.PanelEditCategory.Visible = true;
                this.PanelCreateCategory.Visible = false;
                this.PanelDeleteCategory.Visible = false;
                this.PanelEditCategory.DataBind();
            }

            if (inDelete == true)
            {
                this.PanelDeleteCategory.Visible = true;
                this.PanelEditCategory.Visible = false;
                this.PanelCreateCategory.Visible = false;
                this.PanelDeleteCategory.DataBind();
            }
        }

        public Category FormViewCategoryDelete_GetItem()
        {
            string categoryId = this.GridViewCategories.SelectedValue.ToString();
            int currentCategoryId = int.Parse(categoryId);
            var context = new LibrarySystemEntities();
            var currentCategory = context.Categories.FirstOrDefault(c => c.CategoryId == currentCategoryId);
            return currentCategory;
        }

        public void FormViewCategoryDelete_DeleteItem(int categoryId)
        {
            var context = new LibrarySystemEntities();
            var currentCategory = context.Categories.FirstOrDefault(c => c.CategoryId == categoryId);
            var currentCategoryBooks = currentCategory.Books.ToList();
            foreach (var book in currentCategoryBooks)
            {
                currentCategory.Books.Remove(book);
            }

            try
            {
                context.SaveChanges();
                context.Categories.Remove(currentCategory);
                context.SaveChanges();
                ErrorSuccessNotifier.AddSuccessMessage("Category " + currentCategory.Name + " deleted.");
                this.GridViewCategories.DataBind();
                this.PanelDeleteCategory.Visible = false;
            }
            catch (Exception ex)
            {
                ErrorSuccessNotifier.AddErrorMessage(ex);
            }
        }

        protected void CancelDeleteCategory_Click(object sender, EventArgs e)
        {
            this.PanelDeleteCategory.Visible = false;
        }

        public Category FormViewCategoryEdit_GetItem()
        {
            string categoryId = this.GridViewCategories.SelectedValue.ToString();
            int currentCategoryId = int.Parse(categoryId);
            var context = new LibrarySystemEntities();
            var currentCategory = context.Categories.FirstOrDefault(c => c.CategoryId == currentCategoryId);
            return currentCategory;
        }

        public void FormViewCategoryEdit_UpdateItem(int categoryId)
        {
            var context = new LibrarySystemEntities();
            var category = context.Categories.FirstOrDefault(c => c.CategoryId == categoryId);
            if (category == null)
            {
                ModelState.AddModelError("", "Category was not found");
                return;
            }

            foreach (var cat in context.Categories)
            {
                if (cat.Name == category.Name && cat.CategoryId  != category.CategoryId)
                {
                    ModelState.AddModelError("",
                        "Such category name already exists. Creating new category failed.");
                    return;
                }
            }

            TryUpdateModel(category);
            if (ModelState.IsValid)
            {
                try
                {
                    context.SaveChanges();
                    ErrorSuccessNotifier.AddSuccessMessage("Category updated.");
                    this.GridViewCategories.DataBind();
                    this.PanelEditCategory.Visible = false;
                }
                catch (Exception ex)
                {
                    ErrorSuccessNotifier.AddErrorMessage(ex);
                }
            }
        }

        protected void CancelEditCategory_Click(object sender, EventArgs e)
        {
            this.PanelEditCategory.Visible = false;
        }

        protected void LinkButtonBackToBooks_Click(object sender, EventArgs e)
        {
            this.Response.Redirect("~/Default");
        }
    }
}
﻿using Error_Handler_Control;
using LibrarySystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibrarySystem.Web.Admin
{
    public partial class EditBooks : System.Web.UI.Page
    {
        private bool inEdit = false;
        private bool inDelete = false;

        protected List<Category> categories()
        {
            var context = new LibrarySystemEntities();
            return context.Categories.ToList();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var ddlCategories = this.FormViewCreateBook.FindControl("DropDownListCategories") as DropDownList;
                ddlCategories.DataSource = this.categories();
                ddlCategories.DataBind();

                this.DropDownListEditCategory.DataSource = this.categories();
                this.DropDownListEditCategory.DataBind();
            }
        }
        public IQueryable<Book> GridViewBooks_GetData()
        {
            var context = new LibrarySystemEntities();
            var books = context.Books.Include("Category").AsQueryable<Book>();
            return books;
        }

        protected void GridViewBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (inEdit == true)
            {
                this.PanelEditBook.Visible = true;
                this.PanelCreateBook.Visible = false;
                this.PanelDeleteBook.Visible = false;
                this.PanelCategory.Visible = false;
                this.PanelEditBook.DataBind();
            }

            if (inDelete == true)
            {
                this.PanelDeleteBook.Visible = true;
                this.PanelEditBook.Visible = false;
                this.PanelCreateBook.Visible = false;
                this.PanelCategory.Visible = false;
                this.PanelDeleteBook.DataBind();
            }
        }

        protected void LinkButtonEditBook_Click(object sender, EventArgs e)
        {
            inEdit = true;
        }

        protected void LinkButtonDeleteBook_Click(object sender, EventArgs e)
        {
            inDelete = true;
        }

        protected void LinkButtonCreateNewBook_Click(object sender, EventArgs e)
        {
            this.PanelCreateBook.Visible = true;
            this.PanelCategory.Visible = false;
            this.PanelDeleteBook.Visible = false;
            this.PanelEditBook.Visible = false;
        }

        public void FormViewCreateBook_InsertItem()
        {
            var ddlCategories = this.FormViewCreateBook.FindControl("DropDownListCategories") as DropDownList;
            var selectedValue = ddlCategories.SelectedValue;
            int selectedCategoryId = int.Parse(selectedValue);
            var context = new LibrarySystemEntities();
            var selectedCategory = context.Categories.FirstOrDefault(c => c.CategoryId == selectedCategoryId);
 
            var book = new Book();
            TryUpdateModel(book);
            if (ModelState.IsValid)
            {
                book.Category = selectedCategory;
                context.Books.Add(book);
                try
                {
                    context.SaveChanges();
                    ErrorSuccessNotifier.AddSuccessMessage("Book " + book.Title + " created.");
                    this.GridViewBooks.DataBind();
                    this.PanelCreateBook.Visible = false;
                }
                catch (Exception ex)
                {
                    ErrorSuccessNotifier.AddErrorMessage(ex);
                }
            }
        }

        protected void CancelCreateBook_Click(object sender, EventArgs e)
        {
            this.PanelCreateBook.Visible = false;
        }

        public Book FormViewBookEdit_GetItem()
        {
            string bookId = this.GridViewBooks.SelectedValue.ToString();
            int currentBookId = int.Parse(bookId);
            var context = new LibrarySystemEntities();
            var currentBook = context.Books.FirstOrDefault(c => c.BookId == currentBookId);
            this.DropDownListEditCategory.SelectedValue = currentBook.CategoryId.ToString();
            this.PanelCategory.Visible = true;
            return currentBook;
        }

        public void FormViewBookEdit_UpdateItem(int bookId)
        {
            var context = new LibrarySystemEntities();
            var book = context.Books.FirstOrDefault(b => b.BookId == bookId);
            if (book == null)
            {
                ModelState.AddModelError("", "Book was not found");
                return;
            }

            string selectedCategoryValue = this.DropDownListEditCategory.SelectedValue;
            int categoryId = int.Parse(selectedCategoryValue);
            var selectedCategory = context.Categories.FirstOrDefault(c => c.CategoryId == categoryId);
            if (book.Category != selectedCategory)
            {
                book.Category = selectedCategory;
            }

            TryUpdateModel(book);
            if (ModelState.IsValid)
            {
                try
                {
                    context.SaveChanges();
                    ErrorSuccessNotifier.AddSuccessMessage("Book updated.");
                    this.GridViewBooks.DataBind();
                    this.PanelEditBook.Visible = false;
                    this.PanelCategory.Visible = false;
                }
                catch (Exception ex)
                {
                    ErrorSuccessNotifier.AddErrorMessage(ex);
                }
            }
        }

        protected void CancelEditBook_Click(object sender, EventArgs e)
        {
            this.PanelEditBook.Visible = false;
        }

        public Book FormViewBookDelete_GetItem()
        {
            string bookId = this.GridViewBooks.SelectedValue.ToString();
            int currentBookId = int.Parse(bookId);
            var context = new LibrarySystemEntities();
            var currentBook = context.Books.FirstOrDefault(c => c.BookId == currentBookId);
            return currentBook;
        }

        public void FormViewBookDelete_DeleteItem(int bookId)
        {
            var context = new LibrarySystemEntities();
            var currentBook = context.Books.FirstOrDefault(c => c.BookId == bookId);
            context.Books.Remove(currentBook);

            try
            {
                context.SaveChanges();
                ErrorSuccessNotifier.AddSuccessMessage("Book " + currentBook.Title + " deleted.");
                this.GridViewBooks.DataBind();
                this.PanelDeleteBook.Visible = false;
            }
            catch (Exception ex)
            {
                ErrorSuccessNotifier.AddErrorMessage(ex);
            }
        }

        protected void CancelDeleteBook_Click(object sender, EventArgs e)
        {
            this.PanelDeleteBook.Visible = false;
        }

        protected void LinkButtonBackToBooks_Click(object sender, EventArgs e)
        {
            this.Response.Redirect("~/Default");
        }
    }
}
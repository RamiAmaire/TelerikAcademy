﻿using LibrarySystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.ModelBinding;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibrarySystem.Web
{
    public partial class BookDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public Book FormViewBookDetails_GetItem([QueryString]int bookId)
        {
            var context = new LibrarySystemEntities();
            var currentBook = context.Books.FirstOrDefault(b => b.BookId == bookId);
            if (currentBook == null)
            {
                ModelState.AddModelError("", "Selected book doesn't exist in the database anymore.");
                return null;
            }

            return currentBook;
        }

        protected void LinkButtonBackToBooks_Click(object sender, EventArgs e)
        {
            this.Response.Redirect("~/Default");
        }
    }
}
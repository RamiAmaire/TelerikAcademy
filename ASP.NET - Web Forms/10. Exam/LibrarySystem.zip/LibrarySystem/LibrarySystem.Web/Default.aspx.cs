﻿using LibrarySystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.ModelBinding;

namespace LibrarySystem.Web
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public IQueryable<Category> ListViewAllCategories_GetData()
        {
            var context = new LibrarySystemEntities();
            var categories = context.Categories.Include("Books").AsQueryable<Category>();
            return categories;
        }

        protected void ButtonSearchBookQuery_Click(object sender, EventArgs e)
        {
            string queryBookValue = this.TextBoxBookQuery.Text;
            Response.Redirect("~/Search?q=" + queryBookValue);
        }
    }
}
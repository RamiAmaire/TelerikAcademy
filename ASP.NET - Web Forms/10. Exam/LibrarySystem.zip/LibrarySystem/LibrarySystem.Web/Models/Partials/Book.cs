﻿using System;
using System.Collections.Generic;
using System.Web.DynamicData;
using System.ComponentModel.DataAnnotations;

namespace LibrarySystem.Web.Models
{
    [MetadataType(typeof(BookMetaData))]
    public partial class Book
    {
    }

    public class BookMetaData
    {
        [Key]
        [ScaffoldColumn(false)]
        public int BookId { get; set; }

        [Required, MinLength(6), MaxLength(150)]
        public string Title { get; set; }

        [Required, MinLength(6), MaxLength(150)]
        public string Author { get; set; }

        [MaxLength(2500)]
        public string Content { get; set; }

        [MinLength(6), MaxLength(150)]
        public string ISBN { get; set; }

        [MinLength(10), MaxLength(256)]
        public string WebSite { get; set; }

        [ScaffoldColumn(false)]
        public int CategoryId { get; set; }

        public virtual Category Category { get; set; }
    }
}
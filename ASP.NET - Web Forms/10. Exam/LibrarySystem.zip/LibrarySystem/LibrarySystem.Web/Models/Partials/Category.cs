﻿using System;
using System.Collections.Generic;
using System.Web.DynamicData;
using System.ComponentModel.DataAnnotations;

namespace LibrarySystem.Web.Models
{
    [MetadataType(typeof(CategoryMetaData))]
    public partial class Category
    {
    }

    public class CategoryMetaData
    {
        [Key]
        [ScaffoldColumn(false)]
        public int CategoryId { get; set; }

        [Required, MinLength(6), MaxLength(150)]
        public string Name { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.ModelBinding;
using LibrarySystem.Web.Models;

namespace LibrarySystem.Web
{
    public partial class Search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public IQueryable<Book> ListViewSearch_GetData([QueryString]string q)
        {
            var context = new LibrarySystemEntities();
            this.SearchTitle.InnerText += " " + '\'' + q + '\'' + ":";
            if (q == string.Empty)
            {
                return context.Books.OrderBy(b => b.Title).AsQueryable<Book>();
            }

            var books = context.Books.Include("Category").
                Where(b => b.Title.Contains(q) || b.Author.Contains(q)).OrderBy(b => b.Title).AsQueryable<Book>();

            return books;
        }

        protected void LinkButtonBackToBooks_Click(object sender, EventArgs e)
        {
            this.Response.Redirect("~/Default");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InternationCompany.Bulgarian
{
    public partial class BulgarianSite : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LanguageDdl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.LanguageDdl.SelectedIndex == 1)
            {
                Response.Redirect("~/English/Home.aspx");
            }
            else
            {
                Response.Redirect("~/Bulgarian/Home.aspx");
            }
        }
    }
}
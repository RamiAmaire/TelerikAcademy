﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InternationCompany.English
{
    public partial class EnglishSite : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LanguageDdl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.LanguageDdl.SelectedIndex == 1)
	        {
                Response.Redirect("~/Bulgarian/Home.aspx");
	        }
            else
            {
                Response.Redirect("~/English/Home.aspx");
            }
        }
    }
}
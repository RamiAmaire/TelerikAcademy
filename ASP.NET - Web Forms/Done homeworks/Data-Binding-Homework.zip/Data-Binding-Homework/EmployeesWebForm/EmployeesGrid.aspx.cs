﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Northwind.Data;

namespace EmployeesWebForm
{
    public partial class Employees : System.Web.UI.Page
    {
        protected List<Employee> GetAllEmployees()
        {
            using (var context = new northwindEntities())
            {
                var allEmployees = context.Employees.ToList();
                return allEmployees;
            }
        }

        public Employee GetEmployee(int id)
        {
            Employee emp = this.GetAllEmployees()[id - 1];
            return emp;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Page.DataBind();
            }
        }

        protected void EmployeesGrid_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.EmployeesGrid.PageIndex = e.NewPageIndex;
            this.EmployeesGrid.DataSource = this.GetAllEmployees();
            this.EmployeesGrid.DataBind();
        }
    }
}
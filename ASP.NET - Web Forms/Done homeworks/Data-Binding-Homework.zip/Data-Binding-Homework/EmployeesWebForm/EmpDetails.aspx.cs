﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EmployeesWebForm;
using Northwind.Data;

namespace EmployeesWebForm
{
    public partial class EmpDetails : System.Web.UI.Page
    {
        private List<Employee> GetSelectedEmployees(int id)
        {
            Employees empClass = new Employees();
            Employee selectedEmployee = empClass.GetEmployee(id);
            List<Employee> selectedEmployees = new List<Employee>() { selectedEmployee };
            return selectedEmployees;
        }

        private void DisplayWithDetailsView(int id)
        {
            this.EmployeeDetails.DataSource = this.GetSelectedEmployees(id);
            this.EmployeeDetails.DataBind();
        }

        private void DisplayWithFormView(int id)
        {
            this.EmployeeFormView.DataSource = this.GetSelectedEmployees(id);
            this.EmployeeFormView.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Params["id"] == null)
            {
                Response.Redirect("EmployeesGrid.aspx");
            }
            else
            {
                int id = int.Parse(Request.Params["id"]);
                this.DisplayWithDetailsView(id);
                //this.DisplayWithFormView(id);
            }
        }

        protected void ButtonGoBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeesGrid.aspx");
        }
    }
}
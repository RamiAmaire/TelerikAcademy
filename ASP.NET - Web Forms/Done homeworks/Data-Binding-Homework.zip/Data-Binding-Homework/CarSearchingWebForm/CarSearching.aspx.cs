﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CarSearchingWebForm
{
    public partial class CarSearching : System.Web.UI.Page
    {
        public class Producer
        {
            public Producer(int id, string name, List<Model> models)
            {
                this.Id = id;
                this.Name = name;
                this.Models = models;
            }

            public int Id { get; set; }

            public string Name { get; set; }

            public List<Model> Models { get; set; }
        }

        public class Model
        {
            public Model(int id, string name)
            {
                this.Id = id;
                this.Name = name;
            }

            public int Id { get; set; }

            public string Name { get; set; }
        }

        public class Extra
        {
            public Extra(int id, string name)
            {
                this.Id = id;
                this.Name = name;
            }

            public int Id { get; set; }

            public string Name { get; set; }
        }

        public class Engine
        {
            public Engine(int id, string name)
            {
                this.Id = id;
                this.Name = name;
            }

            public int Id { get; set; }

            public string Name { get; set; }
        }

        protected List<Engine> GetEngines()
        {
            var engines = new List<Engine>()
            {
                new Engine(1, "Gasoline"),
                new Engine(2, "Diesel"),
                new Engine(3, "Electric"),
                new Engine(4, "Hybrid"),
            };

            return engines;
        }

        protected List<Extra> GetExtras()
        {
            var extras = new List<Extra>()
            {
                new Extra(1, "Air-Condidioning"),
                new Extra(2, "Blowjob"),
                new Extra(3, "Tit fuck"),
                new Extra(4, "Warming seats"),
            };

            return extras;
        }

        protected List<Producer> GetProducers()
        {
            var producers = new List<Producer>()
            {
                new Producer(1, "Mercedes", new List<Model>() {new Model(1, "E-Class"), new Model(2, "G-Class"),
                    new Model(3, "S-Class"), new Model(4, "CL-Class"), new Model(5, "SLS-AMG")}),

                new Producer(2, "BMW", new List<Model>() {new Model(1, "BMW-3"), new Model(2, "BMW-5"),
                    new Model(3, "BMW-7"), new Model(4, "BMW-X5"), new Model(5, "BMW-X6")}),

                new Producer(3, "Honda", new List<Model>() {new Model(1, "Fit"), new Model(2, "Civic"),
                    new Model(3, "Accord"), new Model(4, "Legend"), new Model(5, "CRV")}),
            };

            return producers;
        }

        protected List<Producer> Producers
        {
            get
            {
                return this.GetProducers();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                this.ModelsDdl.DataSource = this.Producers[0].Models;
                Page.DataBind();
            }
        }

        protected void ProducersDdl_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = this.ProducersDdl.SelectedIndex;
            this.ModelsDdl.DataSource = this.Producers[selectedIndex].Models;
            this.ModelsDdl.DataBind();
        }

        protected void ButtonSubmitQuery_Click(object sender, EventArgs e)
        {
            string selectedExtras = string.Empty;
            foreach (ListItem item in this.ExtrasCbl.Items)
            {
                if (item.Selected)
                {
                    selectedExtras += item.Text + ", ";
                }
            }

            selectedExtras = selectedExtras.Trim(new char[] { ',', ' '});
            string resultHtml = "<hr/> <div></div>" + 
                                "<div><b>Producer: </b>" + this.ProducersDdl.SelectedItem.Text + "</div>" +
                                "<div><b>Model: </b>" + this.ModelsDdl.SelectedItem.Text + "</div>" +
                                "<div><b>Extras: </b>" + selectedExtras + "</div>" +
                                "<div><b>Engine: </b>" + this.EnginesRbl.SelectedItem.Text + "</div>";
            this.QueryResultHolder.Text = resultHtml;
        }
    }
}
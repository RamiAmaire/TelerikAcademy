﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GeneratingRandomNumbers___HTMLControls
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button_Submit(object sender, EventArgs e)
        {
            var rand = new Random();
            var randomNumber = rand.Next(int.Parse(this.minRangeTb.Value), int.Parse(this.maxRangeTb.Value));
            this.resultHolder.InnerText = "<b>Result: " + randomNumber + "</b>"; 
        }
    }
}
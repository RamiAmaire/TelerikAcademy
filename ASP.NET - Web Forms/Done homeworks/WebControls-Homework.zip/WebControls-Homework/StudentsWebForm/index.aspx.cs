﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentsWebForm
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button_Submit(object sender, EventArgs e)
        {
            string selectedCourses = string.Empty;
            var selectedIndices = this.coursesMs.GetSelectedIndices();
            foreach (var index in selectedIndices)
            {
                selectedCourses += this.coursesMs.Items[index] + ", ";
            }

            selectedCourses = selectedCourses.Trim(new char[]{',', ' '});

            this.regResult.InnerHtml = "<div>Fullname: " + this.Server.HtmlEncode(this.fNameTb.Text) + " " +
                                        this.Server.HtmlEncode(this.lNameTb.Text) + "</div>" +
                                       "<div>Faculty number: " + this.Server.HtmlEncode(this.facultyNumberTb.Text) + "</div>" +
                                       "<div>University: " + this.universityDdl.SelectedItem + "</div>" +
                                       "<div>Specialty: " + this.specialtyDdl.SelectedItem + "</div>" +
                                       "<div>Courses: " + selectedCourses + "</div>";
        }
    }       
}
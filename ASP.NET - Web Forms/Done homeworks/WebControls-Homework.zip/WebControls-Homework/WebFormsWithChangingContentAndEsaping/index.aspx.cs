﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebFormsWithChangingContentAndEsaping
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button_Submit(object sender, EventArgs e)
        {
            this.resultTb.Text = this.initialValueTb.Text;
            this.initialValueTb.Text = string.Empty;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GeneratingRandomNumbers
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button_Submit(object sender, EventArgs e)
        {
            var rnd = new Random();
            int minValue = int.Parse(this.minRangeTB.Text);
            int maxValue = int.Parse(this.maxRangeTB.Text);
            int randomValue = rnd.Next(minValue, maxValue);
            this.randomNumberHolder.Text = "<b>Result: " + randomValue + "</b>";
            this.minRangeTB.Text = string.Empty;
            this.maxRangeTB.Text = string.Empty;
        }
    }
}
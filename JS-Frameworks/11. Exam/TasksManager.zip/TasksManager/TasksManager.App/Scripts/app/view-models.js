﻿/// <reference path="../lib/_references.js" />
window.vmFactory = (function () {
    var persister = persisters.get("http://localhost:16183/api");
    var userPersister = persister.userPersister;
    var listPersister = persister.listPersister;
    var todoPersister = persister.todoPersister;
    var appointmentPersister = persister.appointmentPersister;

    var router = new kendo.Router();

    var Todo = Class.create({
        init: function (text, isDone) {
            this.text = text;
            this.isDone = isDone;
        }
    });

    function getDateAppointmentsModel(date) {
        return appointmentPersister.getDateAppointments(date).then(function (dateAppointments) {
            var viewModel = {
                username: localStorage["username"],
                log: function () {
                    userPersister.logout().then(function () {
                        router.navigate("/login");
                    }, function (errMsg) {
                        console.log(errMsg);
                    });
                },

                appointments: dateAppointments
            }

            return new RSVP.Promise(function (res, rej) {
                res(kendo.observable(viewModel));
            });
        });
    };

    function getTodayAppointmentsModel() {
        return appointmentPersister.getTodayAppointments().then(function (todayAppointments) {
            var viewModel = {
                username: localStorage["username"],
                log: function () {
                    userPersister.logout().then(function () {
                        router.navigate("/login");
                    }, function (errMsg) {
                        console.log(errMsg);
                    });
                },

                appointments: todayAppointments
            }

            return new RSVP.Promise(function (res, rej) {
                res(kendo.observable(viewModel));
            });
        });
    };

    function getCommingAppointmentsModel() {
        return appointmentPersister.getCommingAppointments().then(function (commingAppointments) {
            var viewModel = {
                username: localStorage["username"],
                log: function () {
                    userPersister.logout().then(function () {
                        router.navigate("/login");
                    }, function (errMsg) {
                        console.log(errMsg);
                    });
                },

                appointments: commingAppointments
            }

            return new RSVP.Promise(function (res, rej) {
                res(kendo.observable(viewModel));
            });
        });
    };

    function getCurrentAppointmentsModel() {
        return appointmentPersister.getCurrentAppointments().then(function (currentAppointments) {
            var viewModel = {
                username: localStorage["username"],
                log: function () {
                    userPersister.logout().then(function () {
                        router.navigate("/login");
                    }, function (errMsg) {
                        console.log(errMsg);
                    });
                },

                appointments: currentAppointments
            }

            return new RSVP.Promise(function (res, rej) {
                res(kendo.observable(viewModel));
            });
        });
    };

    function getAppointmentsModel() {
        return appointmentPersister.getAllAppointments().then(function (appointments) {
            var viewModel = {
                username: localStorage["username"],
                log: function () {
                    userPersister.logout().then(function () {
                        router.navigate("/login");
                    }, function (errMsg) {
                        console.log(errMsg);
                    });
                },

                appointments: appointments,

                getCurrentAppointments: function () {
                    router.navigate("/appointments/current");
                },

                getCommingAppointments: function () {
                    router.navigate("/appointments/comming");
                },

                getTodayAppointments: function () {
                    router.navigate("/appointments/today");
                },

                searchAppointmentDate: "3-3-2014",

                getDateAppointments: function () {
                    router.navigate("/appointments/" + this.get("searchAppointmentDate"));
                }
            }

            return new RSVP.Promise(function (res, rej) {
                res(kendo.observable(viewModel));
            });
        });
    };

    function getCreateAppointmentModel() {
        var viewModel = {
            username: localStorage["username"],
            log: function () {
                userPersister.logout().then(function () {
                    router.navigate("/login");
                }, function (errMsg) {
                    console.log(errMsg);
                });
            },

            subject: "Exam ASP",
            description: "Programming",
            createdAt: "02.05.2014",
            appointmentDate: "02.10.2014",
            duration: 30,

            createAppointment: function () {
                var appointmentData = {
                    subject: this.get("subject"),
                    description: this.get("description"),
                    createdAt: this.get("createdAt"),
                    appointmentDate: this.get("appointmentDate"),
                    duration: this.get("duration")
                };

                appointmentPersister.createAppointment(appointmentData).then(function () {
                    router.navigate("/");
                }, function (errMsg) {
                    console.log(errMsg);
                });
            },

            goBack: function () {
                router.navigate("/");
            },
        }

        return new RSVP.Promise(function (res, rej) {
            res(kendo.observable(viewModel));
        });
    }

    function getTodoListsModel() {
        return listPersister.getAllTodoLists().then(function (todoLists) {
            var viewModel = {
                username: localStorage["username"],
                log: function () {
                    userPersister.logout().then(function () {
                        router.navigate("/login");
                    }, function (errMsg) {
                        console.log(errMsg);
                    });
                },

                todoLists: todoLists,

                viewSingleListTodos: function () {
                    router.navigate("/lists/:id/todos");
                }
            }

            return new RSVP.Promise(function (res, rej) {
                res(kendo.observable(viewModel));
            });
        });
    };

    function getASingleListTodosModel(id) {
        return listPersister.getTodosOfAList(id).then(function (data) {
            var viewModel = {
                username: localStorage["username"],
                log: function () {
                    userPersister.logout().then(function () {
                        router.navigate("/login");
                    }, function (errMsg) {
                        console.log(errMsg);
                    });
                },
                createTodoList: function () {
                    router.navigate("/create-todolist");
                },

                title: data.title,
                todos: data.todos,
                goBack: function () {
                    router.navigate("/");
                },
                changeTodoStatus: function (ev) {
                    var target = ev.target;
                    id = target.id;
                    todoPersister.changeTodoStatus(id).then(function (data) {
                        router.navigate("/lists/" + data.id + "/todos");
                    }, function (errMsg) {
                        console.log(errMsg);
                    });
                }
            }

            return new RSVP.Promise(function (res, rej) {
                res(kendo.observable(viewModel));
            });
        }, function (errMsg) {
            console.log(errMsg);
        });
    }

    function getCreateTodoListModel() {
        var viewModel = {
            username: localStorage["username"],
            log: function () {
                userPersister.logout().then(function () {
                    router.navigate("/login");
                }, function (errMsg) {
                    console.log(errMsg);
                });
            },

            title: "Hayde na more",
            todos: [new Todo("Asd", false), new Todo("Asdf", false)],
            todoText: "",
            createTodo: function () {
                var todoData = {
                    text: this.get("todoText"),
                    isDone: false
                };
                this.get("todos").push(todoData);
                this.set("todoText", "");
            },

            goBack: function () {
                router.navigate("/");
            },

            createList: function () {
                var todoListData = {
                    title: this.get("title"),
                    todos: this.get("todos")
                };
                listPersister.createTodoList(todoListData).then(function () {
                    router.navigate("/");
                }, function (errMsg) {
                    console.log(errMsg);
                });
            },
        }

        return new RSVP.Promise(function (res, rej) {
            res(kendo.observable(viewModel));
        });
    };

    function getLoggedViewModel() {
        var viewModel = {
            username: localStorage["username"],
            log: function () {
                userPersister.logout().then(function () {
                    router.navigate("/login");
                }, function (errMsg) {
                    console.log(errMsg);
                });
            },

            createTodoList: function () {
                router.navigate("/create-todolist");
            },

            createAppointment: function () {
                router.navigate("/create-appointment");
            },
            
            goToLists: function () {
                router.navigate("/todo-lists");
            },

            goToAppointments: function () {
                router.navigate("/appointments");
            }
        };

        return new RSVP.Promise(function (res, rej) {
            res(kendo.observable(viewModel));
        });
    };

    function getLoginViewModel() {
        var viewModel = {
            username: "ramito",
            email: "ramiamaire1@gmail.com",
            password: "killer91",
            login: function () {
                var userData = {
                    username: this.get("username"),
                    password: this.get("password"),
                    email: this.get("email")
                };
                userPersister.login(userData).then(function () {
                    router.navigate("/");
                }, function (errMsg) {
                    router.navigate("/errorpage/:" + errMsg.responseText);
                });
            },
            register: function () {
                var userData = {
                    username: this.get("username"),
                    password: this.get("password"),
                    email: this.get("email")
                };
                userPersister.register(userData).then(function () {
                    this.set("username", "");
                    this.set("password", "");
                    this.set("email", "");
                }, function (errMsg) {
                    router.navigate("/errorpage/:" + errMsg.responseText);
                });;
            }
        };
        return new RSVP.Promise(function (res, rej) {
            res(kendo.observable(viewModel));
        });
    };

    function getErroPageViewModel(errMsg) {
        var viewModel = {
            responseText: errMsg
        };
        return new RSVP.Promise(function (res, rej) {
            res(kendo.observable(viewModel));
        });
    };

    return {
        getLoginViewModel: getLoginViewModel,
        getLoggedViewModel: getLoggedViewModel,
        getCreateTodoListModel: getCreateTodoListModel,
        getASingleListTodosModel: getASingleListTodosModel,
        getCreateAppointmentModel: getCreateAppointmentModel,
        getTodoListsModel: getTodoListsModel,
        getAppointmentsModel: getAppointmentsModel,
        getCurrentAppointmentsModel: getCurrentAppointmentsModel,
        getCommingAppointmentsModel: getCommingAppointmentsModel,
        getTodayAppointmentsModel: getTodayAppointmentsModel,
        getDateAppointmentsModel: getDateAppointmentsModel,
        getErroPageViewModel: getErroPageViewModel
    }
}());

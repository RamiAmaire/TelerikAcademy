﻿/// <reference path="../lib/_references.js" />
window.persisters = (function () {
    var currentUsername = null;
    function saveUserData(userData) {
        localStorage.setItem("username", userData.username);
        localStorage.setItem("accessToken", userData.accessToken);
    }

    function clearUserData() {
        localStorage.removeItem("username");
        localStorage.removeItem("accessToken");
        currentUsername = null;
    }

    var MainPersister = Class.create({
        init: function (url) {
            this.rootUrl = url;
            this.userPersister = new UserPersister(this.rootUrl);
            this.listPersister = new ListPersister(this.rootUrl);
            this.todoPersister = new TodoPersister(this.rootUrl);
            this.appointmentPersister = new AppointmentPersister(this.rootUrl);
            this.clearUserData = clearUserData;
        }
    });

    var UserPersister = Class.create({
        init: function (rootUrl) {
            this.rootUrl = rootUrl + "/users";
            this.currentUser = {
                username: localStorage["username"],
                accessToken: localStorage["accessToken"]
            };
        },

        login: function (user) {
            var url = this.rootUrl + "/token";
            var userData = {
                username: user.username,
                authCode: CryptoJS.SHA1(user.username).toString(),
                email: user.email
            }

            return httpRequester.postJSON(url, userData)
				.then(function (data) {
				    currentUsername = userData.username;
				    saveUserData(data);
				    return data;
				},
                function (errMsg) {
                    console.log(errMsg);
                    return errMsg;
                });
        },

        register: function (user) {
            var url = this.rootUrl + "/register";
            var userData = {
                username: user.username,
                authCode: CryptoJS.SHA1(user.username).toString(),
                email: user.email
            }

            return httpRequester.postJSON(url, userData)
				.then(function (data) {
				    return data;
				},
                function (errMsg) {
                    console.log(errMsg);
                    return errMsg;
                });
        },

        logout: function () {
            var accessToken = localStorage["accessToken"];
            var url = this.rootUrl + "/logout";
            var headers = {
                "X-accessToken": accessToken
            };

            return httpRequester.putJSON(url, accessToken, headers)
		    .then(function () {
		        clearUserData();
		    },
            function (errMsg) {
                console.log(errMsg);
            });
        },

        isUserLogged: function () {
            if (localStorage["accessToken"] != null) {
                return true;
            }

            return false;
        }
    });

    var AppointmentPersister = Class.create({
        init: function (rootUrl) {
            this.rootUrl = rootUrl + "/appointments";
        },

        createAppointment: function (appointmentData) {
            var url = this.rootUrl;
            var accessToken = localStorage["accessToken"];
            var headers = {
                "X-accessToken": accessToken
            };

            return httpRequester.postJSON(url, appointmentData, headers)
				.then(function (data) {
				    return data;
				},
                function (errMsg) {
                    console.log(errMsg);
                });
        },

        getAllAppointments: function () {
            var url = this.rootUrl + "/all";
            var accessToken = localStorage["accessToken"];
            var headers = {
                "X-accessToken": accessToken
            };

            return httpRequester.getJSON(url, headers)
				.then(function (data) {
				    return _.sortBy(data, "appointmentDate");
				},
                function (errMsg) {
                    console.log(errMsg);
                });
        },

        getCurrentAppointments: function () {
            var url = this.rootUrl + "/current";
            var accessToken = localStorage["accessToken"];
            var headers = {
                "X-accessToken": accessToken
            };

            return httpRequester.getJSON(url, headers)
				.then(function (data) {
				    return _.sortBy(data, "appointmentDate");
				},
                function (errMsg) {
                    console.log(errMsg);
                });
        },

        getCommingAppointments: function () {
            var url = this.rootUrl + "/comming";
            var accessToken = localStorage["accessToken"];
            var headers = {
                "X-accessToken": accessToken
            };

            return httpRequester.getJSON(url, headers)
				.then(function (data) {
				    return _.sortBy(data, "appointmentDate");
				},
                function (errMsg) {
                    console.log(errMsg);
                });
        },

        getTodayAppointments: function () {
            var url = this.rootUrl + "/today";
            var accessToken = localStorage["accessToken"];
            var headers = {
                "X-accessToken": accessToken
            };

            return httpRequester.getJSON(url, headers)
				.then(function (data) {
				    return _.sortBy(data, "appointmentDate");
				},
                function (errMsg) {
                    console.log(errMsg);
                });
        },

        getDateAppointments: function (date) {
            var url = this.rootUrl + "?date=" + date;
            var accessToken = localStorage["accessToken"];
            var headers = {
                "X-accessToken": accessToken
            };

            return httpRequester.getJSON(url, headers)
				.then(function (data) {
				    return _.sortBy(data, "appointmentDate");
				},
                function (errMsg) {
                    console.log(errMsg);
                });
        }
    });

    var TodoPersister = Class.create({
        init: function (rootUrl) {
            this.rootUrl = rootUrl + "/todos";
        },

        changeTodoStatus: function (id) {
            var url = this.rootUrl + "/" + id;
            var accessToken = localStorage["accessToken"];
            var headers = {
                "X-accessToken": accessToken
            };

            return httpRequester.putJSON(url, id, headers)
				.then(function (data) {
				    return data;
				},
                function (errMsg) {
                    console.log(errMsg);
                });
        }
    });

    var ListPersister = Class.create({
        init: function (rootUrl) {
            this.rootUrl = rootUrl + "/lists";
        },

        createTodoList: function (list) {
            var url = this.rootUrl + "/new";
            var accessToken = localStorage["accessToken"];
            var headers = {
                "X-accessToken": accessToken
            };
            var listData = {
                title: list.title,
                todos: list.todos
            }

            return httpRequester.postJSON(url, listData, headers)
				.then(function (data) {
				    return data;
				},
                function (errMsg) {
                    console.log(errMsg);
                });
        },

        getAllTodoLists: function () {
            var url = this.rootUrl + "/all";
            var accessToken = localStorage["accessToken"];
            var headers = {
                "X-accessToken": accessToken
            };

            return httpRequester.getJSON(url, headers)
				.then(function (data) {
				    return data;
				},
                function (errMsg) {
                    console.log(errMsg);
                });
        },

        getTodosOfAList: function (id) {
            var url = this.rootUrl + "/" + id + "/todos";
            var accessToken = localStorage["accessToken"];
            var headers = {
                "X-accessToken": accessToken
            };

            return httpRequester.getJSON(url, headers)
				.then(function (data) {
				    return data;
				},
                function (errMsg) {
                    console.log(errMsg);
                });
        }
    });

    return {
        get: function (url) {
            return new MainPersister(url);
        }
    }
}());

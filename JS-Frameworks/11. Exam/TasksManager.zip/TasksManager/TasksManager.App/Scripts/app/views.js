﻿/// <reference path="../lib/_references.js" />
window.viewsFactory = (function () {
    var rootUrl = "Scripts/partials/";
    var templates = {};

    function getTemplate(name) {
        var promise = new RSVP.Promise(function (resolve, reject) {
            if (templates[name]) {
                resolve(templates[name])
            }
            else {
                $.ajax({
                    url: rootUrl + name + ".html",
                    type: "GET",
                    success: function (templateHtml) {
                        templates[name] = templateHtml;
                        resolve(templateHtml);
                    },
                    error: function (err) {
                        reject(err)
                    }
                });
            }
        });
        return promise;
    }

    return {
        getErrorPageView: function () { return getTemplate("errorpage-form") },
        getLoginView: function () { return getTemplate("login-form") },
        getLoggedView: function () { return getTemplate("logged-form") },
        getCreateTodoListView: function () { return getTemplate("createTodoList-form") },
        getSingleListTodosView: function () { return getTemplate("singlelist-todos-form") },
        getCreateAppointmentView: function () { return getTemplate("createAppointment-form") },
        getTodolistsView: function () { return getTemplate("todolists-form") },
        getAppointmentsView: function () { return getTemplate("appointments-form") },
        getCurrentAppointmentsView: function () { return getTemplate("currentAppointments-form") },
        getCommingAppointmentsView: function () { return getTemplate("commingAppointments-form") },
        getTodayAppointmentsView: function () { return getTemplate("todayAppointments-form") },
        getDateAppointmentsView: function () { return getTemplate("dateAppointments-form") },
    }
}());
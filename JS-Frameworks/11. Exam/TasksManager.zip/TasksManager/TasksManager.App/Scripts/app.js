﻿/// <reference path="lib/_references.js" />
(function () {
    var persister = persisters.get("http://localhost:16183/api");
    var userPersister = persister.userPersister;
    
    var appLayout = new kendo.Layout('<div id="main-content"></div>');
    var router = new kendo.Router();

    function renderRouteIfLoggedIn(getView, getModel) {
        if (!userPersister.isUserLogged()) {
            router.navigate("/login");
        }
        else {
            renderRoute(getView, getModel);
        }
    };

    function renderRoute(getView, getModel) {
        var args = Array.prototype.slice.apply(arguments);
        args.splice(0, 2);
        getView.apply(null, args).then(function (viewHtml) {
            getModel.apply(null, args).then(function (model) {
                //var template = kendo.template(viewHtml);
                //var finalHtml = template(model);
                var view = new kendo.View(viewHtml, { model: model });
                $("#main-content").empty();
                appLayout.showIn("#main-content", view);

            }, function (modelErr) {
                console.log(modelErr);
            }).then(function () {

            }, function (err) {
                console.log(err);
            });
        }, function (viewError) {
            console.log(viewError);
        });
    };

    //router.route("/appointments/:date", function (date) {
    //    if (date != ":date") {
    //        renderRoute(viewsFactory.getDateAppointmentsView, vmFactory.getDateAppointmentsModel, date);
    //    }
    //});

    router.route("/errorpage/:message", function (message) { renderRoute(viewsFactory.getErrorPageView, vmFactory.getErroPageViewModel, message) });

    router.route("/todo-lists", function () { renderRouteIfLoggedIn(viewsFactory.getTodolistsView, vmFactory.getTodoListsModel) });

    router.route("/appointments/today", function () { renderRouteIfLoggedIn(viewsFactory.getTodayAppointmentsView, vmFactory.getTodayAppointmentsModel) });

    router.route("/appointments/comming", function () { renderRouteIfLoggedIn(viewsFactory.getCommingAppointmentsView, vmFactory.getCommingAppointmentsModel) });

    router.route("/appointments/current", function () { renderRouteIfLoggedIn(viewsFactory.getCurrentAppointmentsView, vmFactory.getCurrentAppointmentsModel) });

    router.route("/appointments", function () { renderRouteIfLoggedIn(viewsFactory.getAppointmentsView, vmFactory.getAppointmentsModel) });

    router.route("/create-appointment", function () { renderRouteIfLoggedIn(viewsFactory.getCreateAppointmentView, vmFactory.getCreateAppointmentModel) });
    
    router.route("/lists/:id/todos", function (id) {
        if (id != ":id") {
            renderRoute(viewsFactory.getSingleListTodosView, vmFactory.getASingleListTodosModel, id);
        }
    });

    router.route("/", function () { renderRouteIfLoggedIn(viewsFactory.getLoggedView, vmFactory.getLoggedViewModel) });
   
    router.route("/login", function () { renderRoute(viewsFactory.getLoginView, vmFactory.getLoginViewModel) });

    router.route("/create-todolist", function () { renderRoute(viewsFactory.getCreateTodoListView, vmFactory.getCreateTodoListModel) });

    $(function () {
        appLayout.render("#application");
        router.start();
    });
}());

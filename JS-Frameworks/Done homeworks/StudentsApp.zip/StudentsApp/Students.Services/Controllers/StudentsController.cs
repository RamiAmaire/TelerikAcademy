﻿using Students.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Students.Services.Controllers
{
    public class StudentsController : ApiController
    {
        private ICollection<StudentModel> students;

        public StudentsController()
        {
            this.students = new HashSet<StudentModel>()
            {
                new StudentModel()
                {
                    Id = 1,
                    Name = "Todor",
                    Grade = 10,
                    Marks = new HashSet<MarkModel>()
                    {
                        new MarkModel(){ Subject = "Mathematics", Score = 5},
                        new MarkModel(){ Subject = "History", Score = 6},
                        new MarkModel(){ Subject = "Literature", Score = 4.5}
                    }
                },
                new StudentModel()
                {
                    Id = 2,
                    Name = "Georgi",
                    Grade = 12,
                    Marks = new HashSet<MarkModel>()
                    {
                        new MarkModel(){ Subject = "HTML", Score = 6},
                        new MarkModel(){ Subject = "C++", Score = 4},
                        new MarkModel(){ Subject = "English", Score = 5.5}
                    }
                },
                new StudentModel()
                {
                    Id = 3,
                    Name = "Dimitur",
                    Grade = 11,
                    Marks = new HashSet<MarkModel>()
                    {
                        new MarkModel(){ Subject = "Psychology", Score = 5},
                        new MarkModel(){ Subject = "German", Score = 3},
                        new MarkModel(){ Subject = "French", Score = 5.5}
                    }
                },
            };
        }

        public IQueryable<StudentModel> GetAll()
        {
            return this.students.AsQueryable();
        }

        [HttpGet]
        [ActionName("marks")]
        public IQueryable<MarkModel> GetStudentMarks(int studentId)
        {
            StudentModel currentStudent = this.GetAll().FirstOrDefault(s => s.Id == studentId);
            if (currentStudent == null)
            {
                throw new ArgumentException("Invalid student id.");
            }

            IQueryable<MarkModel> marks = currentStudent.Marks.AsQueryable();
            return marks;
        }
    }
}

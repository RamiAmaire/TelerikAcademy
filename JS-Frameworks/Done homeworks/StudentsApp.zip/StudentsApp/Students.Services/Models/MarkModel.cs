﻿using System;

namespace Students.Services.Models
{
    public class MarkModel
    {
        public MarkModel()
        {
        }

        public string Subject { get; set; }

        public double Score { get; set; }
    }
}
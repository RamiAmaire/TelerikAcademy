﻿/// <reference path="app/controls.js" />
/// <reference path="app/data-persister.js" />
/// <reference path="libs/require.js" />
require.config({
    waitSeconds: 200,
	paths: {
		jquery: "libs/jquery-2.0.3",
		rsvp: "libs/rsvp.min",
		httpRequester: "libs/http-requester",
		mustache: "libs/mustache",
		controls: "app/controls",
		dataPersister: "app/data-persister"
	}
});

require(["jquery", "mustache", "dataPersister", "controls"], function ($, mustache, dataPersister, controls) {
    dataPersister.students().then(function (students) {
		var studentsTemplate = $("#students-template").html();
		var template = mustache.compile(studentsTemplate);
		var studentTableView = controls.studentTableView(students);
		var studentTableViewHtml = studentTableView.render(template);
		$("#content").append(studentTableViewHtml);
		}, function (err) {
			console.error(err);
		});

    $("#content").on("click", "tr", function (event) {
        var row = event.target.parentNode;
        var studentId = row.children[0].innerHTML;
        dataPersister.studentMarks(studentId)
        .then(function (marks) {
            var marksTemplateString = $("#marks-template").html();
            var template = mustache.compile(marksTemplateString);
            var markTableView = controls.markTableView(marks);
            var markTableViewHtml = markTableView.render(template);
            document.getElementById("content").innerHTML = markTableViewHtml;
        }, function (err) {
            console.error(err);
        });
    });
});
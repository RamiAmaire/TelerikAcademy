﻿/// <reference path="jquery-2.0.3.js" />
/// <reference path="class.js" />
define(["libs/class"], function (Class) {
	var controls = controls || {};
	var StudentTableView = Class.create({
	    init: function (itemsSource) {
	        if (!(itemsSource instanceof Array)) {
	            throw "The itemsSource of a ListView must be an array!";
	        }
	        this.itemsSource = itemsSource;
	    },
	    render: function (template) {
	        var table = document.createElement("table");
	        var header = document.createElement("tr");
	        header.innerHTML = "<th>Id</th><th>Name</th><th>Grade</th>";
	        table.appendChild(header);

	        for (var i = 0; i < this.itemsSource.length; i++) {
	            var tableRow = document.createElement("tr");
	            var item = this.itemsSource[i];
	            tableRow.innerHTML = template(item);
	            table.appendChild(tableRow);
	        }
	        return table.outerHTML;
	    }
	});

	var MarkTableView = Class.create({
	    init: function (itemsSource) {
	        if (!(itemsSource instanceof Array)) {
	            throw "The itemsSource of a ListView must be an array!";
	        }
	        this.itemsSource = itemsSource;
	    },
	    render: function (template) {
	        var table = document.createElement("table");
	        var header = document.createElement("tr");
	        header.innerHTML = "<th>Subject</th><th>Score</th>";
	        table.appendChild(header);

	        for (var i = 0; i < this.itemsSource.length; i++) {
	            var tableRow = document.createElement("tr");
	            var item = this.itemsSource[i];
	            tableRow.innerHTML = template(item);
	            table.appendChild(tableRow);
	        }
	        return table.outerHTML;
	    }
	});

	controls.studentTableView = function (itemsSource) {
	    return new StudentTableView(itemsSource);
	}

	controls.markTableView = function (itemsSource) {
	    return new MarkTableView(itemsSource);
	}

	return controls;
});
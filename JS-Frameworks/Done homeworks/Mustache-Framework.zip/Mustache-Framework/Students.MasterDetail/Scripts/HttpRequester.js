﻿var httpRequester = (function () {
    function getJSONRequest(url, success, error) {
        $.ajax({
            url: url,
            type: "GET",
            contentType: "application/json",
            timeout: 5000,
            success: success,
            error: error
        })
    }

    return {
        getJSON: getJSONRequest
    }
}());
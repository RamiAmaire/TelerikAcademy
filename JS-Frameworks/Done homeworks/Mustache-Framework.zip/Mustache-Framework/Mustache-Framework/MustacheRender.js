﻿var template = "{{#render}} {{fullname}}, {{age}}{{/render}}";
var rami = new Student("Rami", "Amaire", 22);
var output = Mustache.render(template, rami);
var content = document.getElementById("content");
content.innerHTML = output;
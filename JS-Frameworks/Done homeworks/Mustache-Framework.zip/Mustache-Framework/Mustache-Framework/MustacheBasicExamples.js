﻿/// <reference path="Scripts/class.js" />
/// <reference path="Scripts/jquery-2.0.3.intellisense.js" />
/// <reference path="Scripts/Students.js" />
/// <reference path="Scripts/mustache.js" />


var rami = new Student("Rami", "Amaire", 22);
var template = "Iam {{fullname}}, but you can call me {{fname}}. {{#age}} I'am {{age}} years old.{{/age}}";
var output = Mustache.render(template, rami);
document.getElementById("content").innerHTML = output;
﻿var Student = Class.create({
    init: function (fname, lname, age) {
        this.fname = fname,
        this.lname = lname,
        this.age = age
    },
    fullname: function () {
        return this.fname + " " + this.lname;
    },
    render: function () {
        return function (text, render) {
            return "<strong>" + render(text) + "</strong>";
        }
    },
    toString: function () {
        return "Name : " + this.lname + ", " + "Age : " + this.age;
    }
});
﻿/// <reference path="Scripts/class.js" />
/// <reference path="Scripts/jquery-2.0.3.intellisense.js" />
/// <reference path="Scripts/Students.js" />
/// <reference path="Scripts/mustache.js" />

// First
var contentDiv = document.getElementById("content");
var view = {
    students: [new Student("Rami", "Amaire", 22), new Student("Peter", "Petrov"), new Student("Gosho", "Georgiev")]
};
var template =
    "<ul>" +
    "{{#students}}" +
    "<li>{{.}}</li>" +
    "{{/students}}" +
    "</ul>";

contentDiv.innerHTML = Mustache.render(template, view);

// Second
var contentDiv = document.getElementById("content");
var view = {
    students: [new Student("Rami", "Amaire", 22), new Student("Peter", "Petrov"), new Student("Gosho", "Georgiev")]
};

var template = "{{#students}} Student {{fname}} has {{#age}}age {{age}}{{/age}}{{^age}}no age{{/age}}.{{/students}}";
contentDiv.innerHTML = Mustache.render(template, view);
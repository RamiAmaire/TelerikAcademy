﻿using Students.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Students.Services.Controllers
{
    public class StudentsController : ApiController
    {
        private List<StudentModel> students;

        public StudentsController()
        {
            this.students = new List<StudentModel>()
            {
                new StudentModel()
                { 
                    Firstname = "Peter",
                    Lastname = "Petrov",
                    Grade = 11, 
                    Age = 17,
                    Marks = new HashSet<MarksModel>(){new MarksModel(){ Subject = "Maths", Score = 5},
                        new MarksModel(){ Subject = "Physics", Score = 6}}
                },
                new StudentModel()
                { 
                    Firstname = "Gosho",
                    Lastname = "Goshev",
                    Grade = 12, 
                    Age = 18,
                    Marks = new HashSet<MarksModel>(){new MarksModel(){ Subject = "Bulgarian", Score = 6},
                        new MarksModel(){ Subject = "History", Score = 6}}
                }
            };
        }

        [HttpGet]
        [ActionName("get-all")]
        public IEnumerable<StudentModel> GetAll()
        {
            return this.students;
        }

        // GET api/students
        public IEnumerable<StudentModel> Get()
        {
            return this.students;
        }

        // GET api/students/5
        public StudentModel Get(int id)
        {
            return this.students[id];
        }
    }
}

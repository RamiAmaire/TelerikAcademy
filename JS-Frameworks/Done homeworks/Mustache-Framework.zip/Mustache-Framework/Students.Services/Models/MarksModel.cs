﻿using System;

namespace Students.Services.Models
{
    public class MarksModel
    {
        public MarksModel()
        {
        }

        public string Subject { get; set; }

        public double Score { get; set; }
    }
}
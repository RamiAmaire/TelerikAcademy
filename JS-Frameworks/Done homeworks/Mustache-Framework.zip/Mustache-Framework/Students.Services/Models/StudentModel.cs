﻿using System;
using System.Collections.Generic;

namespace Students.Services.Models
{
    public class StudentModel
    {
        public StudentModel()
        {
            this.Marks = new HashSet<MarksModel>();
        }

        public string Firstname { get; set; }

        public string Lastname { get; set; }

        public int Grade { get; set; }

        public int Age { get; set; }

        public virtual ICollection<MarksModel> Marks { get; set; }
    }
}